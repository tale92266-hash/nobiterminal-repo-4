#----------------------------------------------------------------
# Generated CMake target import file for configuration "MinSizeRel".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Qt6::ShaderTools" for configuration "MinSizeRel"
set_property(TARGET Qt6::ShaderTools APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(Qt6::ShaderTools PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libQt6ShaderTools.so.6.12.0"
  IMPORTED_SONAME_MINSIZEREL "libQt6ShaderTools.so.6"
  )

list(APPEND _cmake_import_check_targets Qt6::ShaderTools )
list(APPEND _cmake_import_check_files_for_Qt6::ShaderTools "${_IMPORT_PREFIX}/lib/libQt6ShaderTools.so.6.12.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
