/data/data/com.nobiterminal/files/usr/bin/direnv hook fish | source
