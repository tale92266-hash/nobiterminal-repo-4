#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "dart-utils" for configuration "Release"
set_property(TARGET dart-utils APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(dart-utils PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libdart-utils.so"
  IMPORTED_SONAME_RELEASE "libdart-utils.so"
  )

list(APPEND _cmake_import_check_targets dart-utils )
list(APPEND _cmake_import_check_files_for_dart-utils "/data/data/com.nobiterminal/files/usr/lib/libdart-utils.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
