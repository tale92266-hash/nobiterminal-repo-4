/*
 * Copyright (c) 2011, The DART development contributors
 * All rights reserved.
 *
 * The list of contributors can be found at:
 *   https://github.com/dartsim/dart/blob/main/LICENSE
 *
 * This file is provided under the following "BSD-style" License:
 *   Redistribution and use in source and binary forms, with or
 *   without modification, are permitted provided that the following
 *   conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 *   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *   LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *   ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *   POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef DART_DYNAMICS_DETAIL_GenericJoint_HPP_
#define DART_DYNAMICS_DETAIL_GenericJoint_HPP_

#include "dart/common/Macros.hpp"

#include <dart/config.hpp>

#include <dart/dynamics/BodyNode.hpp>
#include <dart/dynamics/DegreeOfFreedom.hpp>
#include <dart/dynamics/GenericJoint.hpp>

#include <dart/math/ConfigurationSpace.hpp>
#include <dart/math/Helpers.hpp>

#include <cmath>
#include <cstring>

#define GenericJoint_REPORT_DIM_MISMATCH(func, arg)                            \
  {                                                                            \
    dterr << "[GenericJoint::" #func "] Mismatch between size of "             \
          << #arg " [" << arg.size() << "] and the number of "                 \
          << "DOFs [" << getNumDofs() << "] for Joint named ["                 \
          << this->getName() << "].\n";                                        \
    DART_ASSERT(false);                                                        \
  }

#define GenericJoint_REPORT_OUT_OF_RANGE(func, index)                          \
  {                                                                            \
    dterr << "[GenericJoint::" << #func << "] The index [" << index            \
          << "] is out of range for Joint named [" << this->getName()          \
          << "] which has " << this->getNumDofs() << " DOFs.\n";               \
    DART_ASSERT(false);                                                        \
  }

#define GenericJoint_REPORT_UNSUPPORTED_ACTUATOR(func)                         \
  {                                                                            \
    dterr << "[GenericJoint::" #func "] Unsupported actuator type ("           \
          << Joint::mAspectProperties.mActuatorType << ") for Joint ["         \
          << this->getName() << "].\n";                                        \
    DART_ASSERT(false);                                                        \
  }

#define GenericJoint_SET_IF_DIFFERENT(mField, value)                           \
  if (value == Base::mAspectProperties.mField)                                 \
    return;                                                                    \
  Base::mAspectProperties.mField = value;                                      \
  Joint::incrementVersion();

namespace dart {
namespace dynamics {

//==============================================================================
inline bool Joint::isChildArticulatedInertia(
    const Eigen::Matrix6d& artInertia) const
{
  return mChildBodyNode != nullptr
         && std::memcmp(
                artInertia.data(),
                mChildBodyNode->mArtInertia.data(),
                sizeof(double) * artInertia.size())
                == 0;
}

namespace detail {

template <typename Derived>
inline void assertFiniteState(
    const Eigen::MatrixBase<Derived>& values,
    const Joint* joint,
    const char* context,
    const char* valueName)
{
#ifndef NDEBUG
  const bool finite = values.array().isFinite().all();
  if (!finite) {
    DART_ERROR(
        "Non-finite {} passed to {} for Joint [{}] ({}).",
        valueName,
        context,
        joint->getName(),
        static_cast<const void*>(joint));
  }
  DART_ASSERT(finite);
#else
  (void)values;
  (void)joint;
  (void)context;
  (void)valueName;
#endif
}

inline void assertFiniteState(
    double value,
    const Joint* joint,
    const char* context,
    const char* valueName)
{
#ifndef NDEBUG
  const bool finite = std::isfinite(value);
  if (!finite) {
    DART_ERROR(
        "Non-finite {} passed to {} for Joint [{}] ({}).",
        valueName,
        context,
        joint->getName(),
        static_cast<const void*>(joint));
  }
  DART_ASSERT(finite);
#else
  (void)value;
  (void)joint;
  (void)context;
  (void)valueName;
#endif
}

} // namespace detail
} // namespace dynamics
} // namespace dart

namespace dart {
namespace dynamics {

//==============================================================================
//
// These namespace-level definitions are required to enable ODR-use of static
// constexpr member variables.
//
// See this StackOverflow answer: http://stackoverflow.com/a/14396189/111426
//
template <class ConfigSpaceT>
constexpr size_t GenericJoint<ConfigSpaceT>::NumDofs;

//==============================================================================
template <class ConfigSpaceT>
GenericJoint<ConfigSpaceT>::~GenericJoint()
{
  for (auto i = 0u; i < NumDofs; ++i)
    delete mDofs[i];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setProperties(const Properties& properties)
{
  Joint::setProperties(static_cast<const Joint::Properties&>(properties));
  setProperties(static_cast<const UniqueProperties&>(properties));
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setProperties(
    const UniqueProperties& properties)
{
  setAspectProperties(properties);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setAspectState(const AspectState& state)
{
  setCommands(state.mCommands);
  setPositionsStatic(state.mPositions);
  setVelocitiesStatic(state.mVelocities);
  setAccelerationsStatic(state.mAccelerations);
  setForces(state.mForces);
  this->mAspectState.mVelocityChanges = state.mVelocityChanges;
  this->mAspectState.mImpulses = state.mImpulses;
  this->mAspectState.mConstraintImpulses = state.mConstraintImpulses;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setAspectProperties(
    const AspectProperties& properties)
{
  for (auto i = 0u; i < NumDofs; ++i) {
    setDofName(i, properties.mDofNames[i], properties.mPreserveDofNames[i]);
    setPositionLowerLimit(i, properties.mPositionLowerLimits[i]);
    setPositionUpperLimit(i, properties.mPositionUpperLimits[i]);
    setInitialPosition(i, properties.mInitialPositions[i]);
    setVelocityLowerLimit(i, properties.mVelocityLowerLimits[i]);
    setVelocityUpperLimit(i, properties.mVelocityUpperLimits[i]);
    setInitialVelocity(i, properties.mInitialVelocities[i]);
    setAccelerationLowerLimit(i, properties.mAccelerationLowerLimits[i]);
    setAccelerationUpperLimit(i, properties.mAccelerationUpperLimits[i]);
    setForceLowerLimit(i, properties.mForceLowerLimits[i]);
    setForceUpperLimit(i, properties.mForceUpperLimits[i]);
    setSpringStiffness(i, properties.mSpringStiffnesses[i]);
    setRestPosition(i, properties.mRestPositions[i]);
    setDampingCoefficient(i, properties.mDampingCoefficients[i]);
    setCoulombFriction(i, properties.mFrictions[i]);
  }
}

//==============================================================================
template <class ConfigSpaceT>
typename GenericJoint<ConfigSpaceT>::Properties
GenericJoint<ConfigSpaceT>::getGenericJointProperties() const
{
  return GenericJoint<ConfigSpaceT>::Properties(
      Joint::mAspectProperties, Base::mAspectProperties);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::copy(const GenericJoint<ConfigSpaceT>& other)
{
  if (this == &other)
    return;

  setProperties(other.getGenericJointProperties());
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::copy(const GenericJoint<ConfigSpaceT>* other)
{
  if (nullptr == other)
    return;

  copy(*other);
}

//==============================================================================
template <class ConfigSpaceT>
GenericJoint<ConfigSpaceT>& GenericJoint<ConfigSpaceT>::operator=(
    const GenericJoint<ConfigSpaceT>& other)
{
  copy(other);
  return *this;
}

//==============================================================================
template <class ConfigSpaceT>
DegreeOfFreedom* GenericJoint<ConfigSpaceT>::getDof(size_t index)
{
  if (index < NumDofs)
    return mDofs[index];

  GenericJoint_REPORT_OUT_OF_RANGE(getDof, index);

  return nullptr;
}

//==============================================================================
template <class ConfigSpaceT>
const DegreeOfFreedom* GenericJoint<ConfigSpaceT>::getDof(size_t index) const
{
  if (index < NumDofs)
    return mDofs[index];

  GenericJoint_REPORT_OUT_OF_RANGE(getDof, index);

  return nullptr;
}

//==============================================================================
template <class ConfigSpaceT>
size_t GenericJoint<ConfigSpaceT>::getNumDofs() const
{
  return NumDofs;
}

//==============================================================================
template <class ConfigSpaceT>
const std::string& GenericJoint<ConfigSpaceT>::setDofName(
    size_t index, const std::string& name, bool preserveName)
{
  if (NumDofs <= index) {
    dterr << "[GenericJoint::setDofName] Attempting to set the name of DOF "
          << "index " << index << ", which is out of bounds for the Joint ["
          << this->getName()
          << "]. We will set the name of DOF index 0 instead.\n";
    DART_ASSERT(false);
    index = 0u;
  }

  preserveDofName(index, preserveName);

  std::string& dofName = Base::mAspectProperties.mDofNames[index];

  if (name == dofName)
    return dofName;

  const SkeletonPtr& skel
      = this->mChildBodyNode ? this->mChildBodyNode->getSkeleton() : nullptr;
  if (skel)
    dofName = skel->mNameMgrForDofs.changeObjectName(mDofs[index], name);
  else
    dofName = name;

  return dofName;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::preserveDofName(size_t index, bool preserve)
{
  if (NumDofs <= index) {
    GenericJoint_REPORT_OUT_OF_RANGE(preserveDofName, index);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mPreserveDofNames[index], preserve);
}

//==============================================================================
template <class ConfigSpaceT>
bool GenericJoint<ConfigSpaceT>::isDofNamePreserved(size_t index) const
{
  if (NumDofs <= index) {
    GenericJoint_REPORT_OUT_OF_RANGE(isDofNamePreserved, index);
    index = 0;
  }

  return Base::mAspectProperties.mPreserveDofNames[index];
}

//==============================================================================
template <class ConfigSpaceT>
const std::string& GenericJoint<ConfigSpaceT>::getDofName(size_t index) const
{
  if (NumDofs <= index) {
    dterr << "[GenericJoint::getDofName] Requested name of DOF index [" << index
          << "] in Joint [" << this->getName() << "], but that is "
          << "out of bounds (max " << NumDofs - 1
          << "). Returning name of DOF 0.\n";
    DART_ASSERT(false);
    return Base::mAspectProperties.mDofNames[0];
  }

  return Base::mAspectProperties.mDofNames[index];
}

//==============================================================================
template <class ConfigSpaceT>
size_t GenericJoint<ConfigSpaceT>::getIndexInSkeleton(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getIndexInSkeleton, index);
    return 0;
  }

  return mDofs[index]->mIndexInSkeleton;
}

//==============================================================================
template <class ConfigSpaceT>
size_t GenericJoint<ConfigSpaceT>::getIndexInTree(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getIndexInTree, index);
    return 0;
  }

  return mDofs[index]->mIndexInTree;
}

//==============================================================================
template <class ConfigSpaceT>
Joint::ActuatorType GenericJoint<ConfigSpaceT>::getActuatorTypeForValidIndex(
    std::size_t index) const
{
  DART_ASSERT(index < getNumDofs());
  return Joint::mAspectProperties.mActuatorTypes.empty()
             ? Joint::mAspectProperties.mActuatorType
             : Joint::getActuatorType(index);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setCommand(size_t index, double command)
{
  if (index >= getNumDofs())
    GenericJoint_REPORT_OUT_OF_RANGE(setCommand, index);

  // Validate command is finite to prevent NaN/Inf from propagating through
  // the simulation and causing assertion failures (gz-physics#845)
  if (!std::isfinite(command)) {
    dtwarn << "[GenericJoint::setCommand] Non-finite command (" << command
           << ") passed for Joint [" << this->getName() << "] DOF [" << index
           << "]. Command ignored.\n";
    return;
  }

  const double previousCommand = this->mAspectState.mCommands[index];
  switch (getActuatorTypeForValidIndex(index)) {
    case Joint::FORCE:
      this->mAspectState.mCommands[index] = math::clip(
          command,
          Base::mAspectProperties.mForceLowerLimits[index],
          Base::mAspectProperties.mForceUpperLimits[index]);
      break;
    case Joint::PASSIVE:
      if (0.0 != command) {
        dtwarn << "[GenericJoint::setCommand] Attempting to set a non-zero ("
               << command << ") command for a PASSIVE joint ["
               << this->getName() << "].\n";
      }
      this->mAspectState.mCommands[index] = 0.0;
      break;
    case Joint::SERVO:
      this->mAspectState.mCommands[index] = math::clip(
          command,
          Base::mAspectProperties.mVelocityLowerLimits[index],
          Base::mAspectProperties.mVelocityUpperLimits[index]);
      break;
    case Joint::MIMIC:
      if (0.0 != command) {
        dtwarn << "[GenericJoint::setCommand] Attempting to set a non-zero ("
               << command << ") command for a MIMIC joint [" << this->getName()
               << "].\n";
      }
      this->mAspectState.mCommands[index] = 0.0;
      break;
    case Joint::ACCELERATION:
      this->mAspectState.mCommands[index] = math::clip(
          command,
          Base::mAspectProperties.mAccelerationLowerLimits[index],
          Base::mAspectProperties.mAccelerationUpperLimits[index]);
      break;
    case Joint::VELOCITY:
      this->mAspectState.mCommands[index] = math::clip(
          command,
          Base::mAspectProperties.mVelocityLowerLimits[index],
          Base::mAspectProperties.mVelocityUpperLimits[index]);
      // TODO: This possibly makes the acceleration to exceed the limits.
      break;
    case Joint::LOCKED:
      if (0.0 != command) {
        dtwarn << "[GenericJoint::setCommand] Attempting to set a non-zero ("
               << command << ") command for a LOCKED joint [" << this->getName()
               << "].\n";
      }
      this->mAspectState.mCommands[index] = 0.0;
      break;
    default:
      DART_ASSERT(false);
      break;
  }

  if (this->mAspectState.mCommands[index] != previousCommand)
    this->notifyExternalDisturbanceUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getCommand(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getCommand, index);
    return 0.0;
  }

  return this->mAspectState.mCommands[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setCommands(const Eigen::VectorXd& commands)
{
  if (static_cast<size_t>(commands.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setCommands, commands);
    return;
  }

  // Dispatch per DoF so that joints with mixed (per-DoF) actuator types apply
  // the correct clamping/zeroing rules for each DoF. Compare through the
  // virtual getter: a derived joint may override setCommand() and getCommand()
  // to keep its commands outside mCommands, and controllers may resend the same
  // commands every step, which must not count as a disturbance.
  bool changed = false;
  for (std::size_t i = 0; i < getNumDofs(); ++i) {
    const double previousCommand = this->getCommand(i);
    setCommand(i, commands[static_cast<Eigen::Index>(i)]);
    changed |= this->getCommand(i) != previousCommand;
  }

  if (changed)
    this->notifyExternalDisturbanceUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getCommands() const
{
  return this->mAspectState.mCommands;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::resetCommands()
{
  const bool changed = (this->mAspectState.mCommands.array() != 0.0).any();
  this->mAspectState.mCommands.setZero();
  if (changed)
    this->notifyExternalDisturbanceUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setPosition(size_t index, double position)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setPosition, index);
    return;
  }

  detail::assertFiniteState(position, this, "setPosition", "position");

  if (this->mAspectState.mPositions[index] == position)
    return;
  // TODO(JS): Above code should be changed something like:
  //  if (ConfigSpaceT::getEuclideanPoint(mPositions, index) == position)
  //    return;

  // Note: It would not make much sense to use setPositionsStatic() here
  this->mAspectState.mPositions[index] = position;
  this->notifyPositionUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getPosition(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getPosition, index);
    return 0.0;
  }

  return getPositionsStatic()[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setPositions(const Eigen::VectorXd& positions)
{
  if (static_cast<size_t>(positions.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setPositions, positions);
    return;
  }

  setPositionsStatic(positions);
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getPositions() const
{
  return getPositionsStatic();
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setPositionLowerLimit(
    size_t index, double position)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setPositionLowerLimit, index);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mPositionLowerLimits[index], position);
  this->notifyAutomaticConstraintPropertiesUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getPositionLowerLimit(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getPositionLowerLimit, index);
    return 0.0;
  }

  return Base::mAspectProperties.mPositionLowerLimits[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setPositionLowerLimits(
    const Eigen::VectorXd& lowerLimits)
{
  if (static_cast<size_t>(lowerLimits.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setPositionLowerLimits, lowerLimits);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mPositionLowerLimits, lowerLimits);
  this->notifyAutomaticConstraintPropertiesUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getPositionLowerLimits() const
{
  return Base::mAspectProperties.mPositionLowerLimits;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setPositionUpperLimit(
    size_t index, double position)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setPositionUpperLimit, index);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mPositionUpperLimits[index], position);
  this->notifyAutomaticConstraintPropertiesUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getPositionUpperLimit(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getPositionUpperLimit, index);
    return 0.0;
  }

  return Base::mAspectProperties.mPositionUpperLimits[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setPositionUpperLimits(
    const Eigen::VectorXd& upperLimits)
{
  if (static_cast<size_t>(upperLimits.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setPositionUpperLimits, upperLimits);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mPositionUpperLimits, upperLimits);
  this->notifyAutomaticConstraintPropertiesUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getPositionUpperLimits() const
{
  return Base::mAspectProperties.mPositionUpperLimits;
}

//==============================================================================
template <class ConfigSpaceT>
bool GenericJoint<ConfigSpaceT>::hasPositionLimit(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(hasPositionLimit, index);
    return true;
  }

  return std::isfinite(Base::mAspectProperties.mPositionUpperLimits[index])
         || std::isfinite(Base::mAspectProperties.mPositionLowerLimits[index]);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::resetPosition(size_t index)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(resetPosition, index);
    return;
  }

  setPosition(index, Base::mAspectProperties.mInitialPositions[index]);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::resetPositions()
{
  setPositionsStatic(Base::mAspectProperties.mInitialPositions);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setInitialPosition(
    size_t index, double initial)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setInitialPosition, index);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mInitialPositions[index], initial);
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getInitialPosition(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getInitialPosition, index);
    return 0.0;
  }

  return Base::mAspectProperties.mInitialPositions[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setInitialPositions(
    const Eigen::VectorXd& initial)
{
  if (static_cast<size_t>(initial.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setInitialPositions, initial);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mInitialPositions, initial);
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getInitialPositions() const
{
  return Base::mAspectProperties.mInitialPositions;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setPositionsStatic(const Vector& positions)
{
  detail::assertFiniteState(positions, this, "setPositions", "positions");

  if (this->mAspectState.mPositions == positions)
    return;

  this->mAspectState.mPositions = positions;
  this->notifyPositionUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
const typename GenericJoint<ConfigSpaceT>::Vector&
GenericJoint<ConfigSpaceT>::getPositionsStatic() const
{
  return this->mAspectState.mPositions;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setVelocitiesStatic(const Vector& velocities)
{
  setVelocitiesStaticInternal(velocities, true);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setVelocitiesStaticInternal(
    const Vector& velocities, bool trackVelocityVersion)
{
  detail::assertFiniteState(velocities, this, "setVelocities", "velocities");

  if (this->mAspectState.mVelocities == velocities)
    return;

  this->mAspectState.mVelocities = velocities;
  this->notifyVelocityUpdated(trackVelocityVersion);
}

//==============================================================================
template <class ConfigSpaceT>
const typename GenericJoint<ConfigSpaceT>::Vector&
GenericJoint<ConfigSpaceT>::getVelocitiesStatic() const
{
  return this->mAspectState.mVelocities;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setAccelerationsStatic(const Vector& accels)
{
  detail::assertFiniteState(accels, this, "setAccelerations", "accelerations");

  if (this->mAspectState.mAccelerations == accels)
    return;

  this->mAspectState.mAccelerations = accels;
  this->notifyAccelerationUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
const typename GenericJoint<ConfigSpaceT>::Vector&
GenericJoint<ConfigSpaceT>::getAccelerationsStatic() const
{
  return this->mAspectState.mAccelerations;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setVelocity(size_t index, double velocity)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setVelocity, index);
    return;
  }

  detail::assertFiniteState(velocity, this, "setVelocity", "velocity");

  if (this->mAspectState.mVelocities[index] == velocity)
    return;

  // Note: It would not make much sense to use setVelocitiesStatic() here
  this->mAspectState.mVelocities[index] = velocity;
  this->notifyVelocityUpdated();

  if (getActuatorTypeForValidIndex(index) == Joint::VELOCITY) {
    const double command = this->getVelocitiesStatic()[index];
    if (this->mAspectState.mCommands[index] != command) {
      this->mAspectState.mCommands[index] = command;
      this->notifyExternalDisturbanceUpdated();
    }
  }
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getVelocity(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getVelocity, index);
    return 0.0;
  }

  return getVelocitiesStatic()[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setVelocities(
    const Eigen::VectorXd& velocities)
{
  if (static_cast<size_t>(velocities.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setVelocities, velocities);
    return;
  }

  setVelocitiesStatic(velocities);

  bool commandChanged = false;
  for (std::size_t i = 0; i < getNumDofs(); ++i) {
    if (getActuatorTypeForValidIndex(i) == Joint::VELOCITY) {
      const double command = this->getVelocitiesStatic()[i];
      if (this->mAspectState.mCommands[i] != command) {
        this->mAspectState.mCommands[i] = command;
        commandChanged = true;
      }
    }
  }
  if (commandChanged)
    this->notifyExternalDisturbanceUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getVelocities() const
{
  return getVelocitiesStatic();
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setVelocityLowerLimit(
    size_t index, double velocity)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setVelocityLowerLimit, index);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mVelocityLowerLimits[index], velocity);
  this->notifyAutomaticConstraintPropertiesUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getVelocityLowerLimit(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getVelocityLowerLimit, index);
    return 0.0;
  }

  return Base::mAspectProperties.mVelocityLowerLimits[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setVelocityLowerLimits(
    const Eigen::VectorXd& lowerLimits)
{
  if (static_cast<size_t>(lowerLimits.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setVelocityLowerLimits, lowerLimits);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mVelocityLowerLimits, lowerLimits);
  this->notifyAutomaticConstraintPropertiesUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getVelocityLowerLimits() const
{
  return Base::mAspectProperties.mVelocityLowerLimits;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setVelocityUpperLimit(
    size_t index, double velocity)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setVelocityUpperLimit, index);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mVelocityUpperLimits[index], velocity);
  this->notifyAutomaticConstraintPropertiesUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getVelocityUpperLimit(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getVelocityUpperLimit, index);
    return 0.0;
  }

  return Base::mAspectProperties.mVelocityUpperLimits[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setVelocityUpperLimits(
    const Eigen::VectorXd& upperLimits)
{
  if (static_cast<size_t>(upperLimits.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setVelocityUpperLimits, upperLimits);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mVelocityUpperLimits, upperLimits);
  this->notifyAutomaticConstraintPropertiesUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getVelocityUpperLimits() const
{
  return Base::mAspectProperties.mVelocityUpperLimits;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::resetVelocity(size_t index)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(resetVelocity, index);
    return;
  }

  setVelocity(index, Base::mAspectProperties.mInitialVelocities[index]);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::resetVelocities()
{
  setVelocitiesStatic(Base::mAspectProperties.mInitialVelocities);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setInitialVelocity(
    size_t index, double initial)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setInitialVelocity, index);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mInitialVelocities[index], initial);
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getInitialVelocity(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getInitialVelocity, index);
    return 0.0;
  }

  return Base::mAspectProperties.mInitialVelocities[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setInitialVelocities(
    const Eigen::VectorXd& initial)
{
  if (static_cast<size_t>(initial.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setInitialVelocities, initial);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mInitialVelocities, initial);
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getInitialVelocities() const
{
  return Base::mAspectProperties.mInitialVelocities;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setAcceleration(
    size_t index, double acceleration)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setAcceleration, index);
    return;
  }

  detail::assertFiniteState(
      acceleration, this, "setAcceleration", "acceleration");

  if (this->mAspectState.mAccelerations[index] == acceleration)
    return;

  // Note: It would not make much sense to use setAccelerationsStatic() here
  this->mAspectState.mAccelerations[index] = acceleration;
  this->notifyAccelerationUpdated();

  if (getActuatorTypeForValidIndex(index) == Joint::ACCELERATION) {
    const double command = this->getAccelerationsStatic()[index];
    if (this->mAspectState.mCommands[index] != command) {
      this->mAspectState.mCommands[index] = command;
      this->notifyExternalDisturbanceUpdated();
    }
  }
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getAcceleration(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getAcceleration, index);
    return 0.0;
  }

  return getAccelerationsStatic()[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setAccelerations(
    const Eigen::VectorXd& accelerations)
{
  if (static_cast<size_t>(accelerations.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setAccelerations, accelerations);
    return;
  }

  setAccelerationsStatic(accelerations);

  bool commandChanged = false;
  for (std::size_t i = 0; i < getNumDofs(); ++i) {
    if (getActuatorTypeForValidIndex(i) == Joint::ACCELERATION) {
      const double command = this->getAccelerationsStatic()[i];
      if (this->mAspectState.mCommands[i] != command) {
        this->mAspectState.mCommands[i] = command;
        commandChanged = true;
      }
    }
  }
  if (commandChanged)
    this->notifyExternalDisturbanceUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getAccelerations() const
{
  return getAccelerationsStatic();
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setAccelerationLowerLimit(
    size_t index, double acceleration)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setAccelerationLowerLimit, index);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mAccelerationLowerLimits[index], acceleration);
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getAccelerationLowerLimit(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getAccelerationLowerLimit, index);
    return 0.0;
  }

  return Base::mAspectProperties.mAccelerationLowerLimits[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setAccelerationLowerLimits(
    const Eigen::VectorXd& lowerLimits)
{
  if (static_cast<size_t>(lowerLimits.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setAccelerationLowerLimits, lowerLimits);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mAccelerationLowerLimits, lowerLimits);
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getAccelerationLowerLimits() const
{
  return Base::mAspectProperties.mAccelerationLowerLimits;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setAccelerationUpperLimit(
    size_t index, double acceleration)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setAccelerationUpperLimit, index) return;
  }

  GenericJoint_SET_IF_DIFFERENT(mAccelerationUpperLimits[index], acceleration);
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getAccelerationUpperLimit(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getAccelerationUpperLimit, index);
    return 0.0;
  }

  return Base::mAspectProperties.mAccelerationUpperLimits[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setAccelerationUpperLimits(
    const Eigen::VectorXd& upperLimits)
{
  if (static_cast<size_t>(upperLimits.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setAccelerationUpperLimits, upperLimits);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mAccelerationUpperLimits, upperLimits);
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getAccelerationUpperLimits() const
{
  return Base::mAspectProperties.mAccelerationUpperLimits;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::resetAccelerations()
{
  setAccelerationsStatic(Vector::Zero());
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setForce(size_t index, double force)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setForce, index);
    return;
  }

  bool changed = this->mAspectState.mForces[index] != force;
  this->mAspectState.mForces[index] = force;

  if (getActuatorTypeForValidIndex(index) == Joint::FORCE) {
    changed |= this->mAspectState.mCommands[index] != force;
    this->mAspectState.mCommands[index] = force;
  }

  if (changed)
    this->notifyExternalDisturbanceUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getForce(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getForce, index);
    return 0.0;
  }

  return this->mAspectState.mForces[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setForces(const Eigen::VectorXd& forces)
{
  if (static_cast<size_t>(forces.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setForces, forces);
    return;
  }

  bool changed = (this->mAspectState.mForces.array() != forces.array()).any();
  this->mAspectState.mForces = forces;

  for (std::size_t i = 0; i < getNumDofs(); ++i) {
    if (getActuatorTypeForValidIndex(i) == Joint::FORCE) {
      changed
          |= this->mAspectState.mCommands[i] != this->mAspectState.mForces[i];
      this->mAspectState.mCommands[i] = this->mAspectState.mForces[i];
    }
  }

  if (changed)
    this->notifyExternalDisturbanceUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getForces() const
{
  return this->mAspectState.mForces;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setForceLowerLimit(size_t index, double force)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setForceLowerLimit, index);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mForceLowerLimits[index], force);
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getForceLowerLimit(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getForceLowerLimit, index);
    return 0.0;
  }

  return Base::mAspectProperties.mForceLowerLimits[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setForceLowerLimits(
    const Eigen::VectorXd& lowerLimits)
{
  if (static_cast<size_t>(lowerLimits.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setForceLowerLimits, lowerLimits);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mForceLowerLimits, lowerLimits);
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getForceLowerLimits() const
{
  return Base::mAspectProperties.mForceLowerLimits;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setForceUpperLimit(size_t index, double force)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setForceUpperLimit, index);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mForceUpperLimits[index], force);
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getForceUpperLimit(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getForceUpperLimit, index);
    return 0.0;
  }

  return Base::mAspectProperties.mForceUpperLimits[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setForceUpperLimits(
    const Eigen::VectorXd& upperLimits)
{
  if (static_cast<size_t>(upperLimits.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setForceUpperLimits, upperLimits);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mForceUpperLimits, upperLimits);
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getForceUpperLimits() const
{
  return Base::mAspectProperties.mForceUpperLimits;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::resetForces()
{
  bool changed = (this->mAspectState.mForces.array() != 0.0).any();
  this->mAspectState.mForces.setZero();

  for (std::size_t i = 0; i < getNumDofs(); ++i) {
    if (getActuatorTypeForValidIndex(i) == Joint::FORCE) {
      changed |= this->mAspectState.mCommands[i] != 0.0;
      this->mAspectState.mCommands[i] = 0.0;
    }
  }

  if (changed)
    this->notifyExternalDisturbanceUpdated();
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setVelocityChange(
    size_t index, double velocityChange)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setVelocityChange, index);
    return;
  }

  this->mAspectState.mVelocityChanges[index] = velocityChange;
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getVelocityChange(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getVelocityChange, index);
    return 0.0;
  }

  return this->mAspectState.mVelocityChanges[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::resetVelocityChanges()
{
  this->mAspectState.mVelocityChanges.setZero();
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setConstraintImpulse(
    size_t index, double impulse)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setConstraintImpulse, index);
    return;
  }

  this->mAspectState.mConstraintImpulses[index] = impulse;
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getConstraintImpulse(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getConstraintImpulse, index);
    return 0.0;
  }

  return this->mAspectState.mConstraintImpulses[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::resetConstraintImpulses()
{
  this->mAspectState.mConstraintImpulses.setZero();
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::integratePositions(double dt)
{
  const Point& point = math::integratePosition<ConfigSpaceT>(
      math::toManifoldPoint<ConfigSpaceT>(getPositionsStatic()),
      getVelocitiesStatic(),
      dt);

  setPositionsStatic(math::toEuclideanPoint<ConfigSpaceT>(point));
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::integratePositions(
    const Eigen::VectorXd& q0,
    const Eigen::VectorXd& v,
    double dt,
    Eigen::VectorXd& result) const
{
  if (static_cast<std::size_t>(q0.size()) != getNumDofs()
      || static_cast<std::size_t>(v.size()) != getNumDofs()) {
    DART_ERROR(
        "q0's size [{}] and v's size [{}] must both equal the dof [{}] for "
        "Joint [{}].",
        q0.size(),
        v.size(),
        this->getNumDofs(),
        this->getName());
    DART_ASSERT(false);
    result = Eigen::VectorXd::Zero(getNumDofs());
    return;
  }

  detail::assertFiniteState(q0, this, "integratePositions", "q0");
  detail::assertFiniteState(v, this, "integratePositions", "v");
  detail::assertFiniteState(dt, this, "integratePositions", "dt");

  const EuclideanPoint q0Static = q0;
  const Vector vStatic = v;

  const Point& point = math::integratePosition<ConfigSpaceT>(
      math::toManifoldPoint<ConfigSpaceT>(q0Static), vStatic, dt);

  result = math::toEuclideanPoint<ConfigSpaceT>(point);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::integrateVelocities(double dt)
{
  setVelocitiesStaticInternal(
      math::integrateVelocity<ConfigSpaceT>(
          getVelocitiesStatic(), getAccelerationsStatic(), dt),
      false);
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getPositionDifferences(
    const Eigen::VectorXd& q2, const Eigen::VectorXd& q1) const
{
  if (static_cast<size_t>(q1.size()) != getNumDofs()
      || static_cast<size_t>(q2.size()) != getNumDofs()) {
    dterr << "[GenericJoint::getPositionsDifference] q1's size [" << q1.size()
          << "] or q2's size [" << q2.size() << "] must both equal the dof ["
          << this->getNumDofs() << "] for Joint [" << this->getName() << "].\n";
    DART_ASSERT(false);
    return Eigen::VectorXd::Zero(getNumDofs());
  }

  return getPositionDifferencesStatic(q2, q1);
}

//==============================================================================
template <class ConfigSpaceT>
typename ConfigSpaceT::Vector
GenericJoint<ConfigSpaceT>::getPositionDifferencesStatic(
    const Vector& q2, const Vector& q1) const
{
  return q2 - q1;
  // TODO(JS): Move this implementation to each configuration space classes.
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setSpringStiffness(size_t index, double k)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setSpringStiffness, index);
    return;
  }

  if (std::isnan(k) || k < 0.0) {
    DART_WARN(
        "[GenericJoint] Invalid spring stiffness ({}) set for joint [{}]. "
        "Spring stiffness must be non-negative; NaN and negative values are "
        "clamped to 0 (infinite stiffness is permitted).",
        k,
        this->getName());
    k = 0.0;
  }

  GenericJoint_SET_IF_DIFFERENT(mSpringStiffnesses[index], k);
  // Passive forces change rest state, not automatic-constraint eligibility.
  if (const auto skel = this->getSkeleton())
    skel->incrementDeactivationStateVersion();

  // dt * d + dt^2 * k is folded into the cached implicit articulated inertia
  // (updateInvProjArtInertiaImplicitDynamic), which is otherwise refreshed
  // only when the configuration changes.
  if (this->mChildBodyNode)
    this->mChildBodyNode->dirtyArticulatedInertia();
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getSpringStiffness(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getSpringStiffness, index);
    return 0.0;
  }

  return Base::mAspectProperties.mSpringStiffnesses[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setRestPosition(size_t index, double q0)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setRestPosition, index);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mRestPositions[index], q0);
  if (const auto skel = this->getSkeleton())
    skel->incrementDeactivationStateVersion();
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getRestPosition(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getRestPosition, index);
    return 0.0;
  }

  return Base::mAspectProperties.mRestPositions[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setRestPositions(
    const Eigen::VectorXd& restPositions)
{
  if (static_cast<size_t>(restPositions.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setRestPositions, restPositions);
    return;
  }

  GenericJoint_SET_IF_DIFFERENT(mRestPositions, restPositions);
  if (const auto skel = this->getSkeleton())
    skel->incrementDeactivationStateVersion();
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getRestPositions() const
{
  return Base::mAspectProperties.mRestPositions;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setDampingCoefficient(size_t index, double d)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setDampingCoefficient, index);
    return;
  }

  if (std::isnan(d) || d < 0.0) {
    DART_WARN(
        "[GenericJoint] Invalid damping coefficient ({}) set for joint [{}]. "
        "Damping must be non-negative; NaN and negative values are clamped to "
        "0 (negative damping adds energy; infinite damping is permitted).",
        d,
        this->getName());
    d = 0.0;
  }

  GenericJoint_SET_IF_DIFFERENT(mDampingCoefficients[index], d);
  if (const auto skel = this->getSkeleton())
    skel->incrementDeactivationStateVersion();

  // See setSpringStiffness(): the implicit damping term is cached too.
  if (this->mChildBodyNode)
    this->mChildBodyNode->dirtyArticulatedInertia();
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getDampingCoefficient(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getDampingCoefficient, index);
    return 0.0;
  }

  return Base::mAspectProperties.mDampingCoefficients[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setDampingCoefficients(
    const Eigen::VectorXd& dampingCoefficients)
{
  if (static_cast<size_t>(dampingCoefficients.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(
        setDampingCoefficients, dampingCoefficients);
    return;
  }

  for (auto i = 0u; i < getNumDofs(); ++i)
    setDampingCoefficient(i, dampingCoefficients[i]);
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getDampingCoefficients() const
{
  return Base::mAspectProperties.mDampingCoefficients;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setCoulombFriction(
    size_t index, double friction)
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(setCoulombFriction, index);
    return;
  }

  if (std::isnan(friction) || friction < 0.0) {
    DART_WARN(
        "[GenericJoint] Invalid Coulomb friction ({}) set for joint [{}]. "
        "Friction must be non-negative; NaN and negative values are clamped to "
        "0 (infinite friction locks the joint and is permitted).",
        friction,
        this->getName());
    friction = 0.0;
  }

  const bool hadFriction = Base::mAspectProperties.mFrictions[index] > 0.0;
  const bool hasFriction = friction > 0.0;
  GenericJoint_SET_IF_DIFFERENT(mFrictions[index], friction);
  if (hadFriction != hasFriction) {
    // Turning friction on or off changes which joints get a friction
    // constraint, so every solver rescans its joints.
    if (hasFriction)
      ++Joint::mNumNonzeroCoulombFrictionDofs;
    else
      --Joint::mNumNonzeroCoulombFrictionDofs;
    this->notifyAutomaticConstraintPropertiesUpdated();
  } else if (const auto skel = this->getSkeleton()) {
    // Any other change only moves the constraint's bounds: wake resting
    // bodies without a rescan.
    skel->incrementDeactivationStateVersion();
  }
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::getCoulombFriction(size_t index) const
{
  if (index >= getNumDofs()) {
    GenericJoint_REPORT_OUT_OF_RANGE(getCoulombFriction, index);
    return 0.0;
  }

  return Base::mAspectProperties.mFrictions[index];
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setFrictions(const Eigen::VectorXd& frictions)
{
  if (static_cast<size_t>(frictions.size()) != getNumDofs()) {
    GenericJoint_REPORT_DIM_MISMATCH(setFrictions, frictions);
    return;
  }

  for (auto i = 0u; i < getNumDofs(); ++i)
    setCoulombFriction(i, frictions[i]);
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getFrictions() const
{
  return Base::mAspectProperties.mFrictions;
}

//==============================================================================
template <class ConfigSpaceT>
double GenericJoint<ConfigSpaceT>::computePotentialEnergy() const
{
  // Spring energy
  Vector displacement
      = getPositionsStatic() - Base::mAspectProperties.mRestPositions;

  const double pe = 0.5
                    * displacement.dot(
                        Base::mAspectProperties.mSpringStiffnesses.cwiseProduct(
                            displacement));

  return pe;
}

//==============================================================================
template <class ConfigSpaceT>
const math::Jacobian GenericJoint<ConfigSpaceT>::getRelativeJacobian() const
{
  return getRelativeJacobianStatic();
}

//==============================================================================
template <class ConfigSpaceT>
const typename GenericJoint<ConfigSpaceT>::JacobianMatrix&
GenericJoint<ConfigSpaceT>::getRelativeJacobianStatic() const
{
  if (this->mIsRelativeJacobianDirty) {
    this->updateRelativeJacobian(false);
    this->mIsRelativeJacobianDirty = false;
  }

  return mJacobian;
}

//==============================================================================
template <class ConfigSpaceT>
math::Jacobian GenericJoint<ConfigSpaceT>::getRelativeJacobian(
    const Eigen::VectorXd& positions) const
{
  return getRelativeJacobianStatic(positions);
}

//==============================================================================
template <class ConfigSpaceT>
const math::Jacobian GenericJoint<ConfigSpaceT>::getRelativeJacobianTimeDeriv()
    const
{
  return getRelativeJacobianTimeDerivStatic();
}

//==============================================================================
template <class ConfigSpaceT>
const typename GenericJoint<ConfigSpaceT>::JacobianMatrix&
GenericJoint<ConfigSpaceT>::getRelativeJacobianTimeDerivStatic() const
{
  if (this->mIsRelativeJacobianTimeDerivDirty) {
    this->updateRelativeJacobianTimeDeriv();
    this->mIsRelativeJacobianTimeDerivDirty = false;
  }

  return mJacobianDeriv;
}

//==============================================================================
template <class ConfigSpaceT>
GenericJoint<ConfigSpaceT>::GenericJoint(const Properties& properties)
  : mJacobian(JacobianMatrix::Zero()),
    mJacobianDeriv(JacobianMatrix::Zero()),
    mInvProjArtInertia(Matrix::Zero()),
    mInvProjArtInertiaImplicit(Matrix::Zero()),
    mTotalForce(Vector::Zero()),
    mTotalImpulse(Vector::Zero())
{
  for (auto i = 0u; i < NumDofs; ++i)
    mDofs[i] = this->createDofPointer(i);

  // Joint and GenericJoint Aspects must be created by the most derived class.
  this->mAspectState.mPositions = properties.mInitialPositions;
  this->mAspectState.mVelocities = properties.mInitialVelocities;
  for (auto i = 0u; i < NumDofs; ++i) {
    if (!std::isnan(properties.mFrictions[i]) && properties.mFrictions[i] > 0.0)
      ++Joint::mNumNonzeroCoulombFrictionDofs;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::registerDofs()
{
  const SkeletonPtr& skel = this->mChildBodyNode->getSkeleton();
  for (auto i = 0u; i < NumDofs; ++i) {
    Base::mAspectProperties.mDofNames[i]
        = skel->mNameMgrForDofs.issueNewNameAndAdd(
            mDofs[i]->getName(), mDofs[i]);
  }
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::Vector6d GenericJoint<ConfigSpaceT>::getBodyConstraintWrench() const
{
  DART_ASSERT(this->mChildBodyNode);
  return this->mChildBodyNode->getBodyForce()
         - this->getRelativeJacobianStatic() * this->mAspectState.mForces;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateRelativeSpatialVelocity() const
{
  this->mSpatialVelocity
      = this->getRelativeJacobianStatic() * this->getVelocitiesStatic();
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateRelativeSpatialAcceleration() const
{
  this->mSpatialAcceleration = this->getRelativePrimaryAcceleration()
                               + this->getRelativeJacobianTimeDerivStatic()
                                     * this->getVelocitiesStatic();
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateRelativePrimaryAcceleration() const
{
  this->mPrimaryAcceleration
      = this->getRelativeJacobianStatic() * this->getAccelerationsStatic();
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addVelocityTo(Eigen::Vector6d& vel)
{
  // Add joint velocity to _vel
  vel.noalias() += getRelativeJacobianStatic() * getVelocitiesStatic();

  // Verification
  DART_ASSERT(!math::isNan(vel));
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::setPartialAccelerationTo(
    Eigen::Vector6d& partialAcceleration, const Eigen::Vector6d& childVelocity)
{
  // ad(V, S * dq) + dS * dq
  partialAcceleration
      = math::ad(
            childVelocity, getRelativeJacobianStatic() * getVelocitiesStatic())
        + getRelativeJacobianTimeDerivStatic() * getVelocitiesStatic();
  // Verification
  DART_ASSERT(!math::isNan(partialAcceleration));
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addAccelerationTo(Eigen::Vector6d& acc)
{
  // Add joint acceleration to _acc
  acc.noalias() += getRelativeJacobianStatic() * getAccelerationsStatic();

  // Verification
  DART_ASSERT(!math::isNan(acc));
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addVelocityChangeTo(
    Eigen::Vector6d& velocityChange)
{
  // Add joint velocity change to velocityChange
  velocityChange.noalias()
      += getRelativeJacobianStatic() * this->mAspectState.mVelocityChanges;

  // Verification
  DART_ASSERT(!math::isNan(velocityChange));
}

//==============================================================================
template <class ConfigSpaceT>
const typename GenericJoint<ConfigSpaceT>::Matrix&
GenericJoint<ConfigSpaceT>::getInvProjArtInertia() const
{
  Joint::updateArticulatedInertia();

  return mInvProjArtInertia;
}

//==============================================================================
template <class ConfigSpaceT>
const typename GenericJoint<ConfigSpaceT>::Matrix&
GenericJoint<ConfigSpaceT>::getInvProjArtInertiaImplicit() const
{
  Joint::updateArticulatedInertia();

  return mInvProjArtInertiaImplicit;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addChildArtInertiaTo(
    Eigen::Matrix6d& parentArtInertia, const Eigen::Matrix6d& childArtInertia)
{
  switch (Joint::mAspectProperties.mActuatorType) {
    case Joint::FORCE:
    case Joint::PASSIVE:
    case Joint::SERVO:
    case Joint::MIMIC:
      addChildArtInertiaToDynamic(parentArtInertia, childArtInertia);
      break;
    case Joint::ACCELERATION:
    case Joint::VELOCITY:
    case Joint::LOCKED:
      addChildArtInertiaToKinematic(parentArtInertia, childArtInertia);
      break;
    default:
      GenericJoint_REPORT_UNSUPPORTED_ACTUATOR(addChildArtInertiaTo);
      break;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addChildArtInertiaToDynamic(
    Eigen::Matrix6d& parentArtInertia, const Eigen::Matrix6d& childArtInertia)
{
  // Child body's articulated inertia
  JacobianMatrix AIS = childArtInertia * getRelativeJacobianStatic();
  Eigen::Matrix6d PI = childArtInertia;
  PI.noalias() -= AIS * mInvProjArtInertia * AIS.transpose();
  if (!PI.allFinite()) {
    dtwarn << "[GenericJoint::addChildArtInertiaToDynamic] Non-finite "
              "articulated inertia detected for joint ["
           << this->getName() << "]. Skipping child inertia contribution.\n";
    return;
  }

  // Add child body's articulated inertia to parent body's articulated inertia.
  // Note that mT should be updated.
  const Eigen::Matrix6d contribution
      = math::transformInertia(this->getRelativeTransform().inverse(), PI);
  if (!contribution.allFinite()) {
    dtwarn << "[GenericJoint::addChildArtInertiaToDynamic] Non-finite "
              "transformed inertia detected for joint ["
           << this->getName() << "]. Skipping child inertia contribution.\n";
    return;
  }
  parentArtInertia += contribution;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addChildArtInertiaToKinematic(
    Eigen::Matrix6d& parentArtInertia, const Eigen::Matrix6d& childArtInertia)
{
  // Add child body's articulated inertia to parent body's articulated inertia.
  // Note that mT should be updated.
  const Eigen::Matrix6d contribution = math::transformInertia(
      this->getRelativeTransform().inverse(), childArtInertia);
  if (!contribution.allFinite()) {
    dtwarn << "[GenericJoint::addChildArtInertiaToKinematic] Non-finite "
              "transformed inertia detected for joint ["
           << this->getName() << "]. Skipping child inertia contribution.\n";
    return;
  }
  parentArtInertia += contribution;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addChildArtInertiaImplicitTo(
    Eigen::Matrix6d& parentArtInertia, const Eigen::Matrix6d& childArtInertia)
{
  switch (Joint::mAspectProperties.mActuatorType) {
    case Joint::FORCE:
    case Joint::PASSIVE:
    case Joint::SERVO:
    case Joint::MIMIC:
      addChildArtInertiaImplicitToDynamic(parentArtInertia, childArtInertia);
      break;
    case Joint::ACCELERATION:
    case Joint::VELOCITY:
    case Joint::LOCKED:
      addChildArtInertiaImplicitToKinematic(parentArtInertia, childArtInertia);
      break;
    default:
      GenericJoint_REPORT_UNSUPPORTED_ACTUATOR(addChildArtInertiaImplicitTo);
      break;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addChildArtInertiaImplicitToDynamic(
    Eigen::Matrix6d& parentArtInertia, const Eigen::Matrix6d& childArtInertia)
{
  // Child body's articulated inertia
  JacobianMatrix AIS = childArtInertia * getRelativeJacobianStatic();
  Eigen::Matrix6d PI = childArtInertia;
  PI.noalias() -= AIS * mInvProjArtInertiaImplicit * AIS.transpose();
  if (!PI.allFinite()) {
    dtwarn << "[GenericJoint::addChildArtInertiaImplicitToDynamic] Non-finite "
              "articulated inertia detected for joint ["
           << this->getName() << "]. Skipping child inertia contribution.\n";
    return;
  }

  // Add child body's articulated inertia to parent body's articulated inertia.
  // Note that mT should be updated.
  const Eigen::Matrix6d contribution
      = math::transformInertia(this->getRelativeTransform().inverse(), PI);
  if (!contribution.allFinite()) {
    dtwarn << "[GenericJoint::addChildArtInertiaImplicitToDynamic] Non-finite "
              "transformed inertia detected for joint ["
           << this->getName() << "]. Skipping child inertia contribution.\n";
    return;
  }
  parentArtInertia += contribution;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addChildArtInertiaImplicitToKinematic(
    Eigen::Matrix6d& parentArtInertia, const Eigen::Matrix6d& childArtInertia)
{
  // Add child body's articulated inertia to parent body's articulated inertia.
  // Note that mT should be updated.
  const Eigen::Matrix6d contribution = math::transformInertia(
      this->getRelativeTransform().inverse(), childArtInertia);
  if (!contribution.allFinite()) {
    dtwarn
        << "[GenericJoint::addChildArtInertiaImplicitToKinematic] Non-finite "
           "transformed inertia detected for joint ["
        << this->getName() << "]. Skipping child inertia contribution.\n";
    return;
  }
  parentArtInertia += contribution;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateInvProjArtInertia(
    const Eigen::Matrix6d& artInertia)
{
  switch (Joint::mAspectProperties.mActuatorType) {
    case Joint::FORCE:
    case Joint::PASSIVE:
    case Joint::SERVO:
    case Joint::MIMIC:
      updateInvProjArtInertiaDynamic(artInertia);
      break;
    case Joint::ACCELERATION:
    case Joint::VELOCITY:
    case Joint::LOCKED:
      updateInvProjArtInertiaKinematic(artInertia);
      break;
    default:
      GenericJoint_REPORT_UNSUPPORTED_ACTUATOR(updateInvProjArtInertia);
      break;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateInvProjArtInertiaDynamic(
    const Eigen::Matrix6d& artInertia)
{
  // Projected articulated inertia
  const JacobianMatrix& Jacobian = getRelativeJacobianStatic();
  const Matrix projAI = Jacobian.transpose() * artInertia * Jacobian;

  // Inversion of projected articulated inertia
  mInvProjArtInertia = math::inverse<ConfigSpaceT>(projAI);

  // Verification
  if (!mInvProjArtInertia.allFinite()) {
    dtwarn
        << "[GenericJoint::updateInvProjArtInertiaDynamic] Non-finite inverse "
           "projected articulated inertia detected for joint ["
        << this->getName()
        << "]. Setting inverse inertia to zero to avoid instability.\n";
    mInvProjArtInertia.setZero();
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateInvProjArtInertiaKinematic(
    const Eigen::Matrix6d& /*_artInertia*/)
{
  // Do nothing
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateInvProjArtInertiaImplicit(
    const Eigen::Matrix6d& artInertia, double timeStep)
{
  switch (Joint::mAspectProperties.mActuatorType) {
    case Joint::FORCE:
    case Joint::PASSIVE:
    case Joint::SERVO:
    case Joint::MIMIC:
      updateInvProjArtInertiaImplicitDynamic(artInertia, timeStep);
      break;
    case Joint::ACCELERATION:
    case Joint::VELOCITY:
    case Joint::LOCKED:
      updateInvProjArtInertiaImplicitKinematic(artInertia, timeStep);
      break;
    default:
      GenericJoint_REPORT_UNSUPPORTED_ACTUATOR(updateInvProjArtInertiaImplicit);
      break;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateInvProjArtInertiaImplicitDynamic(
    const Eigen::Matrix6d& artInertia, double timeStep)
{
  if constexpr (NumDofs > 4) {
    // Smaller joints use a closed-form inverse. For positive inertia, adding
    // zero cannot change a projected diagonal entry from -0.0 to +0.0.
    // Keep the full path if the squared timestep overflows (infinity * zero).
    if ((Base::mAspectProperties.mDampingCoefficients.array() == 0.0).all()
        && (Base::mAspectProperties.mSpringStiffnesses.array() == 0.0).all()
        && std::isfinite(timeStep * timeStep)
        && this->isChildArticulatedInertia(artInertia)) {
      mInvProjArtInertiaImplicit = mInvProjArtInertia;
      return;
    }
  }

  // Projected articulated inertia
  const JacobianMatrix& Jacobian = getRelativeJacobianStatic();
  Matrix projAI = Jacobian.transpose() * artInertia * Jacobian;

  // Add additional inertia for implicit damping and spring force
  projAI += (timeStep * Base::mAspectProperties.mDampingCoefficients
             + timeStep * timeStep * Base::mAspectProperties.mSpringStiffnesses)
                .asDiagonal();

  // Inversion of projected articulated inertia
  mInvProjArtInertiaImplicit = math::inverse<ConfigSpaceT>(projAI);

  // Verification
  if (math::isNan(mInvProjArtInertiaImplicit)
      || math::isInf(mInvProjArtInertiaImplicit)) {
    dtwarn << "[GenericJoint::updateInvProjArtInertiaImplicitDynamic] "
              "Non-finite inverse projected articulated inertia detected for "
              "joint ["
           << this->getName()
           << "]. Setting inverse inertia to zero to avoid instability.\n";
    mInvProjArtInertiaImplicit.setZero();
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateInvProjArtInertiaImplicitKinematic(
    const Eigen::Matrix6d& /*artInertia*/, double /*timeStep*/)
{
  // Do nothing
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addChildBiasForceTo(
    Eigen::Vector6d& parentBiasForce,
    const Eigen::Matrix6d& childArtInertia,
    const Eigen::Vector6d& childBiasForce,
    const Eigen::Vector6d& childPartialAcc)
{
  switch (Joint::mAspectProperties.mActuatorType) {
    case Joint::FORCE:
    case Joint::PASSIVE:
    case Joint::SERVO:
    case Joint::MIMIC:
      addChildBiasForceToDynamic(
          parentBiasForce, childArtInertia, childBiasForce, childPartialAcc);
      break;
    case Joint::ACCELERATION:
    case Joint::VELOCITY:
    case Joint::LOCKED:
      addChildBiasForceToKinematic(
          parentBiasForce, childArtInertia, childBiasForce, childPartialAcc);
      break;
    default:
      GenericJoint_REPORT_UNSUPPORTED_ACTUATOR(addChildBiasForceTo);
      break;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addChildBiasForceToDynamic(
    Eigen::Vector6d& parentBiasForce,
    const Eigen::Matrix6d& childArtInertia,
    const Eigen::Vector6d& childBiasForce,
    const Eigen::Vector6d& childPartialAcc)
{
  // Compute beta
  const Eigen::Vector6d beta
      = childBiasForce
        + childArtInertia
              * (childPartialAcc
                 + getRelativeJacobianStatic() * getInvProjArtInertiaImplicit()
                       * mTotalForce);

  //    Eigen::Vector6d beta
  //        = _childBiasForce;
  //    beta.noalias() += _childArtInertia * _childPartialAcc;
  //    beta.noalias() += _childArtInertia *  mJacobian *
  //    getInvProjArtInertiaImplicit() * mTotalForce;

  // Verification
  if (!beta.allFinite()) {
    dtwarn << "[GenericJoint::addChildBiasForceToDynamic] Non-finite bias "
              "force detected for joint ["
           << this->getName() << "]. Skipping bias force contribution.\n";
    return;
  }

  // Add child body's bias force to parent body's bias force. Note that mT
  // should be updated.
  parentBiasForce += math::dAdInvT(this->getRelativeTransform(), beta);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addChildBiasForceToKinematic(
    Eigen::Vector6d& _parentBiasForce,
    const Eigen::Matrix6d& childArtInertia,
    const Eigen::Vector6d& childBiasForce,
    const Eigen::Vector6d& childPartialAcc)
{
  // Compute beta
  const Eigen::Vector6d beta
      = childBiasForce
        + childArtInertia
              * (childPartialAcc
                 + getRelativeJacobianStatic() * getAccelerationsStatic());

  //    Eigen::Vector6d beta
  //        = _childBiasForce;
  //    beta.noalias() += _childArtInertia * _childPartialAcc;
  //    beta.noalias() += _childArtInertia *  mJacobian *
  //    getInvProjArtInertiaImplicit() * mTotalForce;

  // Verification
  DART_ASSERT(!math::isNan(beta));

  // Add child body's bias force to parent body's bias force. Note that mT
  // should be updated.
  _parentBiasForce += math::dAdInvT(this->getRelativeTransform(), beta);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addChildBiasImpulseTo(
    Eigen::Vector6d& parentBiasImpulse,
    const Eigen::Matrix6d& childArtInertia,
    const Eigen::Vector6d& childBiasImpulse)
{
  switch (Joint::mAspectProperties.mActuatorType) {
    case Joint::FORCE:
    case Joint::PASSIVE:
    case Joint::SERVO:
    case Joint::MIMIC:
      addChildBiasImpulseToDynamic(
          parentBiasImpulse, childArtInertia, childBiasImpulse);
      break;
    case Joint::ACCELERATION:
    case Joint::VELOCITY:
    case Joint::LOCKED:
      addChildBiasImpulseToKinematic(
          parentBiasImpulse, childArtInertia, childBiasImpulse);
      break;
    default:
      GenericJoint_REPORT_UNSUPPORTED_ACTUATOR(addChildBiasImpulseTo);
      break;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addChildBiasImpulseToDynamic(
    Eigen::Vector6d& _parentBiasImpulse,
    const Eigen::Matrix6d& childArtInertia,
    const Eigen::Vector6d& childBiasImpulse)
{
  // Compute beta
  const Eigen::Vector6d beta = childBiasImpulse
                               + childArtInertia * getRelativeJacobianStatic()
                                     * getInvProjArtInertia() * mTotalImpulse;

  // Verification
  DART_ASSERT(!math::isNan(beta));

  // Add child body's bias force to parent body's bias force. Note that mT
  // should be updated.
  _parentBiasImpulse += math::dAdInvT(this->getRelativeTransform(), beta);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addChildBiasImpulseToKinematic(
    Eigen::Vector6d& parentBiasImpulse,
    const Eigen::Matrix6d& /*childArtInertia*/,
    const Eigen::Vector6d& childBiasImpulse)
{
  // Add child body's bias force to parent body's bias force. Note that mT
  // should be updated.
  parentBiasImpulse
      += math::dAdInvT(this->getRelativeTransform(), childBiasImpulse);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateTotalForce(
    const Eigen::Vector6d& bodyForce, double timeStep)
{
  DART_ASSERT(timeStep > 0.0);

  switch (Joint::mAspectProperties.mActuatorType) {
    case Joint::FORCE:
      this->mAspectState.mForces = this->mAspectState.mCommands;
      updateTotalForceDynamic(bodyForce, timeStep);
      break;
    case Joint::PASSIVE:
    case Joint::SERVO:
    case Joint::MIMIC:
      this->mAspectState.mForces.setZero();
      updateTotalForceDynamic(bodyForce, timeStep);
      break;
    case Joint::ACCELERATION:
      setAccelerationsStatic(this->mAspectState.mCommands);
      updateTotalForceKinematic(bodyForce, timeStep);
      break;
    case Joint::VELOCITY:
      setAccelerationsStatic(
          (this->mAspectState.mCommands - getVelocitiesStatic()) / timeStep);
      updateTotalForceKinematic(bodyForce, timeStep);
      break;
    case Joint::LOCKED:
      setVelocitiesStaticInternal(Vector::Zero(), false);
      setAccelerationsStatic(Vector::Zero());
      updateTotalForceKinematic(bodyForce, timeStep);
      break;
    default:
      GenericJoint_REPORT_UNSUPPORTED_ACTUATOR(updateTotalForce);
      break;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateTotalForceDynamic(
    const Eigen::Vector6d& bodyForce, double timeStep)
{
  // Spring force
  const Vector springForce
      = -Base::mAspectProperties.mSpringStiffnesses.cwiseProduct(
          getPositionsStatic() - Base::mAspectProperties.mRestPositions
          + getVelocitiesStatic() * timeStep);

  // Damping force
  const Vector dampingForce
      = -Base::mAspectProperties.mDampingCoefficients.cwiseProduct(
          getVelocitiesStatic());

  //
  mTotalForce = this->mAspectState.mForces + springForce + dampingForce
                - getRelativeJacobianStatic().transpose() * bodyForce;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateTotalForceKinematic(
    const Eigen::Vector6d& /*bodyForce*/, double /*timeStep*/)
{
  // Do nothing
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateTotalImpulse(
    const Eigen::Vector6d& bodyImpulse)
{
  switch (Joint::mAspectProperties.mActuatorType) {
    case Joint::FORCE:
    case Joint::PASSIVE:
    case Joint::SERVO:
    case Joint::MIMIC:
      updateTotalImpulseDynamic(bodyImpulse);
      break;
    case Joint::ACCELERATION:
    case Joint::VELOCITY:
    case Joint::LOCKED:
      updateTotalImpulseKinematic(bodyImpulse);
      break;
    default:
      GenericJoint_REPORT_UNSUPPORTED_ACTUATOR(updateTotalImpulse);
      break;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateTotalImpulseDynamic(
    const Eigen::Vector6d& bodyImpulse)
{
  //
  mTotalImpulse = this->mAspectState.mConstraintImpulses
                  - getRelativeJacobianStatic().transpose() * bodyImpulse;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateTotalImpulseKinematic(
    const Eigen::Vector6d& /*bodyImpulse*/)
{
  // Do nothing
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::resetTotalImpulses()
{
  mTotalImpulse.setZero();
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateAcceleration(
    const Eigen::Matrix6d& artInertia, const Eigen::Vector6d& spatialAcc)
{
  switch (Joint::mAspectProperties.mActuatorType) {
    case Joint::FORCE:
    case Joint::PASSIVE:
    case Joint::SERVO:
    case Joint::MIMIC:
      updateAccelerationDynamic(artInertia, spatialAcc);
      break;
    case Joint::ACCELERATION:
    case Joint::VELOCITY:
    case Joint::LOCKED:
      updateAccelerationKinematic(artInertia, spatialAcc);
      break;
    default:
      GenericJoint_REPORT_UNSUPPORTED_ACTUATOR(updateAcceleration);
      break;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateAccelerationDynamic(
    const Eigen::Matrix6d& artInertia, const Eigen::Vector6d& spatialAcc)
{
  // Compute accelerations first.
  Vector accelerations
      = getInvProjArtInertiaImplicit()
        * (mTotalForce
           - getRelativeJacobianStatic().transpose() * artInertia
                 * math::AdInvT(this->getRelativeTransform(), spatialAcc));

  // Guard: check for non-finite values BEFORE calling the setter, which
  // asserts finiteness (assertFiniteState) under debug builds.
  if (!accelerations.allFinite()) {
    dtwarn << "[GenericJoint::updateAccelerationDynamic] Non-finite joint "
              "accelerations detected for joint ["
           << this->getName()
           << "]. Setting accelerations to zero to avoid instability.\n";
    accelerations.setZero();
  }

  setAccelerationsStatic(accelerations);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateAccelerationKinematic(
    const Eigen::Matrix6d& /*artInertia*/,
    const Eigen::Vector6d& /*spatialAcc*/)
{
  // Do nothing
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateVelocityChange(
    const Eigen::Matrix6d& artInertia, const Eigen::Vector6d& velocityChange)
{
  switch (Joint::mAspectProperties.mActuatorType) {
    case Joint::FORCE:
    case Joint::PASSIVE:
    case Joint::SERVO:
    case Joint::MIMIC:
      updateVelocityChangeDynamic(artInertia, velocityChange);
      break;
    case Joint::ACCELERATION:
    case Joint::VELOCITY:
    case Joint::LOCKED:
      updateVelocityChangeKinematic(artInertia, velocityChange);
      break;
    default:
      GenericJoint_REPORT_UNSUPPORTED_ACTUATOR(updateVelocityChange);
      break;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateVelocityChangeDynamic(
    const Eigen::Matrix6d& artInertia, const Eigen::Vector6d& velocityChange)
{
  //
  this->mAspectState.mVelocityChanges
      = getInvProjArtInertia()
        * (mTotalImpulse
           - getRelativeJacobianStatic().transpose() * artInertia
                 * math::AdInvT(this->getRelativeTransform(), velocityChange));

  // Verification
  DART_ASSERT(!math::isNan(this->mAspectState.mVelocityChanges));
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateVelocityChangeKinematic(
    const Eigen::Matrix6d& /*artInertia*/,
    const Eigen::Vector6d& /*velocityChange*/)
{
  // Do nothing
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateForceID(
    const Eigen::Vector6d& bodyForce,
    double timeStep,
    bool withDampingForces,
    bool withSpringForces)
{
  this->mAspectState.mForces
      = getRelativeJacobianStatic().transpose() * bodyForce;

  // Implicit damping force:
  //   tau_d = -Kd * dq - Kd * h * ddq
  if (withDampingForces) {
    const typename ConfigSpaceT::Vector dampingForces
        = -Base::mAspectProperties.mDampingCoefficients.cwiseProduct(
            getVelocitiesStatic() + getAccelerationsStatic() * timeStep);
    this->mAspectState.mForces -= dampingForces;
  }

  // Implicit spring force:
  //   tau_s = -Kp * (q - q0) - Kp * h * dq - Kp * h^2 * ddq
  if (withSpringForces) {
    const typename ConfigSpaceT::Vector springForces
        = -Base::mAspectProperties.mSpringStiffnesses.cwiseProduct(
            getPositionsStatic() - Base::mAspectProperties.mRestPositions
            + getVelocitiesStatic() * timeStep
            + getAccelerationsStatic() * timeStep * timeStep);
    this->mAspectState.mForces -= springForces;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateForceFD(
    const Eigen::Vector6d& bodyForce,
    double timeStep,
    bool withDampingForces,
    bool withSpringForces)
{
  switch (Joint::mAspectProperties.mActuatorType) {
    case Joint::FORCE:
    case Joint::PASSIVE:
    case Joint::SERVO:
    case Joint::MIMIC:
      break;
    case Joint::ACCELERATION:
    case Joint::VELOCITY:
    case Joint::LOCKED:
      updateForceID(bodyForce, timeStep, withDampingForces, withSpringForces);
      break;
    default:
      GenericJoint_REPORT_UNSUPPORTED_ACTUATOR(updateForceFD);
      break;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateImpulseID(
    const Eigen::Vector6d& bodyImpulse)
{
  this->mAspectState.mImpulses
      = getRelativeJacobianStatic().transpose() * bodyImpulse;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateImpulseFD(
    const Eigen::Vector6d& bodyImpulse)
{
  switch (Joint::mAspectProperties.mActuatorType) {
    case Joint::FORCE:
    case Joint::PASSIVE:
    case Joint::SERVO:
    case Joint::MIMIC:
      break;
    case Joint::ACCELERATION:
    case Joint::VELOCITY:
    case Joint::LOCKED:
      updateImpulseID(bodyImpulse);
      break;
    default:
      GenericJoint_REPORT_UNSUPPORTED_ACTUATOR(updateImpulseFD);
      break;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateConstrainedTerms(double timeStep)
{
  switch (Joint::mAspectProperties.mActuatorType) {
    case Joint::FORCE:
    case Joint::PASSIVE:
    case Joint::SERVO:
    case Joint::MIMIC:
      updateConstrainedTermsDynamic(timeStep);
      break;
    case Joint::ACCELERATION:
    case Joint::VELOCITY:
    case Joint::LOCKED:
      updateConstrainedTermsKinematic(timeStep);
      break;
    default:
      GenericJoint_REPORT_UNSUPPORTED_ACTUATOR(updateConstrainedTerms);
      break;
  }
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateConstrainedTermsDynamic(double timeStep)
{
  const double invTimeStep = 1.0 / timeStep;

  setVelocitiesStaticInternal(
      getVelocitiesStatic() + this->mAspectState.mVelocityChanges, false);
  setAccelerationsStatic(
      getAccelerationsStatic()
      + this->mAspectState.mVelocityChanges * invTimeStep);
  this->mAspectState.mForces.noalias()
      += this->mAspectState.mImpulses * invTimeStep;
  // Note: As long as this is only called from BodyNode::updateConstrainedTerms
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateConstrainedTermsKinematic(
    double timeStep)
{
  this->mAspectState.mForces.noalias()
      += this->mAspectState.mImpulses / timeStep;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addChildBiasForceForInvMassMatrix(
    Eigen::Vector6d& parentBiasForce,
    const Eigen::Matrix6d& childArtInertia,
    const Eigen::Vector6d& childBiasForce)
{
  // Compute beta
  Eigen::Vector6d beta = childBiasForce;
  beta.noalias() += childArtInertia * getRelativeJacobianStatic()
                    * getInvProjArtInertia() * mInvM_a;

  // Verification
  DART_ASSERT(!math::isNan(beta));

  // Add child body's bias force to parent body's bias force. Note that mT
  // should be updated.
  parentBiasForce += math::dAdInvT(this->getRelativeTransform(), beta);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addChildBiasForceForInvAugMassMatrix(
    Eigen::Vector6d& parentBiasForce,
    const Eigen::Matrix6d& childArtInertia,
    const Eigen::Vector6d& childBiasForce)
{
  // Compute beta
  Eigen::Vector6d beta = childBiasForce;
  beta.noalias() += childArtInertia * getRelativeJacobianStatic()
                    * getInvProjArtInertiaImplicit() * mInvM_a;

  // Verification
  DART_ASSERT(!math::isNan(beta));

  // Add child body's bias force to parent body's bias force. Note that mT
  // should be updated.
  parentBiasForce += math::dAdInvT(this->getRelativeTransform(), beta);
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::updateTotalForceForInvMassMatrix(
    const Eigen::Vector6d& bodyForce)
{
  // Compute alpha
  mInvM_a = this->mAspectState.mForces
            - getRelativeJacobianStatic().transpose() * bodyForce;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::getInvMassMatrixSegment(
    Eigen::MatrixXd& _invMassMat,
    const size_t _col,
    const Eigen::Matrix6d& artInertia,
    const Eigen::Vector6d& spatialAcc)
{
  //
  mInvMassMatrixSegment
      = getInvProjArtInertia()
        * (mInvM_a
           - getRelativeJacobianStatic().transpose() * artInertia
                 * math::AdInvT(this->getRelativeTransform(), spatialAcc));

  // Verification
  DART_ASSERT(!math::isNan(mInvMassMatrixSegment));

  // Index
  size_t iStart = mDofs[0]->mIndexInTree;

  // Assign
  _invMassMat.block<NumDofs, 1>(iStart, _col) = mInvMassMatrixSegment;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::getInvAugMassMatrixSegment(
    Eigen::MatrixXd& invMassMat,
    const size_t col,
    const Eigen::Matrix6d& artInertia,
    const Eigen::Vector6d& spatialAcc)
{
  //
  mInvMassMatrixSegment
      = getInvProjArtInertiaImplicit()
        * (mInvM_a
           - getRelativeJacobianStatic().transpose() * artInertia
                 * math::AdInvT(this->getRelativeTransform(), spatialAcc));

  // Verification
  DART_ASSERT(!math::isNan(mInvMassMatrixSegment));

  // Index
  size_t iStart = mDofs[0]->mIndexInTree;

  // Assign
  invMassMat.block<NumDofs, 1>(iStart, col) = mInvMassMatrixSegment;
}

//==============================================================================
template <class ConfigSpaceT>
void GenericJoint<ConfigSpaceT>::addInvMassMatrixSegmentTo(Eigen::Vector6d& acc)
{
  //
  acc += getRelativeJacobianStatic() * mInvMassMatrixSegment;
}

//==============================================================================
template <class ConfigSpaceT>
Eigen::VectorXd GenericJoint<ConfigSpaceT>::getSpatialToGeneralized(
    const Eigen::Vector6d& spatial)
{
  return getRelativeJacobianStatic().transpose() * spatial;
}

} // namespace dynamics
} // namespace dart

#endif // DART_DYNAMICS_DETAIL_GenericJoint_HPP_
