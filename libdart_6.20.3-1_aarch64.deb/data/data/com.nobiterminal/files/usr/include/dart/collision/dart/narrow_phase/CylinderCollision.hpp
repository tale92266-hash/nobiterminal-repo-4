/*
 * Copyright (c) 2011, The DART development contributors
 * All rights reserved.
 *
 * The list of contributors can be found at:
 *   https://github.com/dartsim/dart/blob/main/LICENSE
 *
 * This file is provided under the following "BSD-style" License:
 *   Redistribution and use in source and binary forms, with or
 *   without modification, are permitted provided that the following
 *   conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 *   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *   LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *   ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *   POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once

#include <dart/collision/dart/Export.hpp>
#include <dart/collision/dart/Types.hpp>
#include <dart/collision/dart/detail/Span.hpp>

#include <Eigen/Core>
#include <Eigen/Geometry>

namespace dart::collision::native {

class BoxShape;
class CapsuleShape;
class CylinderShape;
class PlaneShape;
class SphereShape;

struct DART_COLLISION_NATIVE_API CylinderPair
{
  const CylinderShape* shapeA;
  const CylinderShape* shapeB;
  Eigen::Isometry3d tfA;
  Eigen::Isometry3d tfB;
};

[[nodiscard]] DART_COLLISION_NATIVE_API bool collideCylinders(
    const CylinderShape& cyl1,
    const Eigen::Isometry3d& transform1,
    const CylinderShape& cyl2,
    const Eigen::Isometry3d& transform2,
    CollisionResult& result,
    const CollisionOption& option = CollisionOption());

DART_COLLISION_NATIVE_API void collideCylindersBatch(
    span<const CylinderPair> pairs,
    span<CollisionResult> results,
    const CollisionOption& option = CollisionOption());

[[nodiscard]] DART_COLLISION_NATIVE_API bool collideCylinderSphere(
    const CylinderShape& cylinder,
    const Eigen::Isometry3d& cylinderTransform,
    const SphereShape& sphere,
    const Eigen::Isometry3d& sphereTransform,
    CollisionResult& result,
    const CollisionOption& option = CollisionOption());

[[nodiscard]] DART_COLLISION_NATIVE_API bool collideCylinderBox(
    const CylinderShape& cylinder,
    const Eigen::Isometry3d& cylinderTransform,
    const BoxShape& box,
    const Eigen::Isometry3d& boxTransform,
    CollisionResult& result,
    const CollisionOption& option = CollisionOption());

[[nodiscard]] DART_COLLISION_NATIVE_API bool collideCylinderCapsule(
    const CylinderShape& cylinder,
    const Eigen::Isometry3d& cylinderTransform,
    const CapsuleShape& capsule,
    const Eigen::Isometry3d& capsuleTransform,
    CollisionResult& result,
    const CollisionOption& option = CollisionOption());

[[nodiscard]] DART_COLLISION_NATIVE_API bool collideCylinderPlane(
    const CylinderShape& cylinder,
    const Eigen::Isometry3d& cylinderTransform,
    const PlaneShape& plane,
    const Eigen::Isometry3d& planeTransform,
    CollisionResult& result,
    const CollisionOption& option = CollisionOption());

} // namespace dart::collision::native
