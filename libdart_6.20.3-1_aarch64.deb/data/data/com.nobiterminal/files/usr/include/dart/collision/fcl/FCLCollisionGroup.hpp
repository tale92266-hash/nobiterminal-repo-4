/*
 * Copyright (c) 2011, The DART development contributors
 * All rights reserved.
 *
 * The list of contributors can be found at:
 *   https://github.com/dartsim/dart/blob/main/LICENSE
 *
 * This file is provided under the following "BSD-style" License:
 *   Redistribution and use in source and binary forms, with or
 *   without modification, are permitted provided that the following
 *   conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 *   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *   LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *   ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *   POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef DART_COLLISION_FCL_FCLCOLLISIONGROUP_HPP_
#define DART_COLLISION_FCL_FCLCOLLISIONGROUP_HPP_

#include <dart/collision/CollisionGroup.hpp>
#include <dart/collision/fcl/BackwardCompatibility.hpp>

#include <vector>

namespace dart {
namespace collision {

class CollisionObject;
class FCLCollisionObjectUserData;

class FCLCollisionGroup : public CollisionGroup
{
public:
  friend class FCLCollisionDetector;

  using FCLCollisionManager
      = dart::collision::fcl::DynamicAABBTreeCollisionManager;

  /// Constructor
  FCLCollisionGroup(const CollisionDetectorPtr& collisionDetector);

  /// Destructor
  virtual ~FCLCollisionGroup() = default;

protected:
  using CollisionGroup::updateEngineData;

  // Documentation inherited
  void initializeEngineData() override;

  // Documentation inherited
  void addCollisionObjectToEngine(CollisionObject* object) override;

  // Documentation inherited
  void addCollisionObjectsToEngine(
      const std::vector<CollisionObject*>& collObjects) override;

  // Documentation inherited
  void removeCollisionObjectFromEngine(CollisionObject* object) override;

  // Documentation inherited
  void removeAllCollisionObjectsFromEngine() override;

  // Documentation inherited
  void updateCollisionGroupEngineData() override;

  /// Return FCL collision manager that is also a broad-phase algorithm
  FCLCollisionManager* getFCLCollisionManager();

  /// Return FCL collision manager that is also a broad-phase algorithm
  const FCLCollisionManager* getFCLCollisionManager() const;

  /// Return FCL objects registered with the finite broad-phase manager.
  const std::vector<fcl::CollisionObject*>& getFiniteFCLCollisionObjects()
      const;

  /// Return unbounded FCL objects that cannot be registered with the finite
  /// broad-phase manager.
  const std::vector<fcl::CollisionObject*>& getUnboundedFCLCollisionObjects()
      const;

protected:
  /// FCL broad-phase algorithm
  std::unique_ptr<FCLCollisionManager> mBroadPhaseAlg;

  /// Finite FCL objects registered with mBroadPhaseAlg.
  std::vector<fcl::CollisionObject*> mFiniteObjects;

  /// Unbounded FCL objects, such as halfspaces, handled outside mBroadPhaseAlg.
  std::vector<fcl::CollisionObject*> mUnboundedObjects;
};

} // namespace collision
} // namespace dart

#endif // DART_COLLISION_FCL_FCLCOLLISIONGROUP_HPP_
