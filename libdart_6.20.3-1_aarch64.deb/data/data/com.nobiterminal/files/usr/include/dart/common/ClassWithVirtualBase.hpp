/*
 * Copyright (c) 2011, The DART development contributors
 * All rights reserved.
 *
 * The list of contributors can be found at:
 *   https://github.com/dartsim/dart/blob/main/LICENSE
 *
 * This file is provided under the following "BSD-style" License:
 *   Redistribution and use in source and binary forms, with or
 *   without modification, are permitted provided that the following
 *   conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 *   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *   LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *   ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *   POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef DART_COMMON_CLASSWITHVIRTUALBASE_HPP_
#define DART_COMMON_CLASSWITHVIRTUALBASE_HPP_

// This macro is used to mark all the class that inherit
// virtually from another to avoid problems on MSVC
// See https://github.com/dartsim/dart/issues/1522
//
// C4250: 'class1' : inherits 'class2::member' via dominance
// This warning is expected with virtual inheritance and is safe to suppress.
// See https://github.com/gazebosim/gz-physics/pull/837
// C4324: 'struct' : structure was padded due to alignment specifier
// Expected for the alignas(Frame) classes (see #3447) and safe to suppress.
#if defined(_MSC_VER)
  #define DART_DECLARE_CLASS_WITH_VIRTUAL_BASE_BEGIN                           \
    __pragma(warning(push)) __pragma(warning(disable : 4250 4324))             \
        __pragma(vtordisp(push, 2))
  #define DART_DECLARE_CLASS_WITH_VIRTUAL_BASE_END                             \
    __pragma(vtordisp(pop)) __pragma(warning(pop))
#else
  #define DART_DECLARE_CLASS_WITH_VIRTUAL_BASE_BEGIN
  #define DART_DECLARE_CLASS_WITH_VIRTUAL_BASE_END
#endif

#endif // DART_COMMON_CLASSWITHVIRTUALBASE_HPP_
