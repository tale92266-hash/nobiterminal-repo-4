/*
 * Copyright (c) 2011, The DART development contributors
 * All rights reserved.
 *
 * The list of contributors can be found at:
 *   https://github.com/dartsim/dart/blob/main/LICENSE
 *
 * This file is provided under the following "BSD-style" License:
 *   Redistribution and use in source and binary forms, with or
 *   without modification, are permitted provided that the following
 *   conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 *   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *   LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *   ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *   POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once

#include <type_traits>

#include <cstddef>
#include <cstdint>
#include <cstring>

#if defined(DART_SIMD_FORCE_SCALAR)
  #undef DART_SIMD_AVX512
  #undef DART_SIMD_AVX512F
  #undef DART_SIMD_AVX512DQ
  #undef DART_SIMD_AVX512BW
  #undef DART_SIMD_AVX512VL
  #undef DART_SIMD_AVX512CD
  #undef DART_SIMD_AVX2
  #undef DART_SIMD_AVX
  #undef DART_SIMD_SSE42
  #undef DART_SIMD_NEON
  #undef DART_SIMD_FMA
  #define DART_SIMD_SCALAR 1
#elif defined(__AVX512F__) && defined(__AVX512DQ__)
  #define DART_SIMD_AVX512 1
  #define DART_SIMD_AVX512F 1
  #if defined(__AVX512DQ__)
    #define DART_SIMD_AVX512DQ 1
  #endif
  #if defined(__AVX512BW__)
    #define DART_SIMD_AVX512BW 1
  #endif
  #if defined(__AVX512VL__)
    #define DART_SIMD_AVX512VL 1
  #endif
  #if defined(__AVX512CD__)
    #define DART_SIMD_AVX512CD 1
  #endif
  #if defined(__AVX2__) && defined(__FMA__)
    #define DART_SIMD_AVX2 1
  #endif
  #if defined(__AVX__) || defined(DART_SIMD_AVX2)
    #define DART_SIMD_AVX 1
  #endif
  #if defined(__SSE4_2__) || defined(DART_SIMD_AVX)
    #define DART_SIMD_SSE42 1
  #endif
#elif defined(__AVX2__) && defined(__FMA__)
  #define DART_SIMD_AVX2 1
  #define DART_SIMD_AVX 1
  #define DART_SIMD_SSE42 1
#elif defined(__AVX__)
  #define DART_SIMD_AVX 1
  #define DART_SIMD_SSE42 1
#elif defined(__SSE4_2__)
  #define DART_SIMD_SSE42 1
#endif

// The SVE headers are installed for source parity, but the backend does not
// yet cover the full Vec operation API in this DART 6 C++17 port.
#if !defined(DART_SIMD_FORCE_SCALAR)
  #if defined(__ARM_NEON) || defined(__ARM_NEON__)
    #define DART_SIMD_NEON 1
  #endif
#endif

#if defined(__FMA__)
  #define DART_SIMD_FMA 1
#endif

#if !defined(DART_SIMD_SSE42) && !defined(DART_SIMD_NEON)                      \
    && !defined(DART_SIMD_SVE)
  #define DART_SIMD_SCALAR 1
#endif

#if defined(DART_SIMD_SSE42)
  #include <immintrin.h>
  #if defined(_MSC_VER)
    #include <intrin.h>
  #endif
#endif

#if defined(DART_SIMD_NEON)
  #include <arm_neon.h>
#endif

#if defined(__GNUC__) || defined(__clang__)
  #define DART_SIMD_INLINE __attribute__((always_inline)) inline
  #define DART_SIMD_ALIGNED(x) __attribute__((aligned(x)))
  #define DART_SIMD_PRAGMA_UNROLL _Pragma("GCC unroll 4")
#elif defined(_MSC_VER)
  #define DART_SIMD_INLINE __forceinline
  #define DART_SIMD_ALIGNED(x) __declspec(align(x))
  #define DART_SIMD_PRAGMA_UNROLL
#else
  #define DART_SIMD_INLINE inline
  #define DART_SIMD_ALIGNED(x)
  #define DART_SIMD_PRAGMA_UNROLL
#endif

namespace dart::simd {

#if defined(DART_SIMD_AVX512)
inline constexpr const char* backend_name
    = "AVX-512F"
  #if defined(DART_SIMD_AVX512DQ)
      "+DQ"
  #endif
  #if defined(DART_SIMD_AVX512BW)
      "+BW"
  #endif
  #if defined(DART_SIMD_AVX512VL)
      "+VL"
  #endif
  #if defined(DART_SIMD_AVX512CD)
      "+CD"
  #endif
    ;
inline constexpr std::size_t max_vector_bytes = 64;
#elif defined(DART_SIMD_AVX2)
inline constexpr const char* backend_name = "AVX2+FMA";
inline constexpr std::size_t max_vector_bytes = 32;
#elif defined(DART_SIMD_AVX)
inline constexpr const char* backend_name = "AVX";
inline constexpr std::size_t max_vector_bytes = 32;
#elif defined(DART_SIMD_SSE42)
inline constexpr const char* backend_name = "SSE4.2";
inline constexpr std::size_t max_vector_bytes = 16;
#elif defined(DART_SIMD_SVE)
inline constexpr const char* backend_name = "SVE";
inline constexpr std::size_t max_vector_bytes = 16;
#elif defined(DART_SIMD_NEON)
inline constexpr const char* backend_name = "NEON";
inline constexpr std::size_t max_vector_bytes = 16;
#else
inline constexpr const char* backend_name = "Scalar";
inline constexpr std::size_t max_vector_bytes = 8;
#endif

namespace detail {

// C++17 replacements for C++20 <bit> utilities; DART 6 builds with C++17.

template <typename To, typename From>
[[nodiscard]] DART_SIMD_INLINE To bit_cast(const From& src) noexcept
{
  static_assert(sizeof(To) == sizeof(From), "bit_cast requires equal sizes");
  static_assert(
      std::is_trivially_copyable_v<To> && std::is_trivially_copyable_v<From>,
      "bit_cast requires trivially copyable types");
  To dst;
  std::memcpy(&dst, &src, sizeof(To));
  return dst;
}

[[nodiscard]] constexpr int popcount(std::uint64_t value) noexcept
{
#if defined(__GNUC__) || defined(__clang__)
  return __builtin_popcountll(value);
#elif defined(_MSC_VER) && defined(DART_SIMD_SSE42)                            \
    && (defined(_M_X64) || defined(_M_AMD64))
  // SSE4.2+ targets guarantee POPCNT; <intrin.h> is already included above.
  return static_cast<int>(__popcnt64(value));
#else
  int count = 0;
  while (value != 0) {
    value &= value - 1;
    ++count;
  }
  return count;
#endif
}

[[nodiscard]] constexpr bool is_power_of_two(std::size_t value) noexcept
{
  return value != 0 && (value & (value - 1)) == 0;
}

template <typename T>
struct NativeWidth
{
  static constexpr std::size_t value = 1;
};

#if defined(DART_SIMD_AVX512)
template <>
struct NativeWidth<float>
{
  static constexpr std::size_t value = 16;
};
template <>
struct NativeWidth<double>
{
  static constexpr std::size_t value = 8;
};
template <>
struct NativeWidth<std::int32_t>
{
  static constexpr std::size_t value = 16;
};
template <>
struct NativeWidth<std::uint32_t>
{
  static constexpr std::size_t value = 16;
};
#elif defined(DART_SIMD_AVX2)
template <>
struct NativeWidth<float>
{
  static constexpr std::size_t value = 8;
};
template <>
struct NativeWidth<double>
{
  static constexpr std::size_t value = 4;
};
template <>
struct NativeWidth<std::int32_t>
{
  static constexpr std::size_t value = 8;
};
template <>
struct NativeWidth<std::uint32_t>
{
  static constexpr std::size_t value = 8;
};
#elif defined(DART_SIMD_AVX)
template <>
struct NativeWidth<float>
{
  static constexpr std::size_t value = 8;
};
template <>
struct NativeWidth<double>
{
  static constexpr std::size_t value = 4;
};
template <>
struct NativeWidth<std::int32_t>
{
  static constexpr std::size_t value = 4;
};
template <>
struct NativeWidth<std::uint32_t>
{
  static constexpr std::size_t value = 4;
};
#elif defined(DART_SIMD_SSE42)
template <>
struct NativeWidth<float>
{
  static constexpr std::size_t value = 4;
};
template <>
struct NativeWidth<double>
{
  static constexpr std::size_t value = 2;
};
template <>
struct NativeWidth<std::int32_t>
{
  static constexpr std::size_t value = 4;
};
template <>
struct NativeWidth<std::uint32_t>
{
  static constexpr std::size_t value = 4;
};
#elif defined(DART_SIMD_SVE)
template <>
struct NativeWidth<float>
{
  static constexpr std::size_t value = 4;
};
template <>
struct NativeWidth<double>
{
  static constexpr std::size_t value = 2;
};
template <>
struct NativeWidth<std::int32_t>
{
  static constexpr std::size_t value = 4;
};
template <>
struct NativeWidth<std::uint32_t>
{
  static constexpr std::size_t value = 4;
};
#elif defined(DART_SIMD_NEON)
template <>
struct NativeWidth<float>
{
  static constexpr std::size_t value = 4;
};
template <>
struct NativeWidth<double>
{
  static constexpr std::size_t value = 2;
};
template <>
struct NativeWidth<std::int32_t>
{
  static constexpr std::size_t value = 4;
};
template <>
struct NativeWidth<std::uint32_t>
{
  static constexpr std::size_t value = 4;
};
#endif

} // namespace detail

template <typename T>
inline constexpr std::size_t preferred_width_v = detail::NativeWidth<T>::value;

#if defined(DART_SIMD_SSE42)

DART_SIMD_INLINE void set_flush_denormals(bool enable) noexcept
{
  if (enable) {
    _MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON);
    _MM_SET_DENORMALS_ZERO_MODE(_MM_DENORMALS_ZERO_ON);
  } else {
    _MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_OFF);
    _MM_SET_DENORMALS_ZERO_MODE(_MM_DENORMALS_ZERO_OFF);
  }
}

[[nodiscard]] DART_SIMD_INLINE bool flush_denormals() noexcept
{
  return _MM_GET_FLUSH_ZERO_MODE() == _MM_FLUSH_ZERO_ON;
}

#else

DART_SIMD_INLINE void set_flush_denormals(bool) noexcept {}

[[nodiscard]] DART_SIMD_INLINE bool flush_denormals() noexcept
{
  return false;
}

#endif

class ScopedFlushDenormals
{
public:
  explicit ScopedFlushDenormals(bool enable) noexcept
#if defined(DART_SIMD_SSE42)
    : previous_mxcsr_(_mm_getcsr())
#else
    : previous_state_(flush_denormals())
#endif
  {
    set_flush_denormals(enable);
  }

  ~ScopedFlushDenormals() noexcept
  {
#if defined(DART_SIMD_SSE42)
    _mm_setcsr(previous_mxcsr_);
#else
    set_flush_denormals(previous_state_);
#endif
  }

  ScopedFlushDenormals(const ScopedFlushDenormals&) = delete;
  ScopedFlushDenormals& operator=(const ScopedFlushDenormals&) = delete;

private:
#if defined(DART_SIMD_SSE42)
  unsigned int previous_mxcsr_;
#else
  bool previous_state_;
#endif
};

} // namespace dart::simd
