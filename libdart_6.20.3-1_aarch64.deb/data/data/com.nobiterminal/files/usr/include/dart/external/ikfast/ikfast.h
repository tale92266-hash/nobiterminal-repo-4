// This compatibility header is generated into the build and install trees.
// Keep source includes on <dart/dynamics/ikfast.h>. Do not add an outer guard:
// ikfast.h intentionally allows a second include after IKFAST_HAS_LIBRARY is
// defined to expose library-specific declarations.

#include <dart/dynamics/ikfast.h>
