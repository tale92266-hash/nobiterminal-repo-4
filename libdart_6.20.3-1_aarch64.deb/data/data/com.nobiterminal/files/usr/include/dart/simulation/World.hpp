/*
 * Copyright (c) 2011, The DART development contributors
 * All rights reserved.
 *
 * The list of contributors can be found at:
 *   https://github.com/dartsim/dart/blob/main/LICENSE
 *
 * This file is provided under the following "BSD-style" License:
 *   Redistribution and use in source and binary forms, with or
 *   without modification, are permitted provided that the following
 *   conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * This code incorporates portions of Open Dynamics Engine
 *     (Copyright (c) 2001-2004, Russell L. Smith. All rights
 *     reserved.) and portions of FCL (Copyright (c) 2011, Willow
 *     Garage, Inc. All rights reserved.), which were released under
 *     the same BSD license as below
 *
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 *   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *   LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *   ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *   POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef DART_SIMULATION_WORLD_HPP_
#define DART_SIMULATION_WORLD_HPP_

#include <dart/simulation/DeactivationOptions.hpp>
#include <dart/simulation/Recording.hpp>
#include <dart/simulation/SmartPointer.hpp>

#include <dart/constraint/SmartPointer.hpp>

#include <dart/collision/CollisionOption.hpp>
#include <dart/collision/SmartPointer.hpp>

#include <dart/dynamics/SimpleFrame.hpp>
#include <dart/dynamics/Skeleton.hpp>

#include <dart/common/FreeListAllocator.hpp>
#include <dart/common/MemoryAllocator.hpp>
#include <dart/common/MemoryManager.hpp>
#include <dart/common/NameManager.hpp>
#include <dart/common/SmartPointer.hpp>
#include <dart/common/Subject.hpp>

#include <Eigen/Dense>

#include <memory>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace dart {

namespace dynamics {
class Skeleton;
} // namespace dynamics

namespace constraint {
class ConstraintSolver;
} // namespace constraint

namespace collision {
class CollisionDetector;
class CollisionGroup;
class CollisionResult;
} // namespace collision

namespace simulation {

/// Available collision detector backends for a World.
enum class CollisionDetectorType
{
  Dart,
  Fcl,
  Bullet,
  Ode,
};

/// Configuration bundle used when constructing a World.
struct WorldConfig final
{
  /// Friendly name for the world.
  std::string name = "world";

  /// Preferred collision detector for the world.
  CollisionDetectorType collisionDetector = CollisionDetectorType::Fcl;

  /// Base allocator for the World-owned MemoryManager. The allocator must
  /// outlive the World. This does not affect global operator new.
  common::MemoryAllocator* baseAllocator
      = &common::MemoryAllocator::GetDefault();

  /// Initial bytes reserved for the World's free-list allocator.
  std::size_t freeListInitialAllocation = 1048576 /* 1 MB */;

  /// Whether the World's free-list allocator may grow after construction.
  common::FreeListAllocator::GrowthPolicy freeListGrowthPolicy
      = common::FreeListAllocator::GrowthPolicy::Expand;

  /// Initial bytes reserved for the World's per-step frame scratch arena.
  std::size_t frameScratchInitialCapacity = 65536;

  WorldConfig() = default;
  explicit WorldConfig(std::string worldName) : name(std::move(worldName)) {}
};

DART_COMMON_DECLARE_SHARED_WEAK(World)

class SimulationThreadPool;
class WorldDeactivationState;

/// class World
DART_DECLARE_CLASS_WITH_VIRTUAL_BASE_BEGIN
class World : public virtual common::Subject
{
public:
  using NameChangedSignal = common::Signal<void(
      const std::string& _oldName, const std::string& _newName)>;

  /// Creates World as shared_ptr
  template <typename... Args>
  static WorldPtr create(Args&&... args);

  //--------------------------------------------------------------------------
  // Constructor and Destructor
  //--------------------------------------------------------------------------

  /// Creates a World
  static std::shared_ptr<World> create(const std::string& name = "world");

  /// Creates a World using a configuration bundle.
  static std::shared_ptr<World> create(const WorldConfig& config);

  /// Constructor
  World(const std::string& _name = "world");

  /// Constructor with configuration bundle
  explicit World(const WorldConfig& config);

  /// Destructor
  virtual ~World();

  /// Create a clone of this World. All Skeletons and SimpleFrames that are held
  /// by this World will be copied over.
  std::shared_ptr<World> clone() const;

  //--------------------------------------------------------------------------
  // Properties
  //--------------------------------------------------------------------------

  /// Set the name of this World
  const std::string& setName(const std::string& _newName);

  /// Get the name of this World
  const std::string& getName() const;

  /// Set gravity
  void setGravity(const Eigen::Vector3d& _gravity);

  /// Set gravity
  void setGravity(double x, double y, double z);

  /// Get gravity
  const Eigen::Vector3d& getGravity() const;

  /// Set time step. Invalid (<= 0 or non-finite) values are ignored.
  void setTimeStep(double _timeStep);

  /// Get time step
  double getTimeStep() const;

  /// Sets the number of worker threads used for independent per-skeleton
  /// simulation work. The default is 1, which preserves the historical serial
  /// execution path. Passing 0 selects std::thread::hardware_concurrency().
  void setNumSimulationThreads(std::size_t numThreads);

  /// Returns the configured number of simulation worker threads.
  std::size_t getNumSimulationThreads() const;

  //--------------------------------------------------------------------------
  // Structural Properties
  //--------------------------------------------------------------------------

  /// Get the indexed skeleton
  dynamics::SkeletonPtr getSkeleton(std::size_t _index) const;

  /// Find a Skeleton by name
  /// \param[in] _name The name of the Skeleton you are looking for.
  /// \return If the skeleton does not exist then return nullptr.
  dynamics::SkeletonPtr getSkeleton(const std::string& _name) const;

  /// Get the number of skeletons
  std::size_t getNumSkeletons() const;

  /// Add a skeleton to this world
  std::string addSkeleton(const dynamics::SkeletonPtr& _skeleton);

  /// Remove a skeleton from this world
  void removeSkeleton(const dynamics::SkeletonPtr& _skeleton);

  /// Remove all the skeletons in this world, and return a set of shared
  /// pointers to them, in case you want to recycle them
  std::set<dynamics::SkeletonPtr> removeAllSkeletons();

  /// Returns whether this World contains a Skeleton.
  bool hasSkeleton(const dynamics::ConstSkeletonPtr& skeleton) const;

  /// Returns whether this World contains a Skeleton named \c skeletonName.
  bool hasSkeleton(const std::string& skeletonName) const;

  /// Get the cumulative DOF index for the indexed skeleton.
  ///
  /// \param[in] _index Index in range [0, getNumSkeletons()]. Index 0 returns
  ///   the start DOF of the first skeleton (always 0). Index getNumSkeletons()
  ///   returns the total number of DOFs across all skeletons.
  /// \return The cumulative DOF index, or -1 if \p _index is out of range.
  ///   An error is logged and DART_ASSERT is triggered for invalid indices.
  int getIndex(int _index) const;

  /// Get the indexed Entity
  dynamics::SimpleFramePtr getSimpleFrame(std::size_t _index) const;

  /// Find an Entity by name
  dynamics::SimpleFramePtr getSimpleFrame(const std::string& _name) const;

  /// Get the number of Entities
  std::size_t getNumSimpleFrames() const;

  /// Add an Entity to this world
  std::string addSimpleFrame(const dynamics::SimpleFramePtr& _frame);

  /// Remove a SimpleFrame from this world
  void removeSimpleFrame(const dynamics::SimpleFramePtr& _frame);

  /// Remove all SimpleFrames in this world, and return a set of shared
  /// pointers to them, in case you want to recycle them
  std::set<dynamics::SimpleFramePtr> removeAllSimpleFrames();

  //--------------------------------------------------------------------------
  // Collision checking
  //--------------------------------------------------------------------------

  /// Deprecated. Please use checkCollision(~) instead.
  DART_DEPRECATED(6.0)
  bool checkCollision(bool checkAllCollisions);

  /// Perform collision checking with 'option' over all the feasible collision
  /// pairs in this World, and the result will be stored 'result'. If no
  /// argument is passed in then it will return just whether there is collision
  /// or not without the contact information such as contact point, normal, and
  /// penetration depth.
  bool checkCollision(
      const collision::CollisionOption& option
      = collision::CollisionOption(false, 1u, nullptr),
      collision::CollisionResult* result = nullptr);

  /// Return the collision checking result of the last simulation step. If this
  /// world hasn't stepped forward yet, then the result would be empty. Note
  /// that this function does not return the collision checking result of
  /// World::checkCollision().
  ///
  /// With automatic deactivation and a custom BodyNodeCollisionFilter that
  /// supports sleeping, the result also holds the contacts of resting bodies
  /// as solved in the step that put them to sleep, forces included, so it can
  /// hold more contacts than
  /// CollisionOption::maxNumContacts.
  /// ConstraintSolver::getLastCollisionResult() holds only the contacts the
  /// solver computed in the last step. The returned reference stays valid until
  /// the next step or change to the world. Several threads may call this
  /// function at once, but the result's accessors that build caches on first
  /// use, such as CollisionResult::inCollision() and getCollidingBodyNodes(),
  /// are not synchronized: concurrent readers should copy the result or read
  /// its contacts.
  const collision::CollisionResult& getLastCollisionResult() const;

  /// Sets the collision detector used by the world's constraint solver.
  void setCollisionDetector(
      const collision::CollisionDetectorPtr& collisionDetector);

  /// Sets the collision detector via a typed backend selection.
  void setCollisionDetector(CollisionDetectorType collisionDetector);

  /// Returns the collision detector used by the world.
  collision::CollisionDetectorPtr getCollisionDetector();

  /// Returns the collision detector used by the world (const).
  collision::ConstCollisionDetectorPtr getCollisionDetector() const;

  //--------------------------------------------------------------------------
  // Simulation
  //--------------------------------------------------------------------------

  /// Reset the time, frame counter and recorded histories.
  ///
  /// This also clears constraint impulses on all Skeletons in the World so
  /// stale constraint forces do not leak across independent simulation runs.
  void reset();

  /// Calculate the dynamics and integrate the world for one step
  /// \param[in] _resetCommand True if you want to reset to zero the joint
  /// command after simulation step.
  void step(bool _resetCommand = true);

  /// Prepare one-time simulation caches and allocator reservations for the
  /// current world shape. Calling this is optional; step() does it lazily.
  void enterSimulationMode();

  /// Returns true if simulation preparation is current for the world shape.
  bool isInSimulationMode() const;

  /// Returns the World-owned memory manager.
  common::MemoryManager& getMemoryManager();

  /// Returns the World-owned memory manager.
  const common::MemoryManager& getMemoryManager() const;

  /// Set current time
  void setTime(double _time);

  /// Get current time
  double getTime() const;

  /// Get the number of simulated frames
  ///
  /// TODO(MXG): I think the name of this function is much too similar to
  /// getSimpleFrame()
  int getSimFrames() const;

  //--------------------------------------------------------------------------
  // Constraint
  //--------------------------------------------------------------------------

  /// Sets the constraint solver
  ///
  /// Note that the internal properties of \c solver will be overwritten by this
  /// World.
  void setConstraintSolver(constraint::UniqueConstraintSolverPtr solver);

  /// Get the constraint solver
  constraint::ConstraintSolver* getConstraintSolver();

  /// Get the constraint solver
  const constraint::ConstraintSolver* getConstraintSolver() const;

  //--------------------------------------------------------------------------
  // Automatic deactivation ("sleeping")
  //--------------------------------------------------------------------------

  /// Sets the options controlling automatic body deactivation. If the new
  /// options disable the feature, any skeleton currently flagged as resting is
  /// cleared so that subsequent steps behave identically to the feature being
  /// absent.
  void setDeactivationOptions(const DeactivationOptions& options);

  /// Returns the options controlling automatic body deactivation.
  const DeactivationOptions& getDeactivationOptions() const;

  /// Bake simulated current state and store it into mRecording
  void bake();

  /// Get recording
  Recording* getRecording();

  /// \{ \name Iterations

  /// Iterates all the Skeletons and invokes the callback function.
  ///
  /// Example:
  /// \code{.cpp}
  /// bodyNode->eachSkeleton([](const Skeleton* skel) {
  ///   // ...
  /// });
  ///
  /// bodyNode->eachSkeleton([](const Skeleton* skel) -> bool {
  ///   if (!skel->getName() == "name")
  ///   {
  ///     // to stop iterating when found a ShapeNode with no VisualAspect
  ///     return false;
  ///   }
  ///   return true;
  /// });
  /// \endcode
  ///
  /// \tparam Func: The callback function type. The function signature should be
  /// equivalent to \c void(const Skeleton*) or \c bool(const Skeleton*). If
  /// you want to conditionally iterate, use \c bool(const Skeleton*) and
  /// return false when to stop iterating.
  ///
  /// \param[in] func: The callback function to be called for each Skeleton.
  template <typename Func>
  void eachSkeleton(Func func) const;

  /// Iterates all the Skeletons and invokes the callback function.
  ///
  /// \tparam Func: The callback function type. The function signature should be
  /// equivalent to \c void(Skeleton*) or \c bool(Skeleton*). If
  /// you want to conditionally iterate, use \c bool(Skeleton*) and
  /// return false when to stop iterating.
  ///
  /// \param[in] func: The callback function to be called for each Skeleton.
  template <typename Func>
  void eachSkeleton(Func func);

  /// Iterates all the SimpleFrames and invokes the callback function.
  ///
  /// \tparam Func: The callback function type. The function signature should be
  /// equivalent to \c void(const SimpleFrame*) or \c bool(const SimpleFrame*).
  /// If you want to conditionally iterate, use \c bool(const SimpleFrame*) and
  /// return false when to stop iterating.
  ///
  /// \param[in] func: The callback function to be called for each SimpleFrame.
  template <typename Func>
  void eachSimpleFrame(Func func) const;

  /// Iterates all the SimpleFrames and invokes the callback function.
  ///
  /// \tparam Func: The callback function type. The function signature should be
  /// equivalent to \c void(SimpleFrame*) or \c bool(SimpleFrame*). If
  /// you want to conditionally iterate, use \c bool(SimpleFrame*) and
  /// return false when to stop iterating.
  ///
  /// \param[in] func: The callback function to be called for each SimpleFrame.
  template <typename Func>
  void eachSimpleFrame(Func func);

  /// \}

protected:
  /// Runs the post-step rest-detection pass: puts quiet mobile skeletons to
  /// sleep after the configured dwell time and wakes skeletons that have begun
  /// moving again. \p disturbedThisStep marks skeletons that were woken or kept
  /// awake during this step (by a pending force/command or an applied impulse),
  /// indexed in parallel with mSkeletons.
  void updateRestStates(const std::vector<char>& disturbedThisStep);

  /// Returns true if the cached all-resting state is still valid and every
  /// mobile skeleton remains resting, candidate, islanded, and undisturbed.
  /// Sets \p snapshotStale when the cache was valid but a structural or
  /// kinematic change made it unsafe to reuse.
  bool isAllRestingFastPathReady(bool _resetCommand, bool* snapshotStale);

  /// Saves the current skeleton versions for the all-resting fast path.
  void updateAllRestingKinematicSnapshot(bool _resetCommand);

  /// Refreshes the global generation counters on a validated all-resting
  /// snapshot.
  void updateAllRestingSnapshotGlobalVersions();

  /// Returns true if the current filter exposes enough state for all-resting
  /// snapshot reuse.
  bool isCollisionFilterSnapshotTrackable(
      const collision::CollisionFilter* filter) const;

  /// Returns the collision-filter revision tracked by all-resting snapshots.
  std::size_t getCollisionFilterSnapshotRevision(
      const collision::CollisionFilter* filter) const;

  /// Returns true if any mobile skeleton is currently in the resting state.
  bool hasRestingMobileSkeleton() const;

  /// Returns whether a skeleton in this World or its constraint solver, or one
  /// that owns a frame in collisionGroup, changed deactivation state after
  /// Skeleton::getGlobalDeactivationStateVersion() returned globalVersion.
  /// Changes to other skeletons, such as another World's, do not count.
  bool hasDeactivationStateChangedSince(
      const collision::CollisionGroup& collisionGroup,
      std::size_t globalVersion) const;

  /// Wakes resting skeletons when world/contact state changed between steps.
  void wakeRestingSkeletonsIfStepStateChanged();

  /// Saves world/contact state after a step that may leave bodies resting.
  void updateLastStepRestingWorldState();

  /// Clears the saved state used to detect between-step world/contact changes.
  void invalidateLastStepRestingWorldState();

  /// Invalidates the all-resting fast path cache.
  void invalidateAllRestingKinematicSnapshot();

  /// Wakes sleeping mobile skeletons after world-level or external kinematic
  /// changes that may invalidate filtered resting contacts.
  void wakeRestingSkeletonsForWorldChange();

  /// Invalidates simulation preparation after a world-shape change.
  void invalidateSimulationMode();

  /// Rebuilds the cumulative DOF-index cache from the current skeleton list.
  void refreshSkeletonDofIndices();

  /// Reserves simulation scratch buffers for the current world shape.
  void reserveSimulationScratch();

  /// Register when a Skeleton's name is changed
  void handleSkeletonNameChange(
      const dynamics::ConstMetaSkeletonPtr& _skeleton);

  /// Register when a SimpleFrame's name is changed
  void handleSimpleFrameNameChange(const dynamics::Entity* _entity);

  /// Name of this World
  std::string mName;

  /// Skeletons in this world
  std::vector<dynamics::SkeletonPtr> mSkeletons;

  std::map<dynamics::ConstMetaSkeletonPtr, dynamics::SkeletonPtr>
      mMapForSkeletons;

  /// Connections for noticing changes in Skeleton names
  /// TODO(MXG): Consider putting this functionality into NameManager
  std::vector<common::Connection> mNameConnectionsForSkeletons;

  /// NameManager for keeping track of Skeletons
  dart::common::NameManager<dynamics::SkeletonPtr> mNameMgrForSkeletons;

  /// Entities in this world
  std::vector<dynamics::SimpleFramePtr> mSimpleFrames;

  /// Connections for noticing changes in Frame names
  /// TODO(MXG): Consider putting this functionality into NameManager
  std::vector<common::Connection> mNameConnectionsForSimpleFrames;

  /// Map from raw SimpleFrame pointers to their shared_ptrs
  std::map<const dynamics::SimpleFrame*, dynamics::SimpleFramePtr>
      mSimpleFrameToShared;

  /// NameManager for keeping track of Entities
  dart::common::NameManager<dynamics::SimpleFramePtr> mNameMgrForSimpleFrames;

  /// The first indeices of each skeleton's dof in mDofs
  ///
  /// For example, if this world has three skeletons and their dof are
  /// 6, 1 and 2 then the mIndices goes like this: [0 6 7].
  std::vector<int> mIndices;

  /// Gravity
  Eigen::Vector3d mGravity;

  /// Simulation time step
  double mTimeStep;

  /// Number of worker threads for independent per-skeleton simulation work.
  /// Defaults to 1 so World::step remains serial unless explicitly opted in.
  std::size_t mNumSimulationThreads = 1;

  /// Persistent workers for mNumSimulationThreads > 1.
  std::unique_ptr<SimulationThreadPool> mSimulationThreadPool;

  /// Current simulation time
  double mTime;

  /// Current simulation frame number
  int mFrame;

  /// Constraint solver
  std::unique_ptr<constraint::ConstraintSolver> mConstraintSolver;

  /// Memory manager owned by this World.
  std::unique_ptr<common::MemoryManager> mMemoryManager;

  /// Whether simulation preparation is current for this world shape.
  bool mSimulationMode = false;

  /// Global Skeleton structural version captured at simulation preparation.
  std::size_t mSimulationModeStructuralVersion = 0;

  /// Collision group captured at simulation preparation.
  const collision::CollisionGroup* mSimulationModeCollisionGroup = nullptr;
  std::size_t mSimulationModeCollisionGroupVersion = 0;

  /// Constraint solver thread count captured at simulation preparation.
  std::size_t mSimulationModeConstraintSolverThreads = 0;

  /// Collision options captured at simulation preparation.
  bool mSimulationModeCollisionEnableContact = false;
  std::size_t mSimulationModeCollisionMaxNumContacts = 0;
  std::size_t mSimulationModeCollisionMaxNumContactsPerPair = 0;
  bool mSimulationModeCollisionAllowNegativePenetrationDepthContacts = false;
  const collision::CollisionFilter* mSimulationModeCollisionFilter = nullptr;
  bool mSimulationModeCollisionFilterTrackable = true;
  std::size_t mSimulationModeCollisionFilterRevision = 0;

  /// Options controlling automatic body deactivation ("sleeping")
  simulation::DeactivationOptions mDeactivationOptions;

  std::vector<char> mDisturbedThisStepScratch;
  std::vector<const dynamics::Skeleton*>
      mUnsettledInitialContactSkeletonScratch;
  std::vector<const dynamics::Skeleton*>
      mSupportedInitialContactSkeletonScratch;
  std::vector<char> mIslandInitialEquilibriumScratch;

  /// Per skeleton, indexed like mSkeletons: whether it started the world's
  /// first step with a nonzero velocity, which keeps its contact island from
  /// the first-frame dwell credit. Written and read on frame 0 only.
  std::vector<char> mInitiallyMovingSkeletonScratch;

  /// Per body node, skeleton by skeleton in the order of mSkeletons: the
  /// largest speeds that the second solve may leave for the first-frame dwell
  /// credit to apply, recorded on the first. Read on frame 1 only, and cleared
  /// by reset() and by enterSimulationMode(), so that adding or removing a
  /// skeleton or changing a skeleton's bodies in between drops it.
  std::vector<Eigen::Vector3d> mInitialRestSpeedLimits;

  std::vector<char> mIslandHasMobileSkeletonScratch;
  std::vector<char> mIslandAllFinalSleepCandidateReadyScratch;
  std::vector<char> mIslandAllBelowWakeScratch;
  std::vector<std::size_t> mIslandMobileSkeletonCountScratch;
  std::vector<std::size_t> mIslandDwellWakeReadyCountScratch;

  struct AllRestingKinematicSnapshot
  {
    const dynamics::Skeleton* mSkeleton = nullptr;
    std::size_t mStructuralVersion = 0;
    std::size_t mKinematicVersion = 0;
    std::size_t mNumBodyNodes = 0;
    Eigen::VectorXd mPositions;
    std::vector<Eigen::Isometry3d> mBodyTransforms;
  };

  struct RestingWorldSkeletonState
  {
    const dynamics::Skeleton* mSkeleton = nullptr;
    std::size_t mStructuralVersion = 0;
    std::size_t mKinematicVersion = 0;
    std::size_t mNumBodyNodes = 0;
  };

  /// Snapshot used to avoid skipping collision after an external pose edit.
  std::vector<AllRestingKinematicSnapshot> mAllRestingKinematicSnapshot;

  /// Whether the current all-resting snapshot contains at least one mobile
  /// skeleton.
  bool mAllRestingSnapshotHasMobileSkeleton = false;

  /// Whether the snapshot has passed the full per-skeleton all-resting
  /// readiness scan at least once.
  bool mAllRestingSnapshotReady = false;

  /// Whether the current snapshot has already observed step(true)'s command /
  /// force reset contract. A step(false) snapshot may keep quiet commands
  /// cached, so the next step(true) must run the reset check once.
  bool mAllRestingSnapshotResetCommand = true;

  /// Global generation counters captured with mAllRestingKinematicSnapshot.
  std::size_t mAllRestingSnapshotStructuralVersion = 0;
  std::size_t mAllRestingSnapshotKinematicVersion = 0;
  std::size_t mAllRestingSnapshotExternalDisturbanceVersion = 0;
  std::size_t mAllRestingSnapshotDeactivationStateVersion = 0;
  std::size_t mAllRestingSnapshotVelocityVersion = 0;
  const collision::CollisionDetector* mAllRestingSnapshotCollisionDetector
      = nullptr;
  const collision::CollisionGroup* mAllRestingSnapshotCollisionGroup = nullptr;
  std::size_t mAllRestingSnapshotCollisionGroupVersion = 0;
  bool mAllRestingSnapshotCollisionEnableContact = false;
  std::size_t mAllRestingSnapshotCollisionMaxNumContacts = 0;
  std::size_t mAllRestingSnapshotCollisionMaxNumContactsPerPair = 0;
  bool mAllRestingSnapshotCollisionAllowNegativePenetrationDepthContacts
      = false;
  const collision::CollisionFilter* mAllRestingSnapshotCollisionFilter
      = nullptr;
  std::size_t mAllRestingSnapshotCollisionFilterRevision = 0;

  /// World/contact state captured after the last step while bodies were
  /// resting.
  bool mLastStepRestingWorldStateValid = false;
  bool mLastStepRestingWorldStateCollisionFilterTrackable = false;
  std::vector<RestingWorldSkeletonState> mLastStepRestingWorldSkeletonStates;
  std::size_t mLastStepRestingWorldStateDeactivationStateVersion = 0;
  const collision::CollisionDetector*
      mLastStepRestingWorldStateCollisionDetector
      = nullptr;
  const collision::CollisionGroup* mLastStepRestingWorldStateCollisionGroup
      = nullptr;
  std::size_t mLastStepRestingWorldStateCollisionGroupVersion = 0;
  bool mLastStepRestingWorldStateCollisionEnableContact = false;
  std::size_t mLastStepRestingWorldStateCollisionMaxNumContacts = 0;
  std::size_t mLastStepRestingWorldStateCollisionMaxNumContactsPerPair = 0;
  bool mLastStepRestingWorldStateCollisionAllowNegativePenetrationDepthContacts
      = false;
  const collision::CollisionFilter* mLastStepRestingWorldStateCollisionFilter
      = nullptr;
  std::size_t mLastStepRestingWorldStateCollisionFilterRevision = 0;

  /// Whether mAllRestingKinematicSnapshot can be used.
  bool mAllRestingKinematicSnapshotValid = false;

  ///
  Recording* mRecording;

  //--------------------------------------------------------------------------
  // Signals
  //--------------------------------------------------------------------------
  NameChangedSignal mNameChangedSignal;

public:
  //--------------------------------------------------------------------------
  // Slot registers
  //--------------------------------------------------------------------------
  common::SlotRegister<NameChangedSignal> onNameChanged;

private:
  friend struct WorldTestAccess;

  /// Whether solver support motion is covered by World's skeleton snapshots.
  bool ownsSolverSkeletons();

  /// Number of full skeleton membership checks, for deterministic cost tests.
  std::size_t getSolverSkeletonOwnershipCheckCount() const;

  /// Collision-side deactivation state, including custom-filter decisions and
  /// the resting contacts getLastCollisionResult() keeps reporting.
  /// World's layout is not ABI-stable from 6.19 to 6.20: the thread, memory,
  /// and simulation-mode members above were added in 6.20. Keep new state
  /// behind this pointer so 6.20.x can extend it without changing
  /// sizeof(World).
  std::unique_ptr<WorldDeactivationState> mDeactivationState;
};
DART_DECLARE_CLASS_WITH_VIRTUAL_BASE_END

} // namespace simulation
} // namespace dart

#include <dart/simulation/detail/World-impl.hpp>

#endif // DART_SIMULATION_WORLD_HPP_
