/*
 * Copyright (c) 2011, The DART development contributors
 * All rights reserved.
 *
 * The list of contributors can be found at:
 *   https://github.com/dartsim/dart/blob/main/LICENSE
 *
 * This file is provided under the following "BSD-style" License:
 *   Redistribution and use in source and binary forms, with or
 *   without modification, are permitted provided that the following
 *   conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 *   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *   LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *   ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *   POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef DART_COLLISION_BULLET_BULLETCOLLISIONOBJECT_HPP_
#define DART_COLLISION_BULLET_BULLETCOLLISIONOBJECT_HPP_

#include <dart/collision/CollisionObject.hpp>
#include <dart/collision/bullet/BulletCollisionShape.hpp>
#include <dart/collision/bullet/BulletInclude.hpp>

namespace dart {
namespace collision {

class CollisionObject;

class BulletCollisionObject : public CollisionObject
{
public:
  friend class BulletCollisionDetector;
  friend class BulletCollisionGroup;

  /// Return Bullet collision object
  btCollisionObject* getBulletCollisionObject();

  /// Return Bullet collision object
  const btCollisionObject* getBulletCollisionObject() const;

protected:
  /// Constructor
  BulletCollisionObject(
      CollisionDetector* collisionDetector,
      const dynamics::ShapeFrame* shapeFrame,
      const std::shared_ptr<BulletCollisionShape>& bulletCollisionShape);

  // Documentation inherited
  void updateEngineData() override;

  /// Refreshes whether this object can use its BodyNode world transform
  /// directly during transform sync.
  void updateTransformFastPath();

protected:
  /// Bullet collision object
  std::shared_ptr<BulletCollisionShape> mBulletCollisionShape;
  std::unique_ptr<btCollisionObject> mBulletCollisionObject;

  std::size_t mLastTransformFastPathVersion = static_cast<std::size_t>(-1);
  bool mUseBodyNodeWorldTransform = false;
};

} // namespace collision
} // namespace dart

#endif // DART_COLLISION_BULLET_BULLETCOLLISIONOBJECT_HPP_
