/*
 * Copyright (c) 2011, The DART development contributors
 * All rights reserved.
 *
 * The list of contributors can be found at:
 *   https://github.com/dartsim/dart/blob/main/LICENSE
 *
 * This file is provided under the following "BSD-style" License:
 *   Redistribution and use in source and binary forms, with or
 *   without modification, are permitted provided that the following
 *   conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 *   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *   LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *   ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *   POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once

#include <dart/simd/config.hpp>
#include <dart/simd/detail/avx2/vec.hpp>
#include <dart/simd/detail/avx2/vec_mask.hpp>

#include <cmath>
#include <cstddef>

#if defined(DART_SIMD_AVX2)

namespace dart::simd {

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> abs(const Vec<float, 8>& v)
{
  return Vec<float, 8>(_mm256_and_ps(
      v.data, _mm256_castsi256_ps(_mm256_set1_epi32(0x7FFFFFFF))));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> abs(const Vec<double, 4>& v)
{
  return Vec<double, 4>(_mm256_and_pd(
      v.data, _mm256_castsi256_pd(_mm256_set1_epi64x(0x7FFFFFFFFFFFFFFF))));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> sqrt(const Vec<float, 8>& v)
{
  return Vec<float, 8>(_mm256_sqrt_ps(v.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> sqrt(const Vec<double, 4>& v)
{
  return Vec<double, 4>(_mm256_sqrt_pd(v.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> rsqrt(const Vec<float, 8>& v)
{
  __m256 est = _mm256_rsqrt_ps(v.data);
  __m256 half = _mm256_set1_ps(0.5f);
  __m256 three = _mm256_set1_ps(3.0f);
  __m256 muls = _mm256_mul_ps(_mm256_mul_ps(v.data, est), est);
  return Vec<float, 8>(
      _mm256_mul_ps(_mm256_mul_ps(half, est), _mm256_sub_ps(three, muls)));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> rsqrt(const Vec<double, 4>& v)
{
  return Vec<double, 4>(
      _mm256_div_pd(_mm256_set1_pd(1.0), _mm256_sqrt_pd(v.data)));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> rcp(const Vec<float, 8>& v)
{
  __m256 est = _mm256_rcp_ps(v.data);
  __m256 two = _mm256_set1_ps(2.0f);
  __m256 muls = _mm256_mul_ps(v.data, est);
  return Vec<float, 8>(_mm256_mul_ps(est, _mm256_sub_ps(two, muls)));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> rcp(const Vec<double, 4>& v)
{
  return Vec<double, 4>(_mm256_div_pd(_mm256_set1_pd(1.0), v.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> min(
    const Vec<float, 8>& a, const Vec<float, 8>& b)
{
  return Vec<float, 8>(_mm256_min_ps(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> min(
    const Vec<double, 4>& a, const Vec<double, 4>& b)
{
  return Vec<double, 4>(_mm256_min_pd(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<std::int32_t, 8> min(
    const Vec<std::int32_t, 8>& a, const Vec<std::int32_t, 8>& b)
{
  return Vec<std::int32_t, 8>(_mm256_min_epi32(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> max(
    const Vec<float, 8>& a, const Vec<float, 8>& b)
{
  return Vec<float, 8>(_mm256_max_ps(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> max(
    const Vec<double, 4>& a, const Vec<double, 4>& b)
{
  return Vec<double, 4>(_mm256_max_pd(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<std::int32_t, 8> max(
    const Vec<std::int32_t, 8>& a, const Vec<std::int32_t, 8>& b)
{
  return Vec<std::int32_t, 8>(_mm256_max_epi32(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> clamp(
    const Vec<float, 8>& v, const Vec<float, 8>& lo, const Vec<float, 8>& hi)
{
  return min(max(v, lo), hi);
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> clamp(
    const Vec<double, 4>& v, const Vec<double, 4>& lo, const Vec<double, 4>& hi)
{
  return min(max(v, lo), hi);
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> fmadd(
    const Vec<float, 8>& a, const Vec<float, 8>& b, const Vec<float, 8>& c)
{
  return Vec<float, 8>(_mm256_fmadd_ps(a.data, b.data, c.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> fmadd(
    const Vec<double, 4>& a, const Vec<double, 4>& b, const Vec<double, 4>& c)
{
  return Vec<double, 4>(_mm256_fmadd_pd(a.data, b.data, c.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> fmsub(
    const Vec<float, 8>& a, const Vec<float, 8>& b, const Vec<float, 8>& c)
{
  return Vec<float, 8>(_mm256_fmsub_ps(a.data, b.data, c.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> fmsub(
    const Vec<double, 4>& a, const Vec<double, 4>& b, const Vec<double, 4>& c)
{
  return Vec<double, 4>(_mm256_fmsub_pd(a.data, b.data, c.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> fnmadd(
    const Vec<float, 8>& a, const Vec<float, 8>& b, const Vec<float, 8>& c)
{
  return Vec<float, 8>(_mm256_fnmadd_ps(a.data, b.data, c.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> fnmadd(
    const Vec<double, 4>& a, const Vec<double, 4>& b, const Vec<double, 4>& c)
{
  return Vec<double, 4>(_mm256_fnmadd_pd(a.data, b.data, c.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> floor(const Vec<float, 8>& v)
{
  return Vec<float, 8>(_mm256_floor_ps(v.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> floor(const Vec<double, 4>& v)
{
  return Vec<double, 4>(_mm256_floor_pd(v.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> ceil(const Vec<float, 8>& v)
{
  return Vec<float, 8>(_mm256_ceil_ps(v.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> ceil(const Vec<double, 4>& v)
{
  return Vec<double, 4>(_mm256_ceil_pd(v.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> round(const Vec<float, 8>& v)
{
  return Vec<float, 8>(
      _mm256_round_ps(v.data, _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> round(const Vec<double, 4>& v)
{
  return Vec<double, 4>(
      _mm256_round_pd(v.data, _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> trunc(const Vec<float, 8>& v)
{
  return Vec<float, 8>(
      _mm256_round_ps(v.data, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> trunc(const Vec<double, 4>& v)
{
  return Vec<double, 4>(
      _mm256_round_pd(v.data, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC));
}

template <>
[[nodiscard]] DART_SIMD_INLINE float hsum(const Vec<float, 8>& v)
{
  __m128 lo = _mm256_castps256_ps128(v.data);
  __m128 hi = _mm256_extractf128_ps(v.data, 1);
  __m128 sum = _mm_add_ps(lo, hi);
  __m128 shuf = _mm_movehdup_ps(sum);
  __m128 sums = _mm_add_ps(sum, shuf);
  shuf = _mm_movehl_ps(shuf, sums);
  sums = _mm_add_ss(sums, shuf);
  return _mm_cvtss_f32(sums);
}

template <>
[[nodiscard]] DART_SIMD_INLINE double hsum(const Vec<double, 4>& v)
{
  __m128d lo = _mm256_castpd256_pd128(v.data);
  __m128d hi = _mm256_extractf128_pd(v.data, 1);
  __m128d sum = _mm_add_pd(lo, hi);
  __m128d shuf = _mm_shuffle_pd(sum, sum, 1);
  __m128d sums = _mm_add_sd(sum, shuf);
  return _mm_cvtsd_f64(sums);
}

template <>
[[nodiscard]] DART_SIMD_INLINE float hmin(const Vec<float, 8>& v)
{
  __m128 lo = _mm256_castps256_ps128(v.data);
  __m128 hi = _mm256_extractf128_ps(v.data, 1);
  __m128 mins = _mm_min_ps(lo, hi);
  __m128 shuf = _mm_movehdup_ps(mins);
  mins = _mm_min_ps(mins, shuf);
  shuf = _mm_movehl_ps(shuf, mins);
  mins = _mm_min_ss(mins, shuf);
  return _mm_cvtss_f32(mins);
}

template <>
[[nodiscard]] DART_SIMD_INLINE double hmin(const Vec<double, 4>& v)
{
  __m128d lo = _mm256_castpd256_pd128(v.data);
  __m128d hi = _mm256_extractf128_pd(v.data, 1);
  __m128d mins = _mm_min_pd(lo, hi);
  __m128d shuf = _mm_shuffle_pd(mins, mins, 1);
  mins = _mm_min_sd(mins, shuf);
  return _mm_cvtsd_f64(mins);
}

template <>
[[nodiscard]] DART_SIMD_INLINE float hmax(const Vec<float, 8>& v)
{
  __m128 lo = _mm256_castps256_ps128(v.data);
  __m128 hi = _mm256_extractf128_ps(v.data, 1);
  __m128 maxs = _mm_max_ps(lo, hi);
  __m128 shuf = _mm_movehdup_ps(maxs);
  maxs = _mm_max_ps(maxs, shuf);
  shuf = _mm_movehl_ps(shuf, maxs);
  maxs = _mm_max_ss(maxs, shuf);
  return _mm_cvtss_f32(maxs);
}

template <>
[[nodiscard]] DART_SIMD_INLINE double hmax(const Vec<double, 4>& v)
{
  __m128d lo = _mm256_castpd256_pd128(v.data);
  __m128d hi = _mm256_extractf128_pd(v.data, 1);
  __m128d maxs = _mm_max_pd(lo, hi);
  __m128d shuf = _mm_shuffle_pd(maxs, maxs, 1);
  maxs = _mm_max_sd(maxs, shuf);
  return _mm_cvtsd_f64(maxs);
}

template <>
[[nodiscard]] DART_SIMD_INLINE float hprod(const Vec<float, 8>& v)
{
  __m128 lo = _mm256_castps256_ps128(v.data);
  __m128 hi = _mm256_extractf128_ps(v.data, 1);
  __m128 prods = _mm_mul_ps(lo, hi);
  __m128 shuf = _mm_movehdup_ps(prods);
  prods = _mm_mul_ps(prods, shuf);
  shuf = _mm_movehl_ps(shuf, prods);
  prods = _mm_mul_ss(prods, shuf);
  return _mm_cvtss_f32(prods);
}

template <>
[[nodiscard]] DART_SIMD_INLINE double hprod(const Vec<double, 4>& v)
{
  __m128d lo = _mm256_castpd256_pd128(v.data);
  __m128d hi = _mm256_extractf128_pd(v.data, 1);
  __m128d prods = _mm_mul_pd(lo, hi);
  __m128d shuf = _mm_shuffle_pd(prods, prods, 1);
  prods = _mm_mul_sd(prods, shuf);
  return _mm_cvtsd_f64(prods);
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> select(
    const VecMask<float, 8>& mask,
    const Vec<float, 8>& if_true,
    const Vec<float, 8>& if_false)
{
  return Vec<float, 8>(
      _mm256_blendv_ps(if_false.data, if_true.data, mask.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> select(
    const VecMask<double, 4>& mask,
    const Vec<double, 4>& if_true,
    const Vec<double, 4>& if_false)
{
  return Vec<double, 4>(
      _mm256_blendv_pd(if_false.data, if_true.data, mask.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<std::int32_t, 8> select(
    const VecMask<std::int32_t, 8>& mask,
    const Vec<std::int32_t, 8>& if_true,
    const Vec<std::int32_t, 8>& if_false)
{
  return Vec<std::int32_t, 8>(
      _mm256_blendv_epi8(if_false.data, if_true.data, mask.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> bitAnd(
    const Vec<float, 8>& a, const Vec<float, 8>& b)
{
  return Vec<float, 8>(_mm256_and_ps(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> bitAnd(
    const Vec<double, 4>& a, const Vec<double, 4>& b)
{
  return Vec<double, 4>(_mm256_and_pd(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<std::int32_t, 8> bitAnd(
    const Vec<std::int32_t, 8>& a, const Vec<std::int32_t, 8>& b)
{
  return Vec<std::int32_t, 8>(_mm256_and_si256(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> bitOr(
    const Vec<float, 8>& a, const Vec<float, 8>& b)
{
  return Vec<float, 8>(_mm256_or_ps(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> bitOr(
    const Vec<double, 4>& a, const Vec<double, 4>& b)
{
  return Vec<double, 4>(_mm256_or_pd(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<std::int32_t, 8> bitOr(
    const Vec<std::int32_t, 8>& a, const Vec<std::int32_t, 8>& b)
{
  return Vec<std::int32_t, 8>(_mm256_or_si256(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> bitXor(
    const Vec<float, 8>& a, const Vec<float, 8>& b)
{
  return Vec<float, 8>(_mm256_xor_ps(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> bitXor(
    const Vec<double, 4>& a, const Vec<double, 4>& b)
{
  return Vec<double, 4>(_mm256_xor_pd(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<std::int32_t, 8> bitXor(
    const Vec<std::int32_t, 8>& a, const Vec<std::int32_t, 8>& b)
{
  return Vec<std::int32_t, 8>(_mm256_xor_si256(a.data, b.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> bitAndnot(
    const Vec<float, 8>& a, const Vec<float, 8>& b)
{
  return Vec<float, 8>(_mm256_andnot_ps(b.data, a.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<double, 4> bitAndnot(
    const Vec<double, 4>& a, const Vec<double, 4>& b)
{
  return Vec<double, 4>(_mm256_andnot_pd(b.data, a.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<std::int32_t, 8> bitNot(
    const Vec<std::int32_t, 8>& v)
{
  return Vec<std::int32_t, 8>(_mm256_xor_si256(
      v.data, _mm256_set1_epi32(static_cast<int>(0xFFFFFFFF))));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<std::int32_t, 8> reinterpretAsInt(
    const Vec<float, 8>& v)
{
  return Vec<std::int32_t, 8>(_mm256_castps_si256(v.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> reinterpretAsFloat(
    const Vec<std::int32_t, 8>& v)
{
  return Vec<float, 8>(_mm256_castsi256_ps(v.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<std::int32_t, 8> convertToInt(
    const Vec<float, 8>& v)
{
  return Vec<std::int32_t, 8>(_mm256_cvttps_epi32(v.data));
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> convertToFloat(
    const Vec<std::int32_t, 8>& v)
{
  return Vec<float, 8>(_mm256_cvtepi32_ps(v.data));
}

template <int N>
[[nodiscard]] DART_SIMD_INLINE Vec<std::int32_t, 8> shiftLeft(
    const Vec<std::int32_t, 8>& v)
{
  return Vec<std::int32_t, 8>(_mm256_slli_epi32(v.data, N));
}

template <int N>
[[nodiscard]] DART_SIMD_INLINE Vec<std::int32_t, 8> shiftRight(
    const Vec<std::int32_t, 8>& v)
{
  return Vec<std::int32_t, 8>(_mm256_srai_epi32(v.data, N));
}

template <>
[[nodiscard]] DART_SIMD_INLINE std::pair<Vec<float, 8>, Vec<std::int32_t, 8>>
frexpSimd(const Vec<float, 8>& v)
{
  const __m256i signMask = _mm256_set1_epi32(0x80000000);
  const __m256i expMask = _mm256_set1_epi32(0x7F800000);
  const __m256i mantissaMask = _mm256_set1_epi32(0x007FFFFF);
  const __m256i halfExp = _mm256_set1_epi32(0x3F000000);
  const __m256i bias = _mm256_set1_epi32(127);

  __m256i bits = _mm256_castps_si256(v.data);
  __m256i signBits = _mm256_and_si256(bits, signMask);
  __m256i expBits = _mm256_and_si256(bits, expMask);
  __m256i mantBits = _mm256_and_si256(bits, mantissaMask);

  __m256i isZeroOrSubnorm = _mm256_cmpeq_epi32(expBits, _mm256_setzero_si256());
  __m256i isInfNan = _mm256_cmpeq_epi32(expBits, expMask);
  __m256i needScalar = _mm256_or_si256(isZeroOrSubnorm, isInfNan);

  if (!_mm256_testz_si256(needScalar, needScalar)) {
    alignas(32) float vArr[8];
    alignas(32) float mantArr[8];
    alignas(32) std::int32_t expArr[8];
    v.store(vArr);

    for (std::size_t i = 0; i < 8; ++i) {
      std::uint32_t b = detail::bit_cast<std::uint32_t>(vArr[i]);

      std::int32_t biasedExp
          = static_cast<std::int32_t>((b & 0x7F800000) >> 23);
      std::int32_t expAdjust = 0;

      if (biasedExp == 255) {
        mantArr[i] = vArr[i];
        expArr[i] = 0;
        continue;
      }

      if (biasedExp == 0) {
        if ((b & 0x007FFFFF) == 0) {
          mantArr[i] = vArr[i];
          expArr[i] = 0;
          continue;
        }
        float normalized = vArr[i] * 8388608.0f;
        b = detail::bit_cast<std::uint32_t>(normalized);
        biasedExp = static_cast<std::int32_t>((b & 0x7F800000) >> 23);
        expAdjust = -23;
      }

      expArr[i] = biasedExp - 127 + expAdjust;
      std::uint32_t mantResult = (b & 0x807FFFFF) | 0x3F000000;
      mantArr[i] = detail::bit_cast<float>(mantResult);
    }
    return {Vec<float, 8>::load(mantArr), Vec<std::int32_t, 8>::load(expArr)};
  }

  __m256i exponent = _mm256_sub_epi32(_mm256_srli_epi32(expBits, 23), bias);
  __m256i mantissaBits
      = _mm256_or_si256(_mm256_or_si256(mantBits, halfExp), signBits);

  return {
      Vec<float, 8>(_mm256_castsi256_ps(mantissaBits)),
      Vec<std::int32_t, 8>(exponent)};
}

template <>
[[nodiscard]] DART_SIMD_INLINE Vec<float, 8> ldexpSimd(
    const Vec<float, 8>& x, const Vec<std::int32_t, 8>& exp)
{
  __m256i tooLow = _mm256_cmpgt_epi32(_mm256_set1_epi32(-126), exp.data);
  __m256i tooHigh = _mm256_cmpgt_epi32(exp.data, _mm256_set1_epi32(127));
  if (_mm256_movemask_epi8(_mm256_or_si256(tooLow, tooHigh)) != 0) {
    alignas(32) float xArr[8], rArr[8];
    alignas(32) std::int32_t expArr[8];
    x.store(xArr);
    exp.store(expArr);
    for (std::size_t i = 0; i < 8; ++i) {
      rArr[i] = std::ldexp(xArr[i], expArr[i]);
    }
    return Vec<float, 8>::load(rArr);
  }

  // Fast path: x * 2^exp = x * reinterpret(shiftLeft<23>(exp + 127))
  // This is much faster than extracting/recombining exponent bits
  __m256i biasedExp = _mm256_add_epi32(exp.data, _mm256_set1_epi32(0x7f));
  __m256i pow2 = _mm256_slli_epi32(biasedExp, 23);
  return Vec<float, 8>(_mm256_mul_ps(x.data, _mm256_castsi256_ps(pow2)));
}

} // namespace dart::simd

#endif // DART_SIMD_AVX2
