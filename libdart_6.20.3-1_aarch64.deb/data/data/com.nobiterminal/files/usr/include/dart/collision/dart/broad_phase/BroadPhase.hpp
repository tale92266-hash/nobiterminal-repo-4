/*
 * Copyright (c) 2011, The DART development contributors
 * All rights reserved.
 *
 * The list of contributors can be found at:
 *   https://github.com/dartsim/dart/blob/main/LICENSE
 *
 * This file is provided under the following "BSD-style" License:
 *   Redistribution and use in source and binary forms, with or
 *   without modification, are permitted provided that the following
 *   conditions are met:
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *   CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *   INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *   MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *   DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *   USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 *   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *   LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *   ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *   POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once

#include <dart/collision/dart/Aabb.hpp>
#include <dart/collision/dart/Export.hpp>
#include <dart/collision/dart/detail/Span.hpp>

#include <array>
#include <functional>
#include <limits>
#include <utility>
#include <vector>

#include <cstddef>

namespace dart::collision::native {

using BroadPhasePair = std::pair<std::size_t, std::size_t>;
using BroadPhasePairVisitor
    = std::function<bool(std::size_t first, std::size_t second)>;

struct DART_COLLISION_NATIVE_API BroadPhaseDebugNode
{
  static constexpr std::size_t kInvalidIndex
      = std::numeric_limits<std::size_t>::max();

  std::size_t nodeId = kInvalidIndex;
  std::size_t parent = kInvalidIndex;
  std::size_t left = kInvalidIndex;
  std::size_t right = kInvalidIndex;
  std::size_t objectId = kInvalidIndex;
  Aabb aabb;
  Aabb tightAabb;
  std::size_t height = 0;

  [[nodiscard]] bool isLeaf() const
  {
    return objectId != kInvalidIndex;
  }
};

struct DART_COLLISION_NATIVE_API BroadPhaseDebugCell
{
  std::array<int, 3> coordinates = {0, 0, 0};
  Aabb aabb;
  std::vector<std::size_t> objectIds;
  std::size_t hash = 0;
};

struct DART_COLLISION_NATIVE_API BroadPhaseDebugEndpoint
{
  int axis = 0;
  std::size_t objectId = BroadPhaseDebugNode::kInvalidIndex;
  double value = 0.0;
  bool isMin = true;
  std::size_t order = 0;
};

struct DART_COLLISION_NATIVE_API BroadPhaseDebugSnapshot
{
  std::vector<BroadPhaseDebugNode> nodes;
  std::vector<BroadPhaseDebugCell> cells;
  std::vector<BroadPhaseDebugEndpoint> endpoints;
  std::vector<BroadPhasePair> candidatePairs;
  std::size_t rootNode = BroadPhaseDebugNode::kInvalidIndex;
  std::size_t numObjects = 0;
  double spatialHashCellSize = 0.0;
  bool hasTreeTopology = false;
  bool hasSpatialHashCells = false;
  bool hasSweepEndpoints = false;

  void clear()
  {
    nodes.clear();
    cells.clear();
    endpoints.clear();
    candidatePairs.clear();
    rootNode = BroadPhaseDebugNode::kInvalidIndex;
    numObjects = 0;
    spatialHashCellSize = 0.0;
    hasTreeTopology = false;
    hasSpatialHashCells = false;
    hasSweepEndpoints = false;
  }
};

class DART_COLLISION_NATIVE_API BroadPhase
{
public:
  virtual ~BroadPhase() = default;

  virtual void clear() = 0;
  virtual void add(std::size_t id, const Aabb& aabb) = 0;
  virtual void update(std::size_t id, const Aabb& aabb) = 0;
  virtual void remove(std::size_t id) = 0;

  [[nodiscard]] virtual std::vector<BroadPhasePair> queryPairs() const = 0;
  [[nodiscard]] virtual std::vector<std::size_t> queryOverlapping(
      const Aabb& aabb) const = 0;
  [[nodiscard]] virtual std::size_t size() const = 0;

  virtual void buildDebugSnapshot(BroadPhaseDebugSnapshot& out) const
  {
    out.clear();
    out.candidatePairs = queryPairs();
    out.numObjects = size();
  }

  virtual void queryPairs(std::vector<BroadPhasePair>& out) const
  {
    out = queryPairs();
  }

  virtual bool visitPairs(const BroadPhasePairVisitor& visitor) const
  {
    auto allPairs = queryPairs();
    for (const auto& pair : allPairs) {
      if (!visitor(pair.first, pair.second)) {
        return false;
      }
    }
    return true;
  }

  template <typename FilterFunc>
  void queryPairsFiltered(
      std::vector<BroadPhasePair>& out, FilterFunc&& filter) const
  {
    out.clear();
    auto allPairs = queryPairs();
    for (const auto& pair : allPairs) {
      if (filter(pair.first, pair.second)) {
        out.push_back(pair);
      }
    }
  }

  virtual void build(span<const std::size_t> ids, span<const Aabb> aabbs)
  {
    clear();
    const std::size_t n = std::min(ids.size(), aabbs.size());
    for (std::size_t i = 0; i < n; ++i) {
      add(ids[i], aabbs[i]);
    }
  }

  virtual void updateRange(span<const std::size_t> ids, span<const Aabb> aabbs)
  {
    const std::size_t n = std::min(ids.size(), aabbs.size());
    for (std::size_t i = 0; i < n; ++i) {
      update(ids[i], aabbs[i]);
    }
  }
};

} // namespace dart::collision::native
