@echo off
rem scripts/mprof.bat.  Generated from mprof.bat.in by configure.
rem ---------------------------------------------------------------------------
rem Copyright (C) 2011 The University of Melbourne.
rem Copyright (C) 2024 The Mercury team.
rem This file may only be copied under the terms of the GNU General
rem Public License - see the file COPYING in the Mercury distribution.
rem ---------------------------------------------------------------------------
rem
rem mprof - MercuryProfiler
rem Use `mprof -h' for help.
rem
rem ---------------------------------------------------------------------------

rem Do not export any local environment changes and ensure command extensions
rem are enabled.
setlocal enableextensions

set "MPROF=/data/data/com.nobiterminal/files/usr\bin\mercury_profile"
%MPROF% %*
