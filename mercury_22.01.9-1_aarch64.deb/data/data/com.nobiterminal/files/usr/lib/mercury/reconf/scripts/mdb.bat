@echo off
rem scripts/mdb.bat.  Generated from mdb.bat.in by configure.
rem ---------------------------------------------------------------------------
rem Copyright (C) 2011 The University of Melbourne.
rem Copyright (C) 2020, 2024 The Mercury team.
rem This file may only be copied under the terms of the GNU General
rem Public License - see the file COPYING in the Mercury distribution.
rem ---------------------------------------------------------------------------
rem
rem mdb.bat - Mercury debugger
rem Usage: mdb [<options>] <executable> [<args>] ...
rem
rem ---------------------------------------------------------------------------

rem Do not export any local environment changes and ensure command extensions
rem are enabled.
setlocal enableextensions

set "MERCURY_OPTIONS=%MERCURY_OPTIONS% -Di"
set "MERCURY_DEBUGGER_INIT=/data/data/com.nobiterminal/files/usr\lib\mercury\mdb\mdbrc"
%*
