@echo off
rem scripts/mercury.bat.  Generated from mercury.bat.in by configure.
rem ---------------------------------------------------------------------------
rem Copyright (C) 2001, 2003, 2005, 2011 The University of Melbourne.
rem Copyright (C) 2020, 2024 The Mercury team.
rem This file may only be copied under the terms of the GNU General
rem Public License - see the file COPYING in the Mercury distribution.
rem ---------------------------------------------------------------------------
rem
rem mercury.bat - Melbourne Mercury Compiler.
rem
rem Use `mercury -h' for help.
rem
rem ---------------------------------------------------------------------------
rem This is a Windows batch file version of the `mmc' Bourne shell script.
rem (We don't use that name because it conflicts with that of the Microsoft
rem Management Console.)
rem ---------------------------------------------------------------------------

rem Do not export any local environment changes and ensure command extensions
rem are enabled.
setlocal enableextensions

set "MERCURY_CONFIG_DIR=/data/data/com.nobiterminal/files/usr/lib/mercury"
set "MERCURY_COMPILER=/data/data/com.nobiterminal/files/usr\bin\mercury_compile"

%MERCURY_COMPILER% %*
