#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "fcl" for configuration "Release"
set_property(TARGET fcl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(fcl PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libfcl.so"
  IMPORTED_SONAME_RELEASE "libfcl.so"
  )

list(APPEND _cmake_import_check_targets fcl )
list(APPEND _cmake_import_check_files_for_fcl "/data/data/com.nobiterminal/files/usr/lib/libfcl.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
