#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libcec::cec-shared" for configuration "Release"
set_property(TARGET libcec::cec-shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(libcec::cec-shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libcec.so"
  IMPORTED_SONAME_RELEASE "libcec.so"
  )

list(APPEND _cmake_import_check_targets libcec::cec-shared )
list(APPEND _cmake_import_check_files_for_libcec::cec-shared "/data/data/com.nobiterminal/files/usr/lib/libcec.so" )

# Import target "libcec::cec-static" for configuration "Release"
set_property(TARGET libcec::cec-static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(libcec::cec-static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libcec.a"
  )

list(APPEND _cmake_import_check_targets libcec::cec-static )
list(APPEND _cmake_import_check_files_for_libcec::cec-static "/data/data/com.nobiterminal/files/usr/lib/libcec.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
