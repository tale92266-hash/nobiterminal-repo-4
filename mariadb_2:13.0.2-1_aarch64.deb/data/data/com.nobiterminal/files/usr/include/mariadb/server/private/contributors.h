#ifndef CONTRIBUTORS_INCLUDED
#define CONTRIBUTORS_INCLUDED

/* Copyright (c) 2006 MySQL AB, 2009 Sun Microsystems, Inc.
   Use is subject to license terms.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; version 2 of the License.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1335  USA */

/* Structure of the name list */

struct show_table_contributors_st {
  const char *name;
  const char *location;
  const char *comment;
};

/*
  Output from "SHOW CONTRIBUTORS"

  Get permission before editing.

  Names should be encoded using UTF-8.

  See also https://mariadb.com/docs/general-resources/community/contributing-participating/log-of-mariadb-contributions
*/

struct show_table_contributors_st show_table_contributors[]= {
  /* MariaDB Foundation sponsors, alphabetical by tier */
  {"Amazon", "https://www.amazon.com/", "Diamond Sponsor of the MariaDB Foundation"},
  {"Acronis", "https://www.acronis.com/", "Platinum Sponsor of the MariaDB Foundation"},
  {"Alibaba Cloud", "https://www.alibabacloud.com/", "Platinum Sponsor of the MariaDB Foundation"},
  {"C<onstructor", "https://www.constructor.org/", "Platinum Sponsor of the MariaDB Foundation"},
  {"Development Bank of Singapore", "https://www.dbs.com/", "Platinum Sponsor of the MariaDB Foundation"},
  {"Intel", "https://www.intel.com/", "Platinum Sponsor of the MariaDB Foundation"},
  {"MariaDB plc", "https://mariadb.com/", "Founding member, Platinum Sponsor of the MariaDB Foundation"},
  {"ServiceNow", "https://servicenow.com/", "Platinum Sponsor of the MariaDB Foundation"},
  {"WebPros", "https://webpros.com/", "Platinum Sponsor of the MariaDB Foundation"},
  {"IBM", "https://www.ibm.com/", "Gold Sponsor of the MariaDB Foundation"},
  {"IONOS", "https://www.ionos.com/", "Gold Sponsor of the MariaDB Foundation"},
  {"Automattic", "https://automattic.com/", "Silver Sponsor of the MariaDB Foundation"},
  {"SkySQL", "https://skysql.com/", "Silver Sponsor of the MariaDB Foundation"},
  {"team.blue", "https://team.blue/", "Silver Sponsor of the MariaDB Foundation"},
  {"Tencent Cloud", "https://cloud.tencent.com/", "Silver Sponsor of the MariaDB Foundation"},
  {"Wikimedia Foundation", "https://www.wikimediafoundation.org/", "Silver Sponsor of the MariaDB Foundation"},
  {"Cyber Leo", "https://cyberleo.com/", "Bronze Sponsor of the MariaDB Foundation"},
  {"Hetzner", "https://www.hetzner.com/", "Bronze Sponsor of the MariaDB Foundation"},
  {"Rumahweb", "https://rumahweb.com/", "Bronze Sponsor of the MariaDB Foundation"},
  {"Tasjeel.ae", "https://tasjeel.ae/", "Bronze Sponsor of the MariaDB Foundation"},
  {"Galera Cluster", "https://galeracluster.com/", "Sponsor of the MariaDB Foundation"},
  {"Percona", "https://www.percona.com/", "Sponsor of the MariaDB Foundation"},
  {"Vettabase", "https://vettabase.com/", "Technology partner of the MariaDB Foundation"},
  {"Booking.com", "", "Previous Sponsor of the MariaDB Foundation"},
  {"Jelastic.com", "", "Previous Sponsor of the MariaDB Foundation"},
  {"Microsoft", "", "Previous Sponsor of the MariaDB Foundation"},
  {"Nexedi", "", "Previous Sponsor of the MariaDB Foundation"},
  {"Open Query", "", "Previous Sponsor of the MariaDB Foundation"},
  {"Planeetta Web Hosting", "", "Previous Sponsor of the MariaDB Foundation"},
  {"SpringbokSQL", "", "Previous Sponsor of the MariaDB Foundation"},
  {"Tencent Games", "", "Previous Sponsor of the MariaDB Foundation"},
  {"Tencent Game DBA", "", "Previous Sponsor of the MariaDB Foundation"},
  {"Tencent TDSQL", "", "Previous Sponsor of the MariaDB Foundation"},
  {"Verkkokauppa", "", "Previous Sponsor of the MariaDB Foundation"},
  {"Virtuozzo", "", "Previous Sponsor of the MariaDB Foundation"},
  {"Visma", "", "Previous Sponsor of the MariaDB Foundation"},
  {"Webyog", "", "Previous Sponsor of the MariaDB Foundation"},

  /* Sponsors of important features */
  {"Google", "USA", "Sponsoring encryption, parallel replication and GTID"},
  {"Facebook", "USA", "Sponsoring non-blocking API, LIMIT ROWS EXAMINED etc"},

  /* Individual contributors, names in historical order, newer first */
  {"Ronald Bradford", "Brisbane, Australia", "EFF contribution for UC2006 Auction"},
  {"Sheeri Kritzer", "Boston, Mass. USA", "EFF contribution for UC2006 Auction"},
  {"Mark Shuttleworth", "London, UK.", "EFF contribution for UC2006 Auction"},
  {NULL, NULL, NULL}
};

#endif /* CONTRIBUTORS_INCLUDED */
