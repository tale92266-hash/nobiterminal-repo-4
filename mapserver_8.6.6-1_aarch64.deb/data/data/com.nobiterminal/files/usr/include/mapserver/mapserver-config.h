#ifndef _MAPSERVER_CONFIG_H
#define _MAPSERVER_CONFIG_H

/* #undef USE_PROJ */
#define USE_PBF 1
/* #undef USE_POSTGIS */
/* #undef USE_GDAL */
/* #undef USE_PIXMAN */
/* #undef USE_OGR */
#define USE_WMS_SVR 1
#define USE_WCS_SVR 1
#define USE_WFS_SVR 1
#define USE_SOS_SVR 1
#define USE_OGCAPI_SVR 1
#define USE_WFS_LYR 1
#define USE_WMS_LYR 1
#define USE_CURL 1
#define USE_CAIRO 1
#define USE_GEOS 1
/* #undef USE_GIF */
#define USE_JPEG 1
#define USE_PNG 1
#define USE_ICONV 1
/* #undef USE_FRIBIDI */
/* #undef USE_HARFBUZZ */
#define USE_LIBXML2 1
/* #undef USE_FASTCGI */
/* #undef USE_MYSQL */
/* #undef USE_THREAD */
#define USE_KML 1
/* #undef USE_ORACLESPATIAL */
/* #undef USE_EXEMPI */
/* #undef USE_XMLMAPFILE */
/* #undef USE_GENERIC_MS_NINT */
/* #undef POSTGIS_HAS_SERVER_VERSION */
/* #undef USE_SVG_CAIRO */
/* #undef USE_RSVG */
/* #undef USE_SDE */
/* #undef SDE64 */
/* #undef USE_EXTENDED_DEBUG */
/* #undef USE_V8_MAPSCRIPT */
#define USE_PCRE2 1

/*windows specific hacks*/
#if defined(_WIN32)
/* #undef REGEX_MALLOC */
/* #undef USE_GENERIC_MS_NINT */
#endif


/* #undef HAVE_STRRSTR */
#define HAVE_STRCASECMP 1
#define HAVE_STRCASESTR 1
/* #undef HAVE_STRDUP */
#define HAVE_STRLCAT 1
#define HAVE_STRLCPY 1
#define HAVE_STRLEN 1
#define HAVE_STRNCASECMP 1
#define HAVE_VSNPRINTF 1
#define HAVE_DLFCN_H 1

#define HAVE_LRINTF 1
#define HAVE_LRINT 1
#define HAVE_SYNC_FETCH_AND_ADD 1
     

#endif
