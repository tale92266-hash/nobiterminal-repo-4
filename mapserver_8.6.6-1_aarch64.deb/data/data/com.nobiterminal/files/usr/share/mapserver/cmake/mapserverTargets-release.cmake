#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "mapserver" for configuration "Release"
set_property(TARGET mapserver APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(mapserver PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libmapserver.so"
  IMPORTED_SONAME_RELEASE "libmapserver.so"
  )

list(APPEND _cmake_import_check_targets mapserver )
list(APPEND _cmake_import_check_files_for_mapserver "${_IMPORT_PREFIX}/lib/libmapserver.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
