/*
 * ministream - minimal (subset) appstream metadata parser
 * Copyright (c) 2026  Florian Leander Singer <sp1rit@disroot.org>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, see <https://www.gnu.org/licenses/>.
 */

#ifndef __MINISTREAM_VERSION_H__
#define __MINISTREAM_VERSION_H__

#include <glib.h>

G_BEGIN_DECLS

/**
 * MS_MAJOR_VERSION:
 *
 * Ministream major version component.
 */
#define MS_MAJOR_VERSION (0)

/**
 * MS_MINOR_VERSION:
 *
 * Ministream minor version component.
 */
#define MS_MINOR_VERSION (99)

/**
 * MS_CHECK_VERSION:
 * @major: minimum required major version
 * @minor: minimum required minor version
 *
 * Compile-time version checking. Evaluates to `TRUE` if the version
 * of Ministream is greater than the required one.
 */
#define MS_CHECK_VERSION(major,minor) \
	(MS_MAJOR_VERSION > (major) || \
	 (MS_MAJOR_VERSION == (major) && MS_MINOR_VERSION >= (minor)))

/* --- */

#if (defined(_WIN32) || defined(__CYGWIN__)) && !defined(MS_STATIC_COMPILATION)
#define _MS_EXPORT __declspec(dllexport) extern
#define _MS_IMPORT __declspec(dllimport) extern
#elif __GNUC__ >= 4
#define _MS_EXPORT __attribute__((visibility("default"))) extern
#define _MS_IMPORT extern
#else
#define _MS_EXPORT extern
#define _MS_IMPORT extern
#endif

#if defined(MS_COMPILATION)
#define MS_PUBLIC_API _MS_EXPORT
#else
#define MS_PUBLIC_API _MS_IMPORT
#endif

G_END_DECLS

#endif // __MINISTREAM_VERSION_H__
