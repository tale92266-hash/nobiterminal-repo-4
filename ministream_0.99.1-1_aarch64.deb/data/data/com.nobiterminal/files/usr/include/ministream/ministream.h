/*
 * ministream - minimal (subset) appstream metadata parser
 * Copyright (c) 2026  Florian Leander Singer <sp1rit@disroot.org>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, see <https://www.gnu.org/licenses/>.
 */

#ifndef __MINISTREAM_H__
#define __MINISTREAM_H__

#include <glib-object.h>
#include <ministream-version.h>

G_BEGIN_DECLS

#define MS_ERROR (ms_error_quark())
MS_PUBLIC_API
GQuark ms_error_quark(void);

#define MS_TYPE_ERROR (ms_error_get_type())
MS_PUBLIC_API
GType ms_error_get_type(void);
typedef enum {
  MS_ERROR_NO_COMPONENT,
  MS_ERROR_NO_IDENTIFIER
} MsError;

typedef struct _MsRelease MsRelease;
typedef struct _MsComponent MsComponent;

MS_PUBLIC_API
const gchar* ms_release_get_version(const MsRelease* self);
MS_PUBLIC_API
const gchar* ms_release_get_description(const MsRelease* self);

#define MS_TYPE_COMPONENT (ms_component_get_type())
MS_PUBLIC_API
GType ms_component_get_type(void);

MS_PUBLIC_API
MsComponent* ms_component_ref(MsComponent* self);
MS_PUBLIC_API
void ms_component_unref(MsComponent* self);

G_DEFINE_AUTOPTR_CLEANUP_FUNC (MsComponent, ms_component_unref)

MS_PUBLIC_API
const gchar* ms_component_get_id(const MsComponent* self);
MS_PUBLIC_API
const gchar* ms_component_get_name(const MsComponent* self);
MS_PUBLIC_API
const gchar* ms_component_get_homepage_uri(const MsComponent* self);
MS_PUBLIC_API
const gchar* ms_component_get_bugtracker_uri(const MsComponent* self);
MS_PUBLIC_API
const gchar* ms_component_get_help_uri(const MsComponent* self);
MS_PUBLIC_API
const gchar** ms_component_get_desktop_launchables(const MsComponent* self);
MS_PUBLIC_API
const MsRelease** ms_component_get_releases(const MsComponent* self, guint* len);
MS_PUBLIC_API
const gchar* ms_component_get_project_license(const MsComponent* self);
MS_PUBLIC_API
const gchar* ms_component_get_developer_name(const MsComponent* self);

/* --- */

MS_PUBLIC_API
MsComponent* ms_component_new_from_xml_data(const guchar* data, gsize len, GError** error);

G_END_DECLS

#endif // __MINISTREAM_H__
