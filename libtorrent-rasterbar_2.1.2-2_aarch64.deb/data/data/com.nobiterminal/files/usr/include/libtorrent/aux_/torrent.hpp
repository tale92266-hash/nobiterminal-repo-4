/*

Copyright (c) 2003-2022, Arvid Norberg
Copyright (c) 2003, Daniel Wallin
Copyright (c) 2004, Magnus Jonsson
Copyright (c) 2016-2021, Alden Torres
Copyright (c) 2017, AllSeeingEyeTolledEweSew
Copyright (c) 2017, Falcosc
Copyright (c) 2017, Pavel Pimenov
Copyright (c) 2018-2019, Steven Siloti
Copyright (c) 2018, d-komarov
Copyright (c) 2019, ghbplayer
Copyright (c) 2020, Paul-Louis Ageneau
Copyright (c) 2020, Viktor Elofsson
Copyright (c) 2021, AdvenT
Copyright (c) 2025, Vladimir Golovnev (glassez)
Copyright (c) 2021, Mark Scott
All rights reserved.

You may use, distribute and modify this code under the terms of the BSD license,
see LICENSE file.
*/

#ifndef TORRENT_TORRENT_HPP_INCLUDE
#define TORRENT_TORRENT_HPP_INCLUDE

#include <algorithm>
#include <vector>
#include <set>
#include <list>
#include <deque>
#include <limits> // for numeric_limits
#include <memory> // for unique_ptr
#include <mutex>
#include <optional>

#include "libtorrent/aux_/disable_warnings_push.hpp"
#include <boost/logic/tribool.hpp>
#include "libtorrent/aux_/disable_warnings_pop.hpp"

#include "libtorrent/fwd.hpp"
#include "libtorrent/torrent_handle.hpp"
#include "libtorrent/entry.hpp"
#include "libtorrent/torrent_info.hpp"
#include "libtorrent/socket.hpp"
#include "libtorrent/address.hpp"
#include "libtorrent/aux_/peer_list.hpp"
#include "libtorrent/aux_/tracker_manager.hpp"
#include "libtorrent/aux_/stat.hpp"
#include "libtorrent/alert.hpp"
#include "libtorrent/aux_/piece_picker.hpp"
#include "libtorrent/aux_/hash_picker.hpp"
#include "libtorrent/config.hpp"
#include "libtorrent/aux_/bandwidth_limit.hpp"
#include "libtorrent/aux_/bandwidth_queue_entry.hpp"
#include "libtorrent/storage_defs.hpp"
#include "libtorrent/assert.hpp"
#include "libtorrent/aux_/session_interface.hpp"
#include "libtorrent/aux_/time.hpp"
#include "libtorrent/aux_/deadline_timer.hpp"
#include "libtorrent/aux_/peer_class_set.hpp"
#include "libtorrent/aux_/link.hpp"
#include "libtorrent/aux_/vector_utils.hpp"
#include "libtorrent/aux_/debug.hpp"
#include "libtorrent/piece_block.hpp"
#include "libtorrent/disk_interface.hpp"
#include "libtorrent/aux_/file_progress.hpp"
#include "libtorrent/aux_/suggest_piece.hpp"
#include "libtorrent/units.hpp"
#include "libtorrent/aux_/vector.hpp"
#include "libtorrent/aux_/deferred_handler.hpp"
#include "libtorrent/aux_/allocating_handler.hpp"
#include "libtorrent/aux_/announce_entry.hpp"
#include "libtorrent/extensions.hpp" // for add_peer_flags_t
#include "libtorrent/aux_/ssl.hpp"
#include "libtorrent/aux_/tracker_list.hpp"
#include "libtorrent/web_seed_entry.hpp"

#if TORRENT_USE_RTC
    #include "libtorrent/aux_/rtc_signaling.hpp"
    #include "libtorrent/aux_/rtc_stream.hpp"
#endif

// define as 0 to disable. 1 enables debug output of the pieces and requested
// blocks. 2 also enables trace output of the time critical piece picking
// logic
#define TORRENT_DEBUG_STREAMING 0

namespace libtorrent::aux {

	struct tracker_request;
	class http_parser;
	struct bt_peer_connection;

	using web_seed_flag_t = flags::bitfield_flag<std::uint8_t, struct web_seed_flag_tag>;

	// internal
	enum class waste_reason
	{
		piece_timed_out, piece_cancelled, piece_unknown, piece_seed
		, piece_end_game, piece_closing
		, max
	};

	TORRENT_EXTRA_EXPORT std::int64_t calc_bytes(file_storage const& fs, piece_count const& pc);

#ifndef TORRENT_DISABLE_STREAMING
	struct time_critical_piece
	{
		// when this piece was first requested
		time_point first_requested;
		// when this piece was last requested
		time_point last_requested;
		// by what time we want this piece
		time_point deadline;
		// 1 = send alert with piece data when available
		deadline_flags_t flags;
		// how many peers it's been requested from
		int peers;
		// the piece index
		piece_index_t piece;
#if TORRENT_DEBUG_STREAMING > 0
		// the number of multiple requests are allowed
		// to blocks still not downloaded (debugging only)
		int timed_out;
#endif
		bool operator<(time_critical_piece const& rhs) const
		{ return deadline < rhs.deadline; }
	};
#endif // TORRENT_DISABLE_STREAMING

	// this is the internal representation of web seeds
	struct web_seed_t : web_seed_entry
	{
		explicit web_seed_t(web_seed_entry const& wse);
		web_seed_t(std::string const& url_
			, std::string const& auth_ = std::string()
			, web_seed_entry::headers_t const& extra_headers_ = web_seed_entry::headers_t());

		// if this is > now, we can't reconnect yet
		time_point32 retry = aux::time_now32();

		// if the hostname of the web seed has been resolved,
		// these are its IP addresses
		std::vector<tcp::endpoint> endpoints;

		// this is the peer_info field used for the
		// connection, just to count hash failures
		// it's also used to hold the peer_connection
		// pointer, when the web seed is connected
		ipv4_peer peer_info{tcp::endpoint(), true, {}};

		// this is initialized to true, but if we discover the
		// server not to support it, it's set to false, and we
		// make larger requests.
		bool supports_keepalive = true;

		// this indicates whether or not we're resolving the
		// hostname of this URL
		bool resolving = false;

		// if the user wanted to remove this while
		// we were resolving it. In this case, we set
		// the removed flag to true, to make the resolver
		// callback remove it
		bool removed = false;

		// this indicates whether this web seed has any files. A server that only
		// redirects to other servers for instance, may not have any files and
		// once we've seen all redirects, there's no point in connecting to it
		// again.
		bool interesting = true;

		// if this is true, this URL was created by a redirect and should not be
		// saved in the resume data
		bool ephemeral = false;

		// this is set to true when this web seed was created from a redirect
		// from a global IP, and SSRF mitigation is enabled. It prevents this
		// web seed from resolving to any local network IPs.
		bool no_local_ips = false;

		// This means we want to preserve the web seed in resume data, but not
		// use it for the remainder of this session. For example:
		// this web seed maye have responded with a redirect. The redirected
		// URLs have been added as ephemeral. If an ephemeral URL is redirected,
		// its web seed entry is removed. It could also mean we don't support
		// the URL protocol, but maybe another client may support it.
		bool disabled = false;

		// if the web server doesn't support keepalive or a block request was
		// interrupted, the block received so far is kept here for the next
		// connection to pick up
		peer_request restart_request = { piece_index_t(-1), -1, -1};
		aux::vector<char> restart_piece;

		// this maps file index to a URL it has been redirected to. If an entry is
		// missing, it means it has not been redirected and the full path should
		// be constructed normally based on the filename. All redirections are
		// relative to the web seed hostname root.
		std::map<file_index_t, std::string> redirects;

		// if this bitfield is non-empty, it represents the files this web server
		// has.
		typed_bitfield<file_index_t> have_files;
#if defined __GNUC__ && defined _GLIBCXX_DEBUG
		// this works around a bug in libstdc++'s checked iterators
		// http://stackoverflow.com/questions/22915325/avoiding-self-assignment-in-stdshuffle
		web_seed_t& operator=(web_seed_t&& rhs) noexcept
		{
			if (&rhs == this) return *this;

			web_seed_entry::operator=(std::move(rhs));
			retry = std::move(rhs.retry);
			endpoints = std::move(rhs.endpoints);
			peer_info = std::move(rhs.peer_info);
			supports_keepalive = std::move(rhs.supports_keepalive);
			resolving = std::move(rhs.resolving);
			removed = std::move(rhs.removed);
			ephemeral = std::move(rhs.ephemeral);
			no_local_ips = std::move(rhs.no_local_ips);
			disabled = std::move(rhs.disabled);
			restart_request = std::move(rhs.restart_request);
			restart_piece = std::move(rhs.restart_piece);
			redirects = std::move(rhs.redirects);
			have_files = std::move(rhs.have_files);
			return *this;
		}

		web_seed_t& operator=(web_seed_t const&) = default;
		web_seed_t(web_seed_t const&) = default;
#endif
	};

	// tracks the total time some condition has held (e.g. "this torrent is
	// seeding"), as an accumulated duration plus an anchor timestamp for
	// the current live segment, if any. All transitions go through
	// set_live(), which is the only place that flushes the live segment
	// into the accumulator and re-anchors it. Callers just report
	// whether the condition holds.
	struct accrued_time
	{
		seconds32 get(time_point32 const now) const
		{
			return m_live ? m_total + duration_cast<seconds32>(now - m_anchor) : m_total;
		}

		void set_live(bool const live, time_point32 const now)
		{
			if (live == m_live)
				return;
			if (m_live)
				m_total += duration_cast<seconds32>(now - m_anchor);
			else
				m_anchor = now;
			m_live = live;
		}

		// only meant for initializing from resume data
		void set_total(seconds32 const t) { m_total = t; }

	private:
		seconds32 m_total{0};
		time_point32 m_anchor{aux::time_now32()};
		bool m_live = false;
	};

	struct TORRENT_EXTRA_EXPORT torrent_hot_members
	{
		torrent_hot_members(aux::session_interface& ses
			, add_torrent_params const& p, bool session_paused);

	protected:
		// the piece picker. This is allocated lazily. When we don't
		// have anything in the torrent (for instance, if it hasn't
		// been started yet) or if we have everything, there is no
		// picker. It's allocated on-demand the first time we need
		// it in torrent::need_picker(). In order to tell the
		// difference between having everything and nothing in
		// the case there is no piece picker, see m_have_all.
		std::unique_ptr<piece_picker> m_picker;

		std::unique_ptr<hash_picker> m_hash_picker;

		// TODO: make this a raw pointer. perhaps keep the shared_ptr
		// around further down the object to maintain an owner
#if TORRENT_ABI_VERSION < 4
		std::shared_ptr<torrent_info> m_torrent_file;
#else
		std::shared_ptr<torrent_info const> m_torrent_file;
#endif
		renamed_files m_renamed_files;

		// This is the sum of all non-pad file sizes. In the next major version
		// this is stored in file_storage and no longer need to be kept here.
		std::int64_t m_size_on_disk = 0;

		// a back reference to the session
		// this torrent belongs to.
		aux::session_interface& m_ses;

		// this vector is sorted at all times, by the pointer value.
		// use sorted_insert() and sorted_find() on it. The GNU STL
		// implementation on Darwin uses significantly less memory to
		// represent a vector than a set, and this set is typically
		// relatively small, and it's cheap to copy pointers.
		aux::vector<peer_connection*> m_connections;

		// the scrape data from the tracker response, this
		// is optional and may be 0xffffff
		std::uint32_t m_complete:24;

		// set to true when this torrent may not download anything
		std::uint32_t m_upload_mode:1;

		// this is set to false as long as the connections
		// of this torrent haven't been initialized. If we
		// have metadata from the start, connections are
		// initialized immediately, if we didn't have metadata,
		// they are initialized right after files_checked().
		// valid_resume_data() will return false as long as
		// the connections aren't initialized, to avoid
		// them from altering the piece-picker before it
		// has been initialized with files_checked().
		std::uint32_t m_connections_initialized:1;

		// is set to true when the torrent has
		// been aborted.
		std::uint32_t m_abort:1;

		// is true if this torrent has allows having peers
		std::uint32_t m_paused:1;

		// is true if the session is paused, in which case the torrent is
		// effectively paused as well.
		std::uint32_t m_session_paused:1;

#ifndef TORRENT_DISABLE_SHARE_MODE
		// this is set when the torrent is in share-mode
		std::uint32_t m_share_mode:1;
#endif

		// this is true if we have all pieces. If it's false,
		// it means we either don't have any pieces, or, if
		// there is a piece_picker object present, it contains
		// the state of how many pieces we have
		std::uint32_t m_have_all:1;

		// set to true when this torrent has been paused but
		// is waiting to finish all current download requests
		// before actually closing all connections, when in graceful pause mode,
		// m_paused is also true.
		std::uint32_t m_graceful_pause_mode:1;

		// state subscription. If set, a pointer to this torrent will be added
		// to the session_impl::m_torrent_lists[torrent_state_updates]
		// whenever this torrent's state changes (any state).
		std::uint32_t m_state_subscription:1;

		// the maximum number of connections for this torrent
		std::uint32_t m_max_connections:24;

		// the state of this torrent (queued, checking, downloading, etc.)
		std::uint32_t m_state:3;

		std::unique_ptr<aux::peer_list> m_peer_list;
	};

	// a torrent is a class that holds information
	// for a specific download. It updates itself against
	// the tracker
	struct TORRENT_EXTRA_EXPORT torrent
		: private single_threaded
		, private torrent_hot_members
		, request_callback
		, peer_class_set
		, std::enable_shared_from_this<torrent>
	{
		// add_torrent_params may contain large merkle trees that are best
		// moved. Deleting the const& overload ensures that it's always moved in.
		torrent(aux::session_interface& ses, bool session_paused, add_torrent_params&& p);
		torrent(aux::session_interface&, bool, add_torrent_params const& p) = delete;
		~torrent() override;

		// This may be called from multiple threads
		info_hash_t const& info_hash() const { return m_info_hash; }

		// This may be called from multiple threads
		std::shared_ptr<torrent_info const> get_torrent_file_external() const;


		bool is_deleted() const { return m_deleted; }

		// starts the announce timer
		void start();

		void added()
		{
			TORRENT_ASSERT(m_added == false);
			m_added = true;
			update_gauge();
		}

		void removed()
		{
			TORRENT_ASSERT(m_added == true);
			m_added = false;
			set_queue_position(no_pos);
			// make sure we decrement the gauge counter for this torrent
			update_gauge();
		}

		bool is_added() const { return m_added; }

		// returns which stats gauge this torrent currently
		// has incremented.
		int current_stats_state() const;

#ifndef TORRENT_DISABLE_EXTENSIONS
		void add_extension(std::shared_ptr<torrent_plugin>);
		void remove_extension(std::shared_ptr<torrent_plugin>);
		void add_extension_fun(std::function<std::shared_ptr<torrent_plugin>(torrent_handle const&, client_data_t)> const& ext
			, client_data_t userdata);
		void notify_extension_add_peer(tcp::endpoint const& ip
			, peer_source_flags_t src, add_peer_flags_t flags);
#endif

		peer_connection* find_lowest_ranking_peer() const;

#if TORRENT_USE_ASSERTS
		bool has_peer(peer_connection const* p) const
		{ return sorted_find(m_connections, p) != m_connections.end(); }
		bool is_single_thread() const { return single_threaded::is_single_thread(); }
#endif

		// this is called when the torrent has metadata.
		// it will initialize the storage and the piece-picker
		void init();

		void load_merkle_trees(aux::vector<std::vector<sha256_hash>, file_index_t> t
			, aux::vector<bitfield, file_index_t> mask
			, aux::vector<bitfield, file_index_t> verified);

		// find the peer that introduced us to the given endpoint. This is
		// used when trying to holepunch. We need the introducer so that we
		// can send a rendezvous connect message
		bt_peer_connection* find_introducer(tcp::endpoint const& ep) const;

		// if we're connected to a peer at ep, return its peer connection
		// only count BitTorrent peers
		bt_peer_connection* find_peer(tcp::endpoint const& ep) const;
		peer_connection* find_peer(peer_id const& pid);

		// checks to see if this peer id is used in one of our own outgoing
		// connections.
		bool is_self_connection(peer_id const& pid) const;

		void on_resume_data_checked(status_t status, storage_error const& error);
		void on_force_recheck(status_t status, storage_error const& error);
		void on_piece_hashed(aux::vector<sha256_hash> block_hashes,
			piece_index_t piece,
			sha1_hash const& piece_hash,
			storage_error const& error,
			std::uint8_t picker_gen);
		void files_checked();
		void start_checking();

		void start_announcing();
		void stop_announcing();

		void send_upload_only();

#ifndef TORRENT_DISABLE_SHARE_MODE
		void send_share_mode();
		void set_share_mode(bool s);
		bool share_mode() const { return m_share_mode; }
#endif

		// TODO: make graceful pause also finish all sending blocks
		// before disconnecting
		bool graceful_pause() const { return m_graceful_pause_mode; }

		torrent_flags_t flags() const;
		void set_flags(torrent_flags_t flags, torrent_flags_t mask);

		void set_upload_mode(bool b);
		bool upload_mode() const { return m_upload_mode || m_graceful_pause_mode; }
		bool is_upload_only() const { return is_finished() || upload_mode(); }

		int seed_rank(aux::session_settings const& s) const;

		void add_piece(piece_index_t piece, char const* data, add_piece_flags_t flags);
		void add_piece_async(piece_index_t piece, std::vector<char> data, add_piece_flags_t flags);
		void on_disk_write_complete(
			storage_error const& error, peer_request const& p, std::uint8_t picker_gen);

		void set_progress_ppm(int p) { m_progress_ppm = std::uint32_t(p); }
		struct read_piece_struct
		{
			boost::shared_array<char> piece_data;
			int blocks_left;
			bool fail;
			error_code error;
		};
		void read_piece(piece_index_t);
		void set_sequential_range(piece_index_t first_piece, piece_index_t last_piece);
		void set_sequential_range(piece_index_t first_piece);
		void on_disk_read_complete(disk_buffer_holder, storage_error const&
			, peer_request const&, std::shared_ptr<read_piece_struct>);

		storage_mode_t storage_mode() const;

		// this will flag the torrent as aborted. The main
		// loop in session_impl will check for this state
		// on all torrents once every second, and take
		// the necessary actions then.
		void abort();
		bool is_aborted() const { return m_abort; }
		void panic();

		void new_external_ip();

		torrent_status::state_t state() const
		{ return torrent_status::state_t(m_state); }
		void set_state(torrent_status::state_t s);

		// bumped every time the picker is reset for a fresh check. disk job
		// completion handlers compare this against the generation captured
		// at dispatch time to detect and ignore stale completions.
		std::uint8_t picker_generation() const { return m_picker_generation; }

		aux::session_settings const& settings() const;
		aux::session_interface& session() { return m_ses; }

		void set_sequential_download(bool sd);
		bool is_sequential_download() const
		{ return m_sequential_download || m_auto_sequential; }

		void queue_up();
		void queue_down();
		void set_queue_position(queue_position_t p);
		queue_position_t queue_position() const { return m_sequence_number; }
		// used internally
		void set_queue_position_impl(queue_position_t const p)
		{
			if (m_sequence_number == p) return;
			m_sequence_number = p;
			state_updated();
		}

		void second_tick(int tick_interval_ms);

		// see if we need to connect to web seeds, and if so,
		// connect to them
		void maybe_connect_web_seeds();

		std::string name() const;
		aux::allocation_slot name_idx(aux::stack_allocator& a);

		stat statistics() const { return m_stat; }
		std::optional<std::int64_t> bytes_left() const;

		void bytes_done(torrent_status& st, status_flags_t) const;

		void sent_bytes(int bytes_payload, int bytes_protocol);
		void received_bytes(int bytes_payload, int bytes_protocol);
		void trancieve_ip_packet(int bytes, bool ipv6);
		void sent_syn(bool ipv6);
		void received_synack(bool ipv6);

		void set_ip_filter(std::shared_ptr<const ip_filter> ipf);
		void privileged_port_updated();
		void port_filter_updated();
		ip_filter const* get_ip_filter() { return m_ip_filter.get(); }

		std::string resolve_filename(file_index_t file) const;
		void handle_exception();

		enum class disk_class { none, write };
		void handle_disk_error(string_view job_name
			, storage_error const& error, peer_connection* c = nullptr
			, disk_class rw = disk_class::none);
		void handle_inconsistent_hashes(piece_index_t piece);
		void clear_error();

		void set_error(error_code const& ec, file_index_t file);
		bool has_error() const { return !!m_error; }
		error_code error() const { return m_error; }

		void flush_cache();
		void pause(pause_flags_t flags = {});
		void resume();

		void set_session_paused(bool b);
		void set_paused(bool b, pause_flags_t flags = {});
		void set_announce_to_dht(bool b) { m_announce_to_dht = b; }
		void set_announce_to_trackers(bool b) { m_announce_to_trackers = b; }
		void set_announce_to_lsd(bool b) { m_announce_to_lsd = b; }

		void stop_when_ready(bool b);

		void step_session_time(int seconds);
		void do_pause();
		void do_resume();

		seconds32 finished_time() const;
		seconds32 active_time() const;
		seconds32 seeding_time() const;
		seconds32 upload_mode_time() const;

		bool is_paused() const;
		bool is_torrent_paused() const { return m_paused; }
		void force_recheck();
		void save_resume_data(resume_data_flags_t flags);

		bool need_save_resume_data(resume_data_flags_t flags) const
		{
			return bool(m_need_save_resume_data & flags);
		}

		void set_need_save_resume(resume_data_flags_t const flag)
		{
			if (m_need_save_resume_data & flag) return;
			m_need_save_resume_data |= flag;
			state_updated();
		}

		add_torrent_params get_resume_data(resume_data_flags_t flags) const;

		bool is_auto_managed() const { return m_auto_managed; }
		void auto_managed(bool a);

		bool should_check_files() const;

		bool delete_files(remove_flags_t options);
		void peers_erased(std::vector<torrent_peer*> const& peers);

		// like peers_erased(), but for when every torrent_peer is invalid
		// at once, avoiding a pointer match per peer on the extension and
		// picker side
		void all_peers_erased();

#if TORRENT_ABI_VERSION == 1
#if !TORRENT_NO_FPU
		void file_progress_float(aux::vector<float, file_index_t>& fp);
#endif
#endif // TORRENT_ABI_VERSION

		void post_piece_availability();
		void piece_availability(aux::vector<int, piece_index_t>& avail) const;

		void set_piece_priority(piece_index_t index, download_priority_t priority);
		download_priority_t piece_priority(piece_index_t index) const;

		void prioritize_pieces(aux::vector<download_priority_t, piece_index_t> const& pieces);
		void prioritize_piece_list(std::vector<std::pair<piece_index_t, download_priority_t>> const& pieces);
		void piece_priorities(aux::vector<download_priority_t, piece_index_t>*) const;

		void set_file_priority(file_index_t index, download_priority_t priority);
		download_priority_t file_priority(file_index_t index) const;

		void on_file_priority(storage_error const& err, aux::vector<download_priority_t, file_index_t> prios);
		void prioritize_files(aux::vector<download_priority_t, file_index_t> files);
		void file_priorities(aux::vector<download_priority_t, file_index_t>*) const;
		void post_file_priorities();

#ifndef TORRENT_DISABLE_STREAMING
		void cancel_non_critical();
		void set_piece_deadline(piece_index_t piece, int t, deadline_flags_t flags);
		void reset_piece_deadline(piece_index_t piece);
		void clear_time_critical();
#endif // TORRENT_DISABLE_STREAMING

		void update_piece_priorities(
			aux::vector<download_priority_t, file_index_t> const& file_prios);

		void post_status(status_flags_t flags);
		void status(torrent_status* st, status_flags_t flags);

		// this torrent changed state, if the user is subscribing to
		// it, add it to the m_state_updates list in session_impl
		void state_updated();

		void file_progress(aux::vector<std::int64_t, file_index_t>& fp, file_progress_flags_t flags);
		void post_file_progress(file_progress_flags_t flags);

#if TORRENT_ABI_VERSION == 1
		void use_interface(std::string net_interface);
#endif

		void connect_to_url_seed(std::list<web_seed_t>::iterator);
		bool connect_to_peer(torrent_peer*, bool ignore_limit = false);
		bool create_peer_connection(torrent_peer* peerinfo, aux::socket_type socket, tcp::endpoint endpoint);

		int priority() const;
#if TORRENT_ABI_VERSION == 1
		void set_priority(int prio);
#endif // TORRENT_ABI_VERSION

// --------------------------------------------
		// BANDWIDTH MANAGEMENT

		void set_upload_limit(int limit);
		int upload_limit() const;
		void set_download_limit(int limit);
		int download_limit() const;

		peer_class_t peer_class() const { return m_peer_class; }

		void set_max_uploads(int limit, bool state_update = true);
		int max_uploads() const { return int(m_max_uploads); }
		void set_max_connections(int limit, bool state_update = true);
		int max_connections() const { return int(m_max_connections); }

// --------------------------------------------
		// PEER MANAGEMENT

		// A web seed entry that's added because of a redirect is flagged as
		// ephemeral. We don't want to save these in the resume data.
		static inline constexpr web_seed_flag_t ephemeral = 0_bit;
		// A web seed entry with this flag set is not allowed to resolve to an
		// IP on a local network. This is part of SSRF mitigation, as it may be
		// malicious
		static inline constexpr web_seed_flag_t no_local_ips = 1_bit;

		// add_web_seed won't add duplicates. If we have already added an entry
		// with this URL, we'll get back the existing entry
		web_seed_t* add_web_seed(std::string const& url
			, std::string const& auth = std::string()
			, web_seed_t::headers_t const& extra_headers = web_seed_entry::headers_t()
			, web_seed_flag_t flags = {});

		void remove_web_seed(std::string const& url);

		void retry_web_seed(peer_connection* p, std::optional<seconds32> retry = std::nullopt);

		void remove_web_seed_conn(web_seed_t* w);

		std::set<std::string> web_seeds() const;

		bool free_upload_slots() const
		{ return m_num_uploads < m_max_uploads; }

		bool choke_peer(peer_connection& c);
		bool unchoke_peer(peer_connection& c, bool optimistic = false);

		void trigger_unchoke() noexcept;
		void trigger_optimistic_unchoke() noexcept;

		// used by peer_connection to attach itself to a torrent
		// since incoming connections don't know what torrent
		// they're a part of until they have received an info_hash.
		// false means attach failed
		bool attach_peer(peer_connection* p);

		// this will remove the peer and make sure all
		// the pieces it had have their reference counter
		// decreased in the piece_picker
		void remove_peer(std::shared_ptr<peer_connection> p) noexcept;

		// cancel requests to this block from any peer we're
		// connected to on this torrent
		void cancel_block(piece_block block);

		bool want_tick() const;
		void update_want_tick();
		void update_state_list();

		bool want_peers() const;
		bool want_peers_download() const;
		bool want_peers_finished() const;

		void update_want_peers();
		void update_want_scrape();
		void update_gauge();

		bool try_connect_peer();
		torrent_peer* add_peer(tcp::endpoint const& adr
			, peer_source_flags_t source, pex_flags_t flags = {});
		bool ban_peer(torrent_peer* tp);
		void update_peer_port(int port, torrent_peer* p, peer_source_flags_t src);
		void set_seed(torrent_peer* p, bool s);
		void set_upload_only(torrent_peer* p, bool s);
		void clear_failcount(torrent_peer* p);
		std::pair<aux::peer_list::iterator, aux::peer_list::iterator> find_peers(address const& a);

		// the number of peers that belong to this torrent
		int num_peers() const { return int(m_connections.size() - m_peers_to_disconnect.size()); }
		int num_seeds() const;
		int num_downloaders() const;

		using peer_iterator = std::vector<peer_connection*>::iterator;
		using const_peer_iterator = std::vector<peer_connection*>::const_iterator;

		const_peer_iterator begin() const { return m_connections.begin(); }
		const_peer_iterator end() const { return m_connections.end(); }

		peer_iterator begin() { return m_connections.begin(); }
		peer_iterator end() { return m_connections.end(); }

#if TORRENT_ABI_VERSION == 1
		void get_full_peer_list(std::vector<peer_list_entry>* v) const;
#endif
		void post_peer_info();
		void get_peer_info(std::vector<peer_info>* v);
		void get_download_queue(std::vector<partial_piece_info>* queue) const;
		void post_download_queue();
		void post_file_status();

		void update_auto_sequential();
	private:
#if TORRENT_USE_RTC
		void generate_rtc_offers(int count
			, std::function<void(error_code const&, std::vector<aux::rtc_offer>)> handler) override;
		void on_rtc_offer(aux::rtc_offer const& offer) override;
		void on_rtc_answer(aux::rtc_answer const& answer) override;
		void on_rtc_stream(aux::rtc_stream_init stream_init);
#endif
		void remove_connection(peer_connection const* p);
	public:
// --------------------------------------------
		// TRACKER MANAGEMENT

		// these are callbacks called by the tracker_connection instance
		// (either http_tracker_connection or udp_tracker_connection)
		// when this torrent got a response from its tracker request
		// or when a failure occurred
		void tracker_response(
			tracker_request const& r
			, address const& tracker_ip
			, std::list<address> const& tracker_ips
			, struct tracker_response const& resp) override;
		void tracker_request_error(tracker_request const& r
			, error_code const& ec, operation_t op, const std::string& msg
			, seconds32 retry_interval) override;
		void tracker_warning(tracker_request const& req
			, std::string const& msg) override;
		void tracker_scrape_response(tracker_request const& req
			, int complete, int incomplete, int downloaded, int downloaders) override;

		void update_scrape_state();

#if TORRENT_ABI_VERSION == 1
		// if no password and username is set
		// this will return an empty string, otherwise
		// it will concatenate the login and password
		// ready to be sent over http (but without
		// base64 encoding).
		std::string tracker_login() const;
#endif

		// generate the tracker key for this torrent.
		// The key is passed to http trackers as ``&key=``.
		std::uint32_t tracker_key() const;

		// the peer id for tracker interaction only, generated when we add the torrent
		peer_id const& pid() const { return m_peer_id; }

		// if we need a connect boost, connect some peers
		// immediately
		void do_connect_boost();

		// forcefully sets next_announce to the current time
		void force_tracker_request(time_point, int tracker_idx, reannounce_flags_t flags);
		void force_tracker_request_url(time_point, std::string const& url, reannounce_flags_t flags);
		void scrape_tracker(int idx, bool user_triggered);
		void scrape_tracker_url(std::string url, bool user_triggered);
		void scrape_tracker_impl(aux::announce_entry& ae, bool user_triggered);
		void announce_with_tracker(event_t = event_t::none, bool high_priority = false);
		void announce_tracker_now(aux::announce_entry& ae, event_t e, bool high_priority);

		// populates the fields of a tracker_request that describe this
		// torrent's state, i.e. everything that's the same regardless of
		// which tracker it's being sent to. The caller still needs to set
		// the per-tracker fields (trackerid, url, i2p bit).
		tracker_request build_tracker_request(event_t e);

		// resolves the event type, sends req to the tracker for a single
		// endpoint/info-hash, and updates that endpoint's announce state
		// (updating, next_announce, min_announce) and posts the
		// tracker_announce_alert. Does not touch any tier-selection state;
		// callers that have one (announce_with_tracker) update it themselves.
		void send_tracker_request(tracker_request& req,
			aux::announce_endpoint& aep,
			aux::announce_infohash& a,
			protocol_version ih,
			event_t e,
			bool high_priority,
			time_point32 now);

#ifndef TORRENT_DISABLE_DHT
		void dht_announce();
#endif

#if TORRENT_ABI_VERSION == 1
		// sets the username and password that will be sent to
		// the tracker
		void set_tracker_login(std::string const& name, std::string const& pw);
#endif

// --------------------------------------------
		// PIECE MANAGEMENT

#ifndef TORRENT_DISABLE_SHARE_MODE
		void recalc_share_mode();
#endif

#ifndef TORRENT_DISABLE_SUPERSEEDING
		bool super_seeding() const
		{
			// we're not super seeding if we're not a seed
			return m_super_seeding;
		}

		void set_super_seeding(bool on);
		piece_index_t get_piece_to_super_seed(typed_bitfield<piece_index_t> const&);
#endif

		// returns true if we have downloaded the given piece
		// but not necessarily flushed it to disk
		bool have_piece(piece_index_t index) const
		{
			if (!valid_metadata()) return false;
			if (!has_picker()) return m_have_all;
			return m_picker->have_piece(index);
		}

		// returns true if we have downloaded the given piece
		bool user_have_piece(piece_index_t index) const
		{
			if (!valid_metadata()) return false;
			if (index < piece_index_t{0} || index >= m_torrent_file->end_piece()) return false;
			if (!has_picker()) return m_have_all;
			return m_picker->have_piece(index);
		}

#ifndef TORRENT_DISABLE_PREDICTIVE_PIECES
		// a predictive piece is a piece that we might
		// not have yet, but still announced to peers, anticipating that
		// we'll have it very soon
		bool is_predictive_piece(piece_index_t index) const
		{
			return std::binary_search(m_predictive_pieces.begin(), m_predictive_pieces.end(), index);
		}
#endif // TORRENT_DISABLE_PREDICTIVE_PIECES

	private:

		// called when we learn that we have a piece
		// only once per piece
		void we_have(piece_index_t index, bool loading_resume = false);

		// process the v2 block hashes for a piece
		boost::tribool on_blocks_hashed(piece_index_t piece
			, span<sha256_hash const> block_hashes);

	public:

		// the number of pieces that have passed
		// hash check, but aren't necessarily
		// flushed to disk yet
		int num_have() const
		{
			// pretend we have every piece when in seed mode
			if (m_seed_mode) return m_torrent_file->num_pieces();
			if (has_picker()) return m_picker->have().num_pieces;
			if (m_have_all) return m_torrent_file->num_pieces();
			return 0;
		}

		// when we get a have message, this is called for that piece
		void peer_has(piece_index_t index, peer_connection const* peer);

		// when we get a bitfield message, this is called for that piece
		void peer_has(typed_bitfield<piece_index_t> const& bits, peer_connection const* peer);

		void peer_has_all(peer_connection const* peer);

		void peer_lost(piece_index_t index, peer_connection const* peer);
		void peer_lost(typed_bitfield<piece_index_t> const& bits
			, peer_connection const* peer);

		int block_size() const
		{
			return valid_metadata()
				? (std::min)(m_torrent_file->piece_length(), default_block_size)
				: default_block_size;
		}

		bool disable_v1_hashes() const { return m_disable_v1_hashes; }

		// like torrent_info::piece_size_for_req(), but when disable_v1_hashes
		// was set at the time the torrent was added, the engine treats the torrent
		// as v2-only and requests v2-sized blocks, so pad-file regions are never
		// downloaded or written to disk. The flag is locked in at construct_storage()
		// time so a later setting change cannot cause a storage/engine mismatch.
		// Note: this is not a trivial accessor. For v2-only torrents it performs
		// an O(log n) std::upper_bound over the file list (in piece_size2()) to
		// resolve the file boundary that may shorten the piece. Cache the result
		// when calling it repeatedly for the same piece in a hot path.
		int piece_size_for_req(piece_index_t p) const
		{
			if (m_disable_v1_hashes)
				return m_torrent_file->layout().piece_size2(p);
			return m_torrent_file->piece_size_for_req(p);
		}

		peer_request to_req(piece_block const& p) const;
		// overload that takes a precomputed piece size to avoid recomputing
		// piece_size_for_req() in hot paths. piece_size MUST equal
		// piece_size_for_req(p.piece_index); this is checked by an assert in
		// debug builds.
		peer_request to_req(piece_block const& p, int piece_size) const;

		void disconnect_all(error_code const& ec, operation_t op);
		int disconnect_peers(int num, error_code const& ec);

		// every write to m_have_all must go through here: is_seed() and
		// is_finished() depend on it, and both feed update_state_timers()
		void set_have_all(bool b);

		// re-evaluates whether each of m_active_timer/m_seeding_timer/
		// m_finished_timer should be live right now, and updates them
		// accordingly. Must be called any time is_paused(), m_abort,
		// is_seed() or is_finished() may have changed
		void update_state_timers();

		// overloads for callers that already have "now" at hand and want to
		// query more than one of these in a row without re-reading the clock
		// each time
		seconds32 finished_time(time_point32 now) const { return m_finished_timer.get(now); }
		seconds32 active_time(time_point32 now) const { return m_active_timer.get(now); }
		seconds32 seeding_time(time_point32 now) const { return m_seeding_timer.get(now); }

		// called every time a block is marked as finished in the
		// piece picker. We might have completed the torrent and
		// we can delete the piece picker
		void maybe_done_flushing();

		// this is called when the torrent has completed
		// the download. It will post an event, disconnect
		// all seeds and let the tracker know we're finished.
		void completed();

#if TORRENT_USE_I2P
		void on_i2p_resolve(error_code const& ec, char const* dest, peer_source_flags_t const source);
		void add_i2p_peer(sha256_hash const& dest, peer_source_flags_t source);
		bool is_i2p() const { return m_i2p; }

		// returns true if this tracker is compatible with the torrent's
		// i2p mode. Used to keep announce_with_tracker() and
		// update_tracker_timer() in sync about which trackers will be
		// contacted. If they disagree, the timer may schedule an immediate
		// re-announce for a tracker that announce_with_tracker() will then
		// skip, causing a CPU spin.
		bool i2p_compatible_tracker(aux::announce_entry const& ae) const;
#else
		bool is_i2p() const { return false; }
#endif

		// this is the asio callback that is called when a name
		// lookup for a PEER is completed.
		void on_peer_name_lookup(error_code const&
			, std::vector<address> const&
			, int port
			, protocol_version);

		// this is the asio callback that is called when a name
		// lookup for a WEB SEED is completed.
		void on_name_lookup(error_code const&
			, std::vector<address> const&
			, int port
			, std::list<web_seed_t>::iterator);

		// an unspecified address in "a" means it's a placeholder (the hostname
		// is resolved by the proxy, see settings_pack::proxy_hostnames), so it
		// must not be used for ip_filter or SSRF checks
		void connect_web_seed(std::list<web_seed_t>::iterator web, tcp::endpoint a);

		// this is the asio callback that is called when a name
		// lookup for a proxy for a web seed is completed.
		void on_proxy_name_lookup(error_code const& e
			, std::vector<address> const& addrs
			, std::list<web_seed_t>::iterator web, int port);

		// re-evaluates whether this torrent should be considered inactive or not
		void on_inactivity_tick(error_code const& ec);


		// calculate the instantaneous inactive state (the externally facing
		// inactive state is not instantaneous, but low-pass filtered)
		bool is_inactive_internal() const;

		// remove a web seed, or schedule it for removal in case there
		// are outstanding operations on it
		void remove_web_seed_iter(std::list<web_seed_t>::iterator web);

		// this is called when the torrent has finished. i.e.
		// all the pieces we have not filtered have been downloaded.
		// If no pieces are filtered, this is called first and then
		// completed() is called immediately after it.
		void finished();

		// This is the opposite of finished. It is called if we used
		// to be finished but enabled some files for download so that
		// we wasn't finished anymore.
		void resume_download();

		void verify_piece(piece_index_t piece);
		void on_piece_verified(aux::vector<sha256_hash> block_hashes,
			piece_index_t piece,
			sha1_hash const& piece_hash,
			storage_error const& error,
			std::uint8_t picker_gen);

		// this is called whenever a peer in this swarm becomes interesting
		// it is responsible for issuing a block request, if appropriate
		void peer_is_interesting(peer_connection& c);

		// piece_passed is called when a piece passes the hash check
		// this will tell all peers that we just got his piece
		// and also let the piece picker know that we have this piece
		// so it wont pick it for download
		void piece_passed(piece_index_t index);

		// piece_failed is called when a piece fails the hash check
		// for failures detected with v2 hashes the failing blocks(s)
		// are specified in blocks
		// *blocks must be sorted in ascending order*
		void piece_failed(piece_index_t index, std::vector<int> blocks = std::vector<int>());

		// the peers in "peers" participated in sending a bad piece. If
		// "known_bad_peer" is true, we know for sure the peers are guilty,
		// otherwise only one may be guilty (meaning we can't unconditionally
		// disconnect)
		void penalize_peers(std::set<torrent_peer*> const& peers
			, piece_index_t index
			, bool known_bad_peer);

		// this is the handler for hash failure piece synchronization
		// i.e. resetting the piece
		void on_piece_sync(piece_index_t piece, std::vector<int> const& blocks);

		// this is the handler for write failure piece synchronization
		void on_piece_fail_sync(piece_index_t piece, piece_block b);

		void add_redundant_bytes(int b, waste_reason reason);
		void add_failed_bytes(int b);

		// this is true if we have all the pieces, but not necessarily flushed them to disk
		bool is_seed() const;

		// this is true if we have all the pieces that we want
		// the pieces don't necessarily need to be flushed to disk
		bool is_finished() const;

		bool is_inactive() const;

		std::string save_path() const;
		aux::alert_manager& alerts() const;
		piece_picker& picker()
		{
			TORRENT_ASSERT(m_picker.get());
			return *m_picker;
		}
		piece_picker const& picker() const
		{
			TORRENT_ASSERT(m_picker.get());
			return *m_picker;
		}
		void need_picker();
		bool has_picker() const
		{
			return m_picker.get() != nullptr;
		}

		hash_picker& get_hash_picker()
		{
			TORRENT_ASSERT(m_hash_picker.get());
			return *m_hash_picker;
		}
		hash_picker const& get_hash_picker() const
		{
			TORRENT_ASSERT(m_hash_picker.get());
			return *m_hash_picker;
		}

		void need_hash_picker();
		bool has_hash_picker() const
		{
			return m_hash_picker.get() != nullptr;
		}

		void update_max_failcount()
		{
			if (!m_peer_list) return;
			torrent_state st = get_peer_list_state();
			m_peer_list->set_max_failcount(&st);
		}
		int num_known_peers() const { return m_peer_list ? m_peer_list->num_peers() : 0; }
		int num_connect_candidates() const { return m_peer_list ? m_peer_list->num_connect_candidates() : 0; }

		void clear_peers();

		bool has_storage() const { return bool(m_storage); }
		storage_index_t storage() const { return m_storage; }

		torrent_info const& torrent_file() const
		{ return *m_torrent_file; }

		hash_request pick_hashes(peer_connection* peer);
		std::vector<sha256_hash> get_hashes(hash_request const& req) const;
		bool add_hashes(hash_request const& req, span<sha256_hash> hashes);
		void hashes_rejected(hash_request const& req);
		void verify_block_hashes(piece_index_t index);

		std::shared_ptr<const torrent_info> get_torrent_file() const;
		renamed_files get_renamed_files() const;

#if TORRENT_ABI_VERSION < 4
		std::shared_ptr<torrent_info> get_torrent_copy_with_hashes() const;
#endif

		std::vector<std::vector<sha256_hash>> get_piece_layers() const;

		void post_trackers();
		std::vector<lt::announce_entry> trackers() const;

		// this sets all the "enabled" states on all trackers, giving them
		// all one more chance of being tried
		void enable_all_trackers();

		void replace_trackers(std::vector<lt::announce_entry> const& urls);

		// returns true if the tracker was added, and false if it was already
		// in the tracker list (in which case the source was added to the
		// entry in the list)
		bool add_tracker(lt::announce_entry const& url);

		torrent_handle get_handle();

		void write_resume_data(resume_data_flags_t const flags, add_torrent_params& ret) const;

		void seen_complete() { m_last_seen_complete = aux::posix_time(); }
		int time_since_complete() const { return int(aux::posix_time() - m_last_seen_complete); }
		time_t last_seen_complete() const { return m_last_seen_complete; }

		template <typename Fun, typename... Args>
		void wrap(Fun f, Args&&... a);

		// LOGGING
#ifndef TORRENT_DISABLE_LOGGING
		bool should_log() const override;
		void debug_log(const char* fmt, ...) const noexcept override TORRENT_FORMAT(2,3);

		void log_to_all_peers(char const* message);
		time_point m_dht_start_time;
#endif

		// DEBUG
#if TORRENT_USE_INVARIANT_CHECKS
		void check_invariant() const;
#endif

// --------------------------------------------
		// RESOURCE MANAGEMENT

		// flags are defined in storage.hpp
		void move_storage(std::string const& save_path, move_flags_t flags);

		// renames the file with the given index to the new name
		// the name may include a directory path
		// posts alert to indicate success or failure
		void rename_file(file_index_t index, std::string name);

		// unless this returns true, new connections must wait
		// with their initialization.
		bool ready_for_connections() const
		{ return m_connections_initialized; }
		bool valid_metadata() const
		{ return m_torrent_file->is_valid(); }
		bool are_files_checked() const
		{ return m_files_checked; }

		error_code initialize_merkle_trees();

		// parses the info section from the given
		// bencoded tree and moves the torrent
		// to the checker thread for initial checking
		// of the storage.
		// a return value of false indicates an error
		bool set_metadata(span<char const> metadata);

		queue_position_t sequence_number() const { return m_sequence_number; }

		bool seed_mode() const { return m_seed_mode; }

		enum class seed_mode_t { check_files, skip_checking };

		void leave_seed_mode(seed_mode_t checking);

		bool all_verified() const
		{ return int(m_num_verified) == m_torrent_file->num_pieces(); }
		bool verifying_piece(piece_index_t const piece) const
		{ return m_verifying.get_bit(piece); }
		void verifying(piece_index_t const piece)
		{
			TORRENT_ASSERT(m_verifying.get_bit(piece) == false);
			m_verifying.set_bit(piece);
		}
		bool verified_piece(piece_index_t piece) const
		{ return m_verified.get_bit(piece); }
		void verified(piece_index_t piece);

		// this is called once periodically for torrents
		// that are not private
		void lsd_announce();

		void update_last_upload() { m_last_upload = aux::time_now32(); }

		void set_apply_ip_filter(bool b);
		bool apply_ip_filter() const { return m_apply_ip_filter; }

#ifndef TORRENT_DISABLE_PREDICTIVE_PIECES
		std::vector<piece_index_t> const& predictive_pieces() const
		{ return m_predictive_pieces; }

		// this is called whenever we predict to have this piece
		// within one second
		void predicted_have_piece(piece_index_t index, time_duration duration);
#endif

		void clear_in_state_update()
		{
			TORRENT_ASSERT(m_links[aux::session_interface::torrent_state_updates].in_list());
			m_links[aux::session_interface::torrent_state_updates].clear();
		}

		void inc_num_connecting(torrent_peer* pp)
		{
			++m_num_connecting;
			if (pp->seed) ++m_num_connecting_seeds;
		}
		void dec_num_connecting(torrent_peer* pp)
		{
			TORRENT_ASSERT(m_num_connecting > 0);
			--m_num_connecting;
			if (pp->seed)
			{
				TORRENT_ASSERT(m_num_connecting_seeds > 0);
				--m_num_connecting_seeds;
			}
			TORRENT_ASSERT(m_num_connecting <= int(m_connections.size()));
		}

		bool is_ssl_torrent() const { return m_ssl_torrent; }
#ifdef TORRENT_SSL_PEERS
		void set_ssl_cert(std::string const& certificate
			, std::string const& private_key
			, std::string const& dh_params
			, std::string const& passphrase);
		void set_ssl_cert_buffer(std::string const& certificate
			, std::string const& private_key
			, std::string const& dh_params);
		ssl::context* ssl_ctx() const { return m_ssl_ctx.get(); }
#endif

		int num_time_critical_pieces() const
		{
#ifndef TORRENT_DISABLE_STREAMING
			return int(m_time_critical_pieces.size());
#else
			return 0;
#endif
		}

		int get_suggest_pieces(std::vector<piece_index_t>& p
			, typed_bitfield<piece_index_t> const& bits
			, int const n)
		{
			return m_suggest_pieces.get_pieces(p, bits, n);
		}
		void add_suggest_piece(piece_index_t index);

		client_data_t get_userdata() const { return m_userdata; }

		static constexpr int no_gauge_state = 0xf;

	private:

		void on_exception(std::exception const& e);
		void on_error(error_code const& ec);

		// trigger deferred disconnection of peers
		void on_remove_peers() noexcept;

		void ip_filter_updated();

		void inc_stats_counter(int c, int value = 1);

		// initialize the torrent_state structure passed to peer_list
		// member functions. Don't forget to also call peers_erased()
		// on the erased member after the peer_list call
		torrent_state get_peer_list_state();

		void construct_storage();
		void update_list(torrent_list_index_t list, bool in);

		void on_files_deleted(storage_error const& error);
		void on_torrent_paused();
		void on_storage_moved(status_t status, std::string const& path
			, storage_error const& error);
		void on_file_renamed(std::string const& filename
			, file_index_t file_idx
			, storage_error const& error);
		void on_cache_flushed(bool manually_triggered);

		// this is used when a torrent is being removed.It synchronizes with the
		// disk thread
		void on_torrent_aborted();

		// upload and download rate limits for the torrent
		void set_limit_impl(int limit, int channel, bool state_update = true);
		int limit_impl(int channel) const;

		void update_peer_interest(bool was_finished);

		void update_tracker_timer(time_point32 now);

		void on_tracker_announce(error_code const& ec);

#ifndef TORRENT_DISABLE_DHT
		static void on_dht_announce_response_disp(std::weak_ptr<torrent> t
			, protocol_version v, std::vector<tcp::endpoint> const& peers);
		void on_dht_announce_response(protocol_version v, std::vector<tcp::endpoint> const& peers);
		bool should_announce_dht() const;
#endif

#ifndef TORRENT_DISABLE_STREAMING
		void remove_time_critical_piece(piece_index_t piece, bool finished = false);
		void remove_time_critical_pieces(aux::vector<download_priority_t, piece_index_t> const& priority);
		void request_time_critical_pieces();
#endif // TORRENT_DISABLE_STREAMING

		void need_peer_list();

		std::shared_ptr<const ip_filter> m_ip_filter;

		// all time totals of uploaded and downloaded payload
		// stored in resume data
		std::int64_t m_total_uploaded = 0;
		std::int64_t m_total_downloaded = 0;

		// the number of bytes of pad files
		std::int64_t m_padding_bytes = 0;

		// this is a handle that keeps the storage object in the disk io subsystem
		// alive, as well as the index referencing the storage/torrent in the disk
		// I/O. When this destructs, the torrent will be removed from the disk
		// subsystem.
		storage_holder m_storage;

#ifdef TORRENT_SSL_PEERS
		std::unique_ptr<ssl::context> m_ssl_ctx;

		bool verify_peer_cert(bool const preverified, ssl::verify_context& ctx);

		void init_ssl(string_view cert);
#endif

		void setup_peer_class();

		// The list of web seeds in this torrent. Seeds with fatal errors are
		// removed from the set. It's important that iterators are not
		// invalidated as entries are added and removed from this list, hence the
		// std::list
		std::list<web_seed_t> m_web_seeds;

#ifndef TORRENT_DISABLE_EXTENSIONS
		std::list<std::shared_ptr<torrent_plugin>> m_extensions;
#endif

		// used for tracker announces
		deadline_timer m_tracker_timer;

		// used to detect when we are active or inactive for long enough
		// to trigger the auto-manage logic
		deadline_timer m_inactivity_timer;

		// this is the upload and download statistics for the whole torrent.
		// it's updated from all its peers once every second.
		stat m_stat;

		// -----------------------------

		// this vector is allocated lazily. If no file priorities are
		// ever changed, this remains empty. Any unallocated slot
		// implicitly means the file has priority 4.
		// TODO: this wastes 5 bits per file
		aux::vector<download_priority_t, file_index_t> m_file_priority;

		// any file priority updates attempted while another file priority update
		// is in-progress/outstanding with the disk I/O thread, are queued up in
		// this dictionary. Once the outstanding update comes back, all of these
		// are applied in one batch
		std::map<file_index_t, download_priority_t> m_deferred_file_priorities;

		// this object is used to track download progress of individual files
		aux::file_progress m_file_progress;

		// a queue of the most recent low-availability pieces we accessed on disk.
		// These are good candidates for suggesting other peers to request from
		// us.
		aux::suggest_piece m_suggest_pieces;

		aux::tracker_list m_trackers;

#ifndef TORRENT_DISABLE_STREAMING
		// this list is sorted by time_critical_piece::deadline
		std::vector<time_critical_piece> m_time_critical_pieces;
#endif

		std::string m_trackerid;
#if TORRENT_ABI_VERSION == 1
		// deprecated in 1.1
		std::string m_username;
		std::string m_password;
#endif

		std::string m_save_path;
		std::string m_part_file_dir;
		aux::cached_slot m_name_idx;

#ifndef TORRENT_DISABLE_PREDICTIVE_PIECES
		// this is a list of all pieces that we have announced
		// as having, without actually having yet. If we receive
		// a request for a piece in this list, we need to hold off
		// on responding until we have completed the piece and
		// verified its hash. If the hash fails, send reject to
		// peers with outstanding requests, and dont_have to other
		// peers. This vector is ordered, to make lookups fast.

		// TODO: 3 factor out predictive pieces and all operations on it into a
		// separate class (to use as member here instead)
		std::vector<piece_index_t> m_predictive_pieces;
#endif

		// v2 merkle tree for each file
		aux::vector<aux::merkle_tree, file_index_t> m_merkle_trees;

		// the performance counters of this session
		counters& m_stats_counters;

		// each bit represents a piece. a set bit means
		// the piece has had its hash verified. This
		// is only used in seed mode (when m_seed_mode
		// is true)
		typed_bitfield<piece_index_t> m_verified;

		// this means there is an outstanding, async, operation
		// to verify each piece that has a 1
		typed_bitfield<piece_index_t> m_verifying;

		// set if there's an error on this torrent
		error_code m_error;

		// used if there is any resume data. Some of the information from the
		// add_torrent_params struct are needed later in the torrent object's life
		// cycle, and not in the constructor. So we need to save it here
		std::unique_ptr<add_torrent_params> m_add_torrent_params;

		// if the torrent is started without metadata, it may
		// still be given a name until the metadata is received
		// once the metadata is received this field will no
		// longer be used and will be reset
		std::unique_ptr<std::string> m_name;

		// the posix time this torrent was added and when
		// it was completed. If the torrent isn't yet
		// completed, m_completed_time is 0
		std::time_t m_added_time;
		std::time_t m_completed_time;

		// this was the last time _we_ saw a seed in this swarm
		std::time_t m_last_seen_complete = 0;

		// this is the time last any of our peers saw a seed
		// in this swarm
		std::time_t m_swarm_last_seen_complete = 0;

		// keep a copy of the info-hash here, so it can be accessed from multiple
		// threads, and be cheap to access from the client
		info_hash_t m_info_hash;

		// protects m_torrent_file_external, which may be read from client
		// threads without holding the network thread lock
		mutable std::mutex m_torrent_file_mutex;
		std::shared_ptr<torrent_info const> m_torrent_file_external;

		// these are copied from the original .torrent file, and really just
		// here to allow re-creating the torrent file again (by
		// save_resume_data())
		std::string m_comment;
		std::string m_created_by;
		std::time_t m_creation_date;

	public:
		// these are the lists this torrent belongs to. For more
		// details about each list, see session_impl.hpp. Each list
		// represents a group this torrent belongs to and makes it
		// efficient to enumerate only torrents belonging to a specific
		// group. Such as torrents that want peer connections or want
		// to be ticked etc.

		// TODO: 3 factor out the links (as well as update_list() to a separate
		// class that torrent can inherit)
		aux::array<link, aux::session_interface::num_torrent_lists, torrent_list_index_t>
			m_links;

	private:

		// m_num_verified = m_verified.count()
		std::uint32_t m_num_verified = 0;

		// total time we've been active on this torrent, i.e. either (trying
		// to) download or seed, not counting time paused or stopped. Used
		// to have a bias towards keeping recently-started seeding torrents,
		// to avoid oscillation
		accrued_time m_active_timer;

		// total time we've been available as a seed on this torrent, not
		// counting time paused or stopped
		accrued_time m_seeding_timer;

		// total time we've been finished with this torrent, not counting
		// time paused or stopped
		accrued_time m_finished_timer;

		// when checking, this is the first piece we have not
		// issued a hash job for
		piece_index_t m_checking_piece{0};

		// the number of pieces we completed the check of
		piece_index_t m_num_checked_pieces{0};

		// bumped every time the picker is reset for a fresh check
		// (force_recheck(), handle_inconsistent_hashes()). in-flight disk
		// job completions capture this at dispatch time; a mismatch at
		// completion means the picker they were issued against no longer
		// exists. force_recheck() does not happen at a frequency anywhere
		// near wrapping an 8 bit counter.
		std::uint8_t m_picker_generation = 0;

		// if the error occurred on a file, this is the index of that file
		// there are a few special cases, when this is negative. See
		// set_error()
		file_index_t m_error_file;

		// the average time it takes to download one time critical piece
		std::int32_t m_average_piece_time = 0;

		// the average piece download time deviation
		std::int32_t m_piece_time_deviation = 0;

		// the number of bytes that has been
		// downloaded that failed the hash-test
		std::int64_t m_total_failed_bytes = 0;
		std::int64_t m_total_redundant_bytes = 0;

		// the sequence number for this torrent, this is a
		// monotonically increasing number for each added torrent
		queue_position_t m_sequence_number;

		// used to post a message to defer disconnecting peers
		std::vector<std::shared_ptr<peer_connection>> m_peers_to_disconnect;
		aux::deferred_handler m_deferred_disconnect;
		aux::handler_storage<aux::deferred_handler_max_size, aux::defer_handler> m_deferred_handler_storage;

		// these are the peer IDs we've used for our outgoing peer connections for
		// this torrent. If we get an incoming peer claiming to have one of these,
		// it's a connection to ourself, and we should reject it.
		std::set<peer_id> m_outgoing_pids;

		// for torrents who have a bandwidth limit, this is != 0
		// and refers to a peer_class in the session.
		peer_class_t m_peer_class{0};

		// of all peers in m_connections, this is the number
		// of peers that are outgoing and still waiting to
		// complete the connection. This is used to possibly
		// kick out these connections when we get incoming
		// connections (if we've reached the connection limit)
		std::uint16_t m_num_connecting = 0;

		// this is the peer id we generate when we add the torrent. Peers won't
		// use this (they generate their own peer ids) but this is used in case
		// the tracker returns peer IDs, to identify ourself in the peer list to
		// avoid connecting back to it.
		peer_id m_peer_id;

		// ==============================
		// The following members are specifically
		// ordered to make the 24 bit members
		// properly 32 bit aligned by inserting
		// 8 bits after each one
		// ==============================

		// if we're currently in upload-mode this is the time timestamp of when
		// we entered it
		time_point32 m_upload_mode_time = aux::time_now32();

		// true when this torrent should announce to
		// trackers
		std::uint8_t m_announce_to_trackers:1;

		// true when this torrent should announce to
		// the local network
		std::uint8_t m_announce_to_lsd:1;

		// is set to true every time there is an incoming
		// connection to this torrent
		std::uint8_t m_has_incoming:1;

		// this is set to true when the files are checked
		// before the files are checked, we don't try to
		// connect to peers
		std::uint8_t m_files_checked:1;

		// determines the storage state for this torrent.
		std::uint8_t m_storage_mode:2;

		// this is true while tracker announcing is enabled
		// is is disabled while paused and checking files
		std::uint8_t m_announcing:1;

		// this is true when the torrent has been added to the session. Before
		// then, it isn't included in the counters (session_stats)
		std::uint8_t m_added:1;

		// this is > 0 while the tracker deadline timer
		// is in use. i.e. one or more trackers are waiting
		// for a reannounce
		std::int8_t m_waiting_tracker = 0;

// ----

		// in case the piece picker hasn't been constructed
		// when this settings is set, this variable will keep
		// its value until the piece picker is created
		bool m_sequential_download:1;

		// this is set if the auto_sequential setting is true and this swarm
		// satisfies the criteria to be considered high-availability. i.e. if
		// there's mostly seeds in the swarm, download the files sequentially
		// for improved disk I/O performance.
		bool m_auto_sequential:1;

		// this means we haven't verified the file content
		// of the files we're seeding. the m_verified bitfield
		// indicates which pieces have been verified and which
		// haven't
		bool m_seed_mode:1;

#ifndef TORRENT_DISABLE_SUPERSEEDING
		// if this is true, we're currently super seeding this
		// torrent.
		bool m_super_seeding:1;
#endif

		// if this is set, whenever transitioning into a downloading/seeding state
		// from a non-downloading/seeding state, the torrent is paused.
		bool m_stop_when_ready:1;

		// when this is true, this torrent participates in the DHT
		bool m_enable_dht:1;

		// when this is true, this torrent participates in local service discovery
		bool m_enable_lsd:1;

		bool m_i2p:1;

		// set once at construct_storage() time when disable_v1_hashes is
		// enabled. locked in at that point so that changing the setting later
		// doesn't cause a mismatch between the storage (which was set up as
		// v2-only) and the engine's block-sizing logic.
		bool m_disable_v1_hashes:1;
		// ----

		// the maximum number of uploads for this torrent
		std::uint32_t m_max_uploads:24;

		// bits set to indicate which category of resume data state has updated
		resume_data_flags_t m_need_save_resume_data;

// ----

		// the number of unchoked peers in this torrent
		std::uint32_t m_num_uploads:24;

		// 4 unused bits

		// when this is true, this torrent supports peer exchange
		std::uint32_t m_enable_pex:1;

		// set to true if the session IP filter applies to this
		// torrent or not. Defaults to true.
		std::uint32_t m_apply_ip_filter:1;

		// this is true when our effective inactive state is different from our
		// actual inactive state. Whenever this state changes, there is a
		// quarantine period until we change the effective state. This is to avoid
		// flapping. If the state changes back during this period, we cancel the
		// quarantine
		std::uint32_t m_pending_active_change:1;

#if TORRENT_ABI_VERSION < 4
		// this is set to true if all piece layers were successfully loaded and
		// validated. Only for v2 torrents
		// TODO: this member can probably be removed
		std::uint32_t m_v2_piece_layers_validated:1;
#endif

// ----

		// this is set to the connect boost quota for this torrent.
		// After having received this many priority peer connection attempts, it
		// falls back onto the steady state peer connection logic, driven by the
		// session tick. Each tracker response, as long as this is non-zero, will
		// attempt to connect to peers immediately and decrement the counter.
		// We give torrents a connect boost when they are first added and then
		// every time they resume from being paused.
		std::uint8_t m_connect_boost_counter;

// ----

		// the scrape data from the tracker response, this
		// is optional and may be 0xffffff
		std::uint32_t m_incomplete:24;

		// true when the torrent should announce to
		// the DHT
		std::uint32_t m_announce_to_dht:1;

		// even if we're not built to support SSL torrents,
		// remember that this is an SSL torrent, so that we don't
		// accidentally start seeding it without any authentication.
		std::uint32_t m_ssl_torrent:1;

		// this is set to true if we're trying to delete the
		// files belonging to it. When set, don't write any
		// more blocks to disk!
		std::uint32_t m_deleted:1;

// ----

		// the timestamp of the last piece passed for this torrent specified in
		// seconds since epoch.
		time_point32 m_last_download{seconds32(0)};

		// the number of peer connections to seeds. This should be the same as
		// counting the peer connections that say true for is_seed()
		std::uint16_t m_num_seeds = 0;

		// this is the number of peers that are seeds, and count against
		// m_num_seeds, but have not yet been connected
		std::uint16_t m_num_connecting_seeds = 0;

		// the timestamp of the last byte uploaded from this torrent specified in
		// seconds since epoch.
		time_point32 m_last_upload{seconds32(0)};

		// user data as passed in by add_torrent_params
		client_data_t m_userdata;

// ----

		// if this is true, libtorrent may pause and resume
		// this torrent depending on queuing rules. Torrents
		// started with auto_managed flag set may be added in
		// a paused state in case there are no available
		// slots.
		std::uint32_t m_auto_managed:1;

		// the current stats gauge this torrent counts against
		std::uint32_t m_current_gauge_state:4;

		// set to true while moving the storage
		std::uint32_t m_moving_storage:1;

		// this is true if this torrent is considered inactive from the
		// queuing mechanism's point of view. If a torrent doesn't transfer
		// at high enough rates, it's inactive.
		std::uint32_t m_inactive:1;

// ----

		// the scrape data from the tracker response, this
		// is optional and may be 0xffffff
		std::uint32_t m_downloaded:24;

#if TORRENT_ABI_VERSION == 1
		// the timestamp of the last scrape request to one of the trackers in
		// this torrent specified in session_time. This is signed because it must
		// be able to represent time before the session started
		time_point32 m_last_scrape{seconds32(0)};
#endif

// ----

		// progress parts per million (the number of
		// millionths of completeness)
		std::uint32_t m_progress_ppm:20;

		// set to true once init() completes successfully. This is important to
		// track in case it fails and need to be retried if the client clears
		// the torrent error
		std::uint32_t m_torrent_initialized:1;

		// this is set to true while waiting for an async_set_file_priority
		std::uint32_t m_outstanding_file_priority:1;

		// set to true if we've sent an event=completed to any tracker. This will
		// prevent us from sending it again to anyone
		std::uint32_t m_complete_sent:1;

#if TORRENT_USE_ASSERTS
		// set to true when torrent is start()ed. It may only be started once
		bool m_was_started = false;
		bool m_outstanding_check_files = false;

		// this is set to true while we're looping over m_connections. We may not
		// mutate the list while doing this
		mutable int m_iterating_connections = 0;
#endif

#if TORRENT_USE_RTC
		std::shared_ptr<aux::rtc_signaling> m_rtc_signaling;
#endif
	};
}

#endif // TORRENT_TORRENT_HPP_INCLUDED
