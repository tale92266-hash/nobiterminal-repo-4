#----------------------------------------------------------------
# Generated CMake target import file for configuration "MinSizeRel".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Qt6::qtgraphicaleffectsplugin" for configuration "MinSizeRel"
set_property(TARGET Qt6::qtgraphicaleffectsplugin APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(Qt6::qtgraphicaleffectsplugin PROPERTIES
  IMPORTED_COMMON_LANGUAGE_RUNTIME_MINSIZEREL ""
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/qt6/qml/Qt5Compat/GraphicalEffects/libqtgraphicaleffectsplugin.so"
  IMPORTED_NO_SONAME_MINSIZEREL "TRUE"
  )

list(APPEND _cmake_import_check_targets Qt6::qtgraphicaleffectsplugin )
list(APPEND _cmake_import_check_files_for_Qt6::qtgraphicaleffectsplugin "${_IMPORT_PREFIX}/lib/qt6/qml/Qt5Compat/GraphicalEffects/libqtgraphicaleffectsplugin.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
