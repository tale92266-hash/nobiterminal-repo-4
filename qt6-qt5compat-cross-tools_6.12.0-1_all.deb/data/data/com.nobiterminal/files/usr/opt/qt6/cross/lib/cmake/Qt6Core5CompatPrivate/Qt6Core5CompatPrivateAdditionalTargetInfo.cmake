# Additional target information for Qt6Core5CompatPrivate
if(NOT DEFINED QT_DEFAULT_IMPORT_CONFIGURATION)
    set(QT_DEFAULT_IMPORT_CONFIGURATION MINSIZEREL)
endif()
__qt_internal_promote_target_to_global_checked(Qt6::Core5CompatPrivate)
