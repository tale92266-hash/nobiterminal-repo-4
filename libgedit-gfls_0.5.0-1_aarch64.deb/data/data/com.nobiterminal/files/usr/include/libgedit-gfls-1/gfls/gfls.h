/* SPDX-FileCopyrightText: 2023-2026 - Sébastien Wilmet
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#ifndef GFLS_H
#define GFLS_H

#define GFLS_H_INSIDE

#include <gfls/gfls-enum-types.h>

#include <gfls/gfls-attribute-keys.h>
#include <gfls/gfls-byte-array.h>
#include <gfls/gfls-encoding-conversion.h>
#include <gfls/gfls-encoding-converter.h>
#include <gfls/gfls-encoding.h>
#include <gfls/gfls-error.h>
#include <gfls/gfls-iconv.h>
#include <gfls/gfls-init.h>
#include <gfls/gfls-input-stream.h>
#include <gfls/gfls-loader-basic.h>
#include <gfls/gfls-loader-config.h>
#include <gfls/gfls-loader-config-simple.h>
#include <gfls/gfls-unsaved-document-titles.h>
#include <gfls/gfls-utf8-auto-converter.h>
#include <gfls/gfls-utf8.h>
#include <gfls/gfls-utils.h>
#include <gfls/gfls-validated-string-builder.h>
#include <gfls/gfls-validated-string-chunk.h>
#include <gfls/gfls-validated-string.h>

#undef GFLS_H_INSIDE

#endif /* GFLS_H */
