/* SPDX-FileCopyrightText: 2025-2026 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#if !defined (GFLS_H_INSIDE) && !defined (GFLS_COMPILATION)
#error "Only <gfls/gfls.h> can be included directly."
#endif

#include <gfls/gfls-encoding.h>
#include <gfls/gfls-validated-string.h>

G_BEGIN_DECLS

G_MODULE_EXPORT
GflsValidatedString *	gfls_encoding_convert		(GBytes              *input_bytes,
							 const GflsEncoding  *from_encoding,
							 const GflsEncoding  *to_encoding,
							 gboolean             allow_invalid_bytes,
							 gboolean            *lossy_conversion,
							 GError             **error);

G_MODULE_EXPORT
gboolean		gfls_encoding_try_convert	(GBytes      *input_bytes,
							 const gchar *to_codeset,
							 const gchar *from_codeset);

G_END_DECLS
