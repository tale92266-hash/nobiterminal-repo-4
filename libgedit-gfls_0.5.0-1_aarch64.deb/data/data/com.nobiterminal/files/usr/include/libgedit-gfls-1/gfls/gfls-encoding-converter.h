/* SPDX-FileCopyrightText: 2026 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#if !defined (GFLS_H_INSIDE) && !defined (GFLS_COMPILATION)
#error "Only <gfls/gfls.h> can be included directly."
#endif

#include <glib-object.h>
#include <gmodule.h>

G_BEGIN_DECLS

#define GFLS_TYPE_ENCODING_CONVERTER             (gfls_encoding_converter_get_type ())
#define GFLS_ENCODING_CONVERTER(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), GFLS_TYPE_ENCODING_CONVERTER, GflsEncodingConverter))
#define GFLS_ENCODING_CONVERTER_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), GFLS_TYPE_ENCODING_CONVERTER, GflsEncodingConverterClass))
#define GFLS_IS_ENCODING_CONVERTER(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GFLS_TYPE_ENCODING_CONVERTER))
#define GFLS_IS_ENCODING_CONVERTER_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), GFLS_TYPE_ENCODING_CONVERTER))
#define GFLS_ENCODING_CONVERTER_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), GFLS_TYPE_ENCODING_CONVERTER, GflsEncodingConverterClass))

typedef struct _GflsEncodingConverter         GflsEncodingConverter;
typedef struct _GflsEncodingConverterClass    GflsEncodingConverterClass;
typedef struct _GflsEncodingConverterPrivate  GflsEncodingConverterPrivate;

struct _GflsEncodingConverter
{
	GObject parent;
	GflsEncodingConverterPrivate *priv;
};

struct _GflsEncodingConverterClass
{
	GObjectClass parent_class;
};

/**
 * GflsEncodingConverterCallback:
 * @bytes: the chunk data.
 * @is_valid: whether @bytes is a valid chunk.
 * @user_data: user data.
 *
 * This callback function is called when there is an output chunk from the
 * #GflsEncodingConverter.
 *
 * @bytes is always nul-terminated, but this is not included in the #GBytes
 * length.
 *
 * If @is_valid is %TRUE, the chunk has been successfully converted.
 *
 * If @is_valid is %FALSE, the @bytes is a copy of the input bytes for which the
 * conversion failed. Note especially that the @bytes have not been escaped; for
 * that, you can call a function like gfls_utils_bytes_to_hex_representation().
 *
 * #GflsEncodingConverter makes no attempts to coalesce contiguous chunks of the
 * same kind. In other words, this callback can be called many times in a row
 * with the same value for @is_valid.
 *
 * You need to either use @bytes directly during the call of this callback, or
 * increase the reference count to store @bytes for later use. (When the call of
 * the callback finishes, #GflsEncodingConverter decreases the reference count
 * of @bytes).
 *
 * Since: 0.5
 */
typedef void (*GflsEncodingConverterCallback) (GBytes   *bytes,
					       gboolean  is_valid,
					       gpointer  user_data);

G_MODULE_EXPORT
GType			gfls_encoding_converter_get_type		(void);

G_MODULE_EXPORT
GflsEncodingConverter *	gfls_encoding_converter_new			(void);

G_MODULE_EXPORT
gboolean		gfls_encoding_converter_get_allow_invalid_bytes	(GflsEncodingConverter *converter);

G_MODULE_EXPORT
void			gfls_encoding_converter_set_allow_invalid_bytes	(GflsEncodingConverter *converter,
									 gboolean               allow_invalid_bytes);

G_MODULE_EXPORT
void			gfls_encoding_converter_set_callback		(GflsEncodingConverter         *converter,
									 GflsEncodingConverterCallback  callback,
									 gpointer                       user_data);

G_MODULE_EXPORT
gboolean		gfls_encoding_converter_open			(GflsEncodingConverter  *converter,
									 const gchar            *from_charset,
									 const gchar            *to_charset,
									 GError                **error);

G_MODULE_EXPORT
gboolean		gfls_encoding_converter_feed			(GflsEncodingConverter  *converter,
									 const guint8           *data,
									 gsize                   n_bytes,
									 GError                **error);

G_MODULE_EXPORT
gboolean		gfls_encoding_converter_finish_feeding		(GflsEncodingConverter  *converter,
									 GError                **error);

G_MODULE_EXPORT
gboolean		gfls_encoding_converter_get_lossy_conversion	(GflsEncodingConverter *converter);

G_END_DECLS
