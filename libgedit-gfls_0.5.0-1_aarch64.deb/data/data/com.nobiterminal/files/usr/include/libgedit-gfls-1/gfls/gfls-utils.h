/* SPDX-FileCopyrightText: 2026 - Sébastien Wilmet
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#if !defined (GFLS_H_INSIDE) && !defined (GFLS_COMPILATION)
#error "Only <gfls/gfls.h> can be included directly."
#endif

#include <gmodule.h>

G_BEGIN_DECLS

G_MODULE_EXPORT
gchar *		gfls_utils_bytes_to_hex_representation	(const guint8 *bytes,
							 gsize         n_bytes);

G_MODULE_EXPORT
gsize		gfls_utils_find_nearest_power_of_two	(gsize number);

G_END_DECLS
