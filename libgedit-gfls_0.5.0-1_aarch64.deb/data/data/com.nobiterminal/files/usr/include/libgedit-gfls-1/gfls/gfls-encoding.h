/* SPDX-FileCopyrightText: 2002-2005 - Paolo Maggi
 * SPDX-FileCopyrightText: 2014-2026 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#if !defined (GFLS_H_INSIDE) && !defined (GFLS_COMPILATION)
#error "Only <gfls/gfls.h> can be included directly."
#endif

#include <glib-object.h>
#include <gmodule.h>

G_BEGIN_DECLS

#define GFLS_TYPE_ENCODING (gfls_encoding_get_type ())

typedef struct _GflsEncoding GflsEncoding;

/**
 * GflsEncodingDuplicates:
 * @GFLS_ENCODING_DUPLICATES_KEEP_FIRST: Keep the first occurrence.
 * @GFLS_ENCODING_DUPLICATES_KEEP_LAST: Keep the last occurrence.
 *
 * Specifies which #GflsEncoding occurrence to keep when removing duplicated
 * encodings in a list with gfls_encoding_remove_duplicates().
 *
 * Since: 0.5
 */
typedef enum
{
	GFLS_ENCODING_DUPLICATES_KEEP_FIRST,
	GFLS_ENCODING_DUPLICATES_KEEP_LAST
} GflsEncodingDuplicates;

G_MODULE_EXPORT
GType		gfls_encoding_get_type			(void);

G_MODULE_EXPORT
GflsEncoding *	gfls_encoding_new			(const gchar *charset);

G_MODULE_EXPORT
GflsEncoding *	gfls_encoding_new_utf8			(void);

G_MODULE_EXPORT
GflsEncoding *	gfls_encoding_new_from_locale		(void);

G_MODULE_EXPORT
GflsEncoding *	gfls_encoding_copy			(const GflsEncoding *enc);

G_MODULE_EXPORT
gpointer	gfls_encoding_copy_func			(gconstpointer src,
							 gpointer      data);

G_MODULE_EXPORT
void		gfls_encoding_free			(GflsEncoding *enc);

G_MODULE_EXPORT
const gchar *	gfls_encoding_get_charset		(const GflsEncoding *enc);

G_MODULE_EXPORT
gboolean	gfls_encoding_has_known_charset		(const GflsEncoding *enc);

G_MODULE_EXPORT
const gchar *	gfls_encoding_get_name			(const GflsEncoding *enc);

G_MODULE_EXPORT
gchar *		gfls_encoding_to_string			(const GflsEncoding *enc);

G_MODULE_EXPORT
gboolean	gfls_encoding_is_utf8			(const GflsEncoding *enc);

G_MODULE_EXPORT
gboolean	gfls_encoding_is_locale			(const GflsEncoding *enc);

G_MODULE_EXPORT
gboolean	gfls_encoding_equals			(const GflsEncoding *enc1,
							 const GflsEncoding *enc2);

G_MODULE_EXPORT
gint		gfls_encoding_compare_func		(gconstpointer a,
							 gconstpointer b);

G_MODULE_EXPORT
GSList *	gfls_encoding_get_all			(void);

G_MODULE_EXPORT
GSList *	gfls_encoding_get_default_candidates	(void);

G_MODULE_EXPORT
GSList *	gfls_encoding_remove_duplicates		(GSList                 *list,
							 GflsEncodingDuplicates  removal_type);

G_END_DECLS
