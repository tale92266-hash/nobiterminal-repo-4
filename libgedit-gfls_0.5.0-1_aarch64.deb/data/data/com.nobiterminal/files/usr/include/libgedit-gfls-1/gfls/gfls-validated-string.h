/* SPDX-FileCopyrightText: 2026 - Sébastien Wilmet
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#if !defined (GFLS_H_INSIDE) && !defined (GFLS_COMPILATION)
#error "Only <gfls/gfls.h> can be included directly."
#endif

#include <gfls/gfls-validated-string-chunk.h>

G_BEGIN_DECLS

#define GFLS_TYPE_VALIDATED_STRING             (gfls_validated_string_get_type ())
#define GFLS_VALIDATED_STRING(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), GFLS_TYPE_VALIDATED_STRING, GflsValidatedString))
#define GFLS_VALIDATED_STRING_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), GFLS_TYPE_VALIDATED_STRING, GflsValidatedStringClass))
#define GFLS_IS_VALIDATED_STRING(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GFLS_TYPE_VALIDATED_STRING))
#define GFLS_IS_VALIDATED_STRING_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), GFLS_TYPE_VALIDATED_STRING))
#define GFLS_VALIDATED_STRING_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), GFLS_TYPE_VALIDATED_STRING, GflsValidatedStringClass))

typedef struct _GflsValidatedString         GflsValidatedString;
typedef struct _GflsValidatedStringClass    GflsValidatedStringClass;
typedef struct _GflsValidatedStringPrivate  GflsValidatedStringPrivate;

struct _GflsValidatedString
{
	GObject parent;
	GflsValidatedStringPrivate *priv;
};

struct _GflsValidatedStringClass
{
	GObjectClass parent_class;
};

G_MODULE_EXPORT
GType				gfls_validated_string_get_type		(void);

G_MODULE_EXPORT
GflsValidatedStringChunk **	gfls_validated_string_get_chunks	(GflsValidatedString *validated_string);

G_GNUC_INTERNAL
GflsValidatedString *		_gfls_validated_string_new		(GflsValidatedStringChunk **chunks);

G_END_DECLS
