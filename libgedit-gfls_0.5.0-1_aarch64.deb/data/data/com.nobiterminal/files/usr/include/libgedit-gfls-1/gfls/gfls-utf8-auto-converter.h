/* SPDX-FileCopyrightText: 2026 - Sébastien Wilmet
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#if !defined (GFLS_H_INSIDE) && !defined (GFLS_COMPILATION)
#error "Only <gfls/gfls.h> can be included directly."
#endif

#include <gfls/gfls-encoding.h>
#include <gfls/gfls-validated-string.h>

G_BEGIN_DECLS

typedef struct _GflsUtf8AutoConverter GflsUtf8AutoConverter;

G_MODULE_EXPORT
GflsUtf8AutoConverter *	gfls_utf8_auto_converter_new			(GBytes   *input_bytes,
									 GSList   *candidate_encodings,
									 gboolean  allow_invalid_bytes);

G_MODULE_EXPORT
void			gfls_utf8_auto_converter_free			(GflsUtf8AutoConverter *auto_converter);

G_MODULE_EXPORT
GflsValidatedString *	gfls_utf8_auto_converter_get_validated_string	(GflsUtf8AutoConverter *auto_converter);

G_MODULE_EXPORT
const GflsEncoding *	gfls_utf8_auto_converter_get_chosen_encoding	(GflsUtf8AutoConverter *auto_converter);

G_MODULE_EXPORT
gboolean		gfls_utf8_auto_converter_get_lossy_conversion	(GflsUtf8AutoConverter *auto_converter);

G_END_DECLS
