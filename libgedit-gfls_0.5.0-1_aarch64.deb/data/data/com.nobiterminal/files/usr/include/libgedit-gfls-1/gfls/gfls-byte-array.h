/* SPDX-FileCopyrightText: 2026 - Sébastien Wilmet
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#if !defined (GFLS_H_INSIDE) && !defined (GFLS_COMPILATION)
#error "Only <gfls/gfls.h> can be included directly."
#endif

#include <gmodule.h>

G_BEGIN_DECLS

typedef struct _GflsByteArray GflsByteArray;

G_MODULE_EXPORT
GflsByteArray *	gfls_byte_array_new			(void);

G_MODULE_EXPORT
GBytes *	gfls_byte_array_free_to_bytes		(GflsByteArray *byte_array);

G_MODULE_EXPORT
void		gfls_byte_array_append			(GflsByteArray *byte_array,
							 const guint8  *data,
							 gsize          size);

G_MODULE_EXPORT
guint8 *	gfls_byte_array_begin_write		(GflsByteArray *byte_array,
							 gsize          n_bytes_to_reserve);

G_MODULE_EXPORT
void		gfls_byte_array_end_write		(GflsByteArray *byte_array,
							 gsize          n_bytes_written);

G_END_DECLS
