/* SPDX-FileCopyrightText: 2023-2026 - Sébastien Wilmet
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#if !defined (GFLS_H_INSIDE) && !defined (GFLS_COMPILATION)
#error "Only <gfls/gfls.h> can be included directly."
#endif

#include <gio/gio.h>

G_BEGIN_DECLS

/**
 * GflsSimpleProgressCallback:
 * @number: the number.
 * @user_data: user data.
 *
 * Like #GFileProgressCallback but without the total.
 *
 * Since: 0.4
 */
typedef void (*GflsSimpleProgressCallback) (gsize    number,
					    gpointer user_data);

G_MODULE_EXPORT
void		gfls_input_stream_read_async	(GInputStream               *input_stream,
						 gsize                       expected_size,
						 gsize                       max_size,
						 gint                        io_priority,
						 GCancellable               *cancellable,
						 GflsSimpleProgressCallback  progress_callback,
						 gpointer                    progress_callback_data,
						 GAsyncReadyCallback         callback,
						 gpointer                    user_data);

G_MODULE_EXPORT
GBytes *	gfls_input_stream_read_finish	(GInputStream  *input_stream,
						 GAsyncResult  *result,
						 gboolean      *is_truncated,
						 GError       **error);

G_END_DECLS
