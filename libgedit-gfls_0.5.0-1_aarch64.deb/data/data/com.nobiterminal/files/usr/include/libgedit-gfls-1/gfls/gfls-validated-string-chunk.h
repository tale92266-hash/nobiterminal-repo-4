/* SPDX-FileCopyrightText: 2026 - Sébastien Wilmet
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#if !defined (GFLS_H_INSIDE) && !defined (GFLS_COMPILATION)
#error "Only <gfls/gfls.h> can be included directly."
#endif

#include <glib-object.h>
#include <gmodule.h>

G_BEGIN_DECLS

#define GFLS_TYPE_VALIDATED_STRING_CHUNK (gfls_validated_string_chunk_get_type ())

typedef struct _GflsValidatedStringChunk GflsValidatedStringChunk;

G_MODULE_EXPORT
GType				gfls_validated_string_chunk_get_type		(void);

G_MODULE_EXPORT
GflsValidatedStringChunk *	gfls_validated_string_chunk_new			(GBytes *bytes);

G_MODULE_EXPORT
GflsValidatedStringChunk *	gfls_validated_string_chunk_ref			(GflsValidatedStringChunk *chunk);

G_MODULE_EXPORT
void				gfls_validated_string_chunk_unref		(GflsValidatedStringChunk *chunk);

G_MODULE_EXPORT
GBytes *			gfls_validated_string_chunk_get_bytes		(GflsValidatedStringChunk *chunk);

G_MODULE_EXPORT
gboolean			gfls_validated_string_chunk_get_valid		(GflsValidatedStringChunk *chunk);

G_MODULE_EXPORT
void				gfls_validated_string_chunk_set_valid		(GflsValidatedStringChunk *chunk,
										 gboolean                  valid);

G_END_DECLS
