/* SPDX-FileCopyrightText: 2019, 2025 - Sébastien Wilmet <swilmet@gnome.org>
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#if !defined (GFLS_H_INSIDE) && !defined (GFLS_COMPILATION)
#error "Only <gfls/gfls.h> can be included directly."
#endif

#include <glib.h>
#include <gmodule.h>

G_BEGIN_DECLS

typedef struct _GflsIconv GflsIconv;

/**
 * GflsIconvResult:
 * @GFLS_ICONV_RESULT_OK: Everything OK.
 * @GFLS_ICONV_RESULT_ERROR: An error occurred.
 * @GFLS_ICONV_RESULT_ILLEGAL_SEQUENCE: Stopped at an invalid character in
 *   the @inbuf; or the character could not be represented in the target
 *   character set. `*inbuf` is left pointing to the beginning of the invalid or
 *   unconvertible sequence.
 * @GFLS_ICONV_RESULT_INCOMPLETE_INPUT: The input byte sequence ends with
 *   an incomplete multi-byte character. `*inbuf` is left pointing to the
 *   beginning of the incomplete multi-byte character.
 * @GFLS_ICONV_RESULT_OUTPUT_BUFFER_FULL: The output buffer has no more
 *   room for the next converted character.
 * @GFLS_ICONV_RESULT_LOSSY_CONVERSION: A number of nonreversible
 *   conversions have been performed.
 *
 * Used as the result value of gfls_iconv_feed().
 *
 * Since: 0.4
 */
typedef enum
{
	GFLS_ICONV_RESULT_OK,
	GFLS_ICONV_RESULT_ERROR,
	GFLS_ICONV_RESULT_ILLEGAL_SEQUENCE,
	GFLS_ICONV_RESULT_INCOMPLETE_INPUT,
	GFLS_ICONV_RESULT_OUTPUT_BUFFER_FULL,
	GFLS_ICONV_RESULT_LOSSY_CONVERSION,
} GflsIconvResult;

G_MODULE_EXPORT
GflsIconv *	gfls_iconv_new			(void);

G_MODULE_EXPORT
gboolean	gfls_iconv_open			(GflsIconv    *conv,
						 const gchar  *to_codeset,
						 const gchar  *from_codeset,
						 GError      **error);

G_MODULE_EXPORT
GflsIconvResult	gfls_iconv_feed			(GflsIconv  *conv,
						 gchar     **inbuf,
						 gsize      *inbytes_left,
						 gchar     **outbuf,
						 gsize      *outbytes_left,
						 GError    **error);

G_MODULE_EXPORT
GflsIconvResult	gfls_iconv_feed_discard_output	(GflsIconv  *conv,
						 gchar     **inbuf,
						 gsize      *inbytes_left,
						 GError    **error);

G_MODULE_EXPORT
gboolean	gfls_iconv_close		(GflsIconv  *conv,
						 GError    **error);

G_MODULE_EXPORT
void		gfls_iconv_free			(GflsIconv *conv);

G_END_DECLS
