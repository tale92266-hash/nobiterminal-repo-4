/* SPDX-FileCopyrightText: 2026 - Sébastien Wilmet
 * SPDX-License-Identifier: LGPL-3.0-or-later
 */

#pragma once

#if !defined (GFLS_H_INSIDE) && !defined (GFLS_COMPILATION)
#error "Only <gfls/gfls.h> can be included directly."
#endif

#include <gfls/gfls-validated-string.h>

G_BEGIN_DECLS

typedef struct _GflsValidatedStringBuilder GflsValidatedStringBuilder;

G_MODULE_EXPORT
GflsValidatedStringBuilder *	gfls_validated_string_builder_new			(void);

G_MODULE_EXPORT
GflsValidatedString *		gfls_validated_string_builder_free_to_validated_string	(GflsValidatedStringBuilder *builder);

G_MODULE_EXPORT
void				gfls_validated_string_builder_free			(GflsValidatedStringBuilder *builder);

G_MODULE_EXPORT
void				gfls_validated_string_builder_append_chunk		(GflsValidatedStringBuilder *builder,
											 GflsValidatedStringChunk   *chunk);

G_MODULE_EXPORT
void				gfls_validated_string_builder_append_validated_string	(GflsValidatedStringBuilder *builder,
											 GflsValidatedString        *validated_string);

G_MODULE_EXPORT
void				gfls_validated_string_builder_simplify			(GflsValidatedStringBuilder *builder);

G_END_DECLS
