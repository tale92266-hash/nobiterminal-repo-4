#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Groonga::libgroonga" for configuration "Release"
set_property(TARGET Groonga::libgroonga APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Groonga::libgroonga PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libgroonga.so"
  IMPORTED_SONAME_RELEASE "libgroonga.so"
  )

list(APPEND _cmake_import_check_targets Groonga::libgroonga )
list(APPEND _cmake_import_check_files_for_Groonga::libgroonga "/data/data/com.nobiterminal/files/usr/lib/libgroonga.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
