#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "TileDB::tiledb_shared" for configuration "Release"
set_property(TARGET TileDB::tiledb_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(TileDB::tiledb_shared PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "spdlog::spdlog"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libtiledb.so"
  IMPORTED_SONAME_RELEASE "libtiledb.so"
  )

list(APPEND _cmake_import_check_targets TileDB::tiledb_shared )
list(APPEND _cmake_import_check_files_for_TileDB::tiledb_shared "/data/data/com.nobiterminal/files/usr/lib/libtiledb.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
