# Get current dir.
get_filename_component(_PAGMO_CONFIG_SELF_DIR "${CMAKE_CURRENT_LIST_FILE}" PATH)

# Find the deps.
if(POLICY CMP0167)
	cmake_policy(SET CMP0167 OLD)
endif()
include(CMakeFindDependencyMacro)
find_dependency(Threads)
find_dependency(TBB CONFIG)
find_dependency(Boost 1.68.0 COMPONENTS serialization)
set(_PAGMO_CONFIG_OLD_MODULE_PATH "${CMAKE_MODULE_PATH}")
list(APPEND CMAKE_MODULE_PATH "${_PAGMO_CONFIG_SELF_DIR}")
find_package(Eigen3 QUIET REQUIRED NO_MODULE)
find_package(NLopt 2.6 QUIET REQUIRED NO_MODULE)

set(CMAKE_MODULE_PATH "${_PAGMO_CONFIG_OLD_MODULE_PATH}")
unset(_PAGMO_CONFIG_OLD_MODULE_PATH)

include(${_PAGMO_CONFIG_SELF_DIR}/pagmo_export.cmake)

# Clean up.
unset(_PAGMO_CONFIG_SELF_DIR)
