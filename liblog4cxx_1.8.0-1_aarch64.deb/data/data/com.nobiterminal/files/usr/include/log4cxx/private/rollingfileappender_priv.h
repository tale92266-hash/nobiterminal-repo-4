/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _LOG4CXX_ROLLING_FILEAPPENDER_PRIV_H
#define _LOG4CXX_ROLLING_FILEAPPENDER_PRIV_H

#include <log4cxx/private/fileappender_priv.h>

namespace LOG4CXX_NS
{

namespace rolling
{

struct RollingFileAppender::RollingFileAppenderPriv : public FileAppenderPriv
{
	RollingFileAppenderPriv() :
		FileAppenderPriv(),
		fileLength(0) {}

	/**
	 * Triggering policy.
	 */
	TriggeringPolicyPtr triggeringPolicy;

	/**
	 * Rolling policy.
	 */
	RollingPolicyPtr rollingPolicy;

	/**
	 * Length of current active log file.
	 */
	size_t fileLength;

	/**
	 *  save the loggingevent
	 */
	spi::LoggingEventPtr _event;

	bool activateOptions();
};

} // namespace rolling
} // namespace LOG4CXX_NS

#endif // _LOG4CXX_ROLLING_FILEAPPENDER_PRIV_H
