#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hidapi::libusb" for configuration "Release"
set_property(TARGET hidapi::libusb APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hidapi::libusb PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libhidapi-libusb.so"
  IMPORTED_SONAME_RELEASE "libhidapi-libusb.so"
  )

list(APPEND _cmake_import_check_targets hidapi::libusb )
list(APPEND _cmake_import_check_files_for_hidapi::libusb "/data/data/com.nobiterminal/files/usr/lib/libhidapi-libusb.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
