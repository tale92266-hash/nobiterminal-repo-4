#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "tins" for configuration "Release"
set_property(TARGET tins APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(tins PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libtins.so"
  IMPORTED_SONAME_RELEASE "libtins.so"
  )

list(APPEND _cmake_import_check_targets tins )
list(APPEND _cmake_import_check_files_for_tins "/data/data/com.nobiterminal/files/usr/lib/libtins.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
