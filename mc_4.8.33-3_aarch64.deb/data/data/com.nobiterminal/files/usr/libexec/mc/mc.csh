alias mc 'source /data/data/com.nobiterminal/files/usr/libexec/mc/mc-wrapper.csh'
