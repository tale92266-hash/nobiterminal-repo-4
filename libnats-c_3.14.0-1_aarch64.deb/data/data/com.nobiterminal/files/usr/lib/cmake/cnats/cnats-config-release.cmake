#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cnats::nats" for configuration "Release"
set_property(TARGET cnats::nats APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(cnats::nats PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libnats.so"
  IMPORTED_SONAME_RELEASE "libnats.so"
  )

list(APPEND _cmake_import_check_targets cnats::nats )
list(APPEND _cmake_import_check_files_for_cnats::nats "/data/data/com.nobiterminal/files/usr/lib/libnats.so" )

# Import target "cnats::nats_static" for configuration "Release"
set_property(TARGET cnats::nats_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(cnats::nats_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libnats_static.a"
  )

list(APPEND _cmake_import_check_targets cnats::nats_static )
list(APPEND _cmake_import_check_files_for_cnats::nats_static "/data/data/com.nobiterminal/files/usr/lib/libnats_static.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
