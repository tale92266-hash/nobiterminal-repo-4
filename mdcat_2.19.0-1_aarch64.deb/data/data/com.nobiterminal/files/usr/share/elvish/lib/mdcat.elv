
use builtin;
use str;

set edit:completion:arg-completer[mdcat] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'mdcat'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'mdcat'= {
            cand --columns 'Maximum number of columns to use for output. Defaults to 80, the terminal width (whichever is smaller), or `defaults.columns` in `~/.config/mdcat/config.toml`. Pass 0 to disable line wrapping'
            cand --completions 'Generate completions for a shell to standard output and exit'
            cand --theme 'Colour theme to use. Defaults to auto-detecting dark or light from the terminal, or to the `[theme]` section''s `base` in `~/.config/mdcat/config.toml` if that file exists'
            cand --image-protocol 'Force a specific inline image protocol instead of auto-detecting one from the terminal. Useful inside tmux/screen, where the outer terminal''s capabilities usually aren''t visible to auto-detection. `none` disables inline images entirely. Also settable via `$MDCAT_IMAGE_PROTOCOL`'
            cand --tabs 'Expand tabs in the input to spaces, using a tab stop width of COLUMNS, before parsing. Off by default, so literal tabs pass through unchanged; without this, a tab inside text content (not part of the Markdown block structure) throws off line-wrapping and alignment width calculations, since terminals render it as jumping to the next tab stop rather than occupying a single column. Also settable via `defaults.tabs` in `~/.config/mdcat/config.toml`'
            cand -c 'Disable all colours and other styles'
            cand --no-colour 'Disable all colours and other styles'
            cand --full-width 'Use the full terminal width instead of capping it at 80 columns. Also settable via `defaults.full_width` in `~/.config/mdcat/config.toml`'
            cand -l 'Do not load remote resources like images. Also settable via `defaults.local_only` in `~/.config/mdcat/config.toml`'
            cand --local 'Do not load remote resources like images. Also settable via `defaults.local_only` in `~/.config/mdcat/config.toml`'
            cand --fail 'Exit immediately if any error occurs processing an input file. Also settable via `defaults.fail_fast` in `~/.config/mdcat/config.toml`'
            cand --detect-terminal 'Print detected terminal name and exit'
            cand --ansi 'Skip terminal detection and only use ANSI formatting'
            cand -w 'Watch the input file and re-render on change. Requires a single file argument'
            cand --watch 'Watch the input file and re-render on change. Requires a single file argument'
            cand --margin 'Add a two-space left margin to all output. Reduces the effective render width accordingly. Also settable via `defaults.margin` in `~/.config/mdcat/config.toml`'
            cand --smart-punctuation 'Render typographic punctuation: straight quotes become curly, `--`/`---` become en/em dashes, and `...` becomes an ellipsis. Also settable via `defaults.smart_punctuation` in `~/.config/mdcat/config.toml`'
            cand --emoji 'Render GitHub-style emoji shortcodes (e.g. `:+1:`) as Unicode emoji. Off by default, to avoid silently changing existing output. Also settable via `defaults.emoji` in `~/.config/mdcat/config.toml`'
            cand --frontmatter 'Render YAML/TOML frontmatter as a table instead of stripping it. Off by default, to avoid silently changing existing output. Has no effect if the frontmatter isn''t a flat key-value mapping, or fails to parse; in that case it''s stripped as usual. Also settable via `defaults.frontmatter` in `~/.config/mdcat/config.toml`'
            cand --list-themes 'Print a sample rendered with every built-in theme, to help pick one, and exit'
            cand --toc 'Print a table of contents generated from the document''s headings before its content. Entries link to the source file, for terminals and later viewers that support OSC 8 links and resolve GitHub-style heading anchors; plain text on standard input, since there''s no file to link to'
            cand -p 'Paginate the output of mdcat with a pager like less (default for mdless)'
            cand --paginate 'Paginate the output of mdcat with a pager like less (default for mdless)'
            cand -P 'Do not paginate output (default). Overrides an earlier --paginate'
            cand --no-pager 'Do not paginate output (default). Overrides an earlier --paginate'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand -V 'Print version'
            cand --version 'Print version'
        }
    ]
    $completions[$command]
}
