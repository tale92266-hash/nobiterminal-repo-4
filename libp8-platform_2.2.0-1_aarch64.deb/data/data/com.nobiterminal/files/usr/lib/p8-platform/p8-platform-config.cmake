# - p8-platform config mode
#
# Defines the following variables:
#  p8-platform_FOUND        - true
#  p8-platform_VERSION      - version of the platform library found, e.g. 2.2.0
#  p8-platform_INCLUDE_DIRS - header directories with which to compile
#  p8-platform_LINKER_FLAGS - flags that must be passed to the linker
#  p8-platform_LIBRARIES    - names of the libraries with which to link
#  p8-platform_LIBRARY_DIRS - directories in which the libraries are situated
#

# this file is installed inside the tree it describes, so work everything out
# from its own location instead of the prefix it happened to be configured with.
# that keeps the installed tree relocatable, and points the find_*() calls below
# at our own tree, which would otherwise be free to pick up whichever
# p8-platform turned up first on the default search path
get_filename_component (_p8-platform_libdir "${CMAKE_CURRENT_LIST_DIR}/.." ABSOLUTE)
get_filename_component (_p8-platform_prefix "${CMAKE_CURRENT_LIST_DIR}/../../" ABSOLUTE)

# propagate these properties from one build system to the other
# report the patch level too: without it every 2.2.x looks like the same "2.2", so
# there's no way to ask for the version that carries a given fix
set (p8-platform_VERSION "2.2.0")
find_path (p8-platform_INCLUDE_DIRS p8-platform/os.h HINTS "${_p8-platform_prefix}/include")
set (p8-platform_LIBRARY_DIRS "${_p8-platform_libdir}")
set (p8-platform_LINKER_FLAGS "")
set (p8-platform_CONFIG_VARS "")

# libraries come from the build tree where this file was generated
if(WIN32)
  set (p8-platform_LIBRARY "${_p8-platform_libdir}/p8-platform.lib")
else(WIN32)
  find_library (p8-platform_LIBRARY p8-platform HINTS "${_p8-platform_libdir}")
endif(WIN32)
set (p8-platform_LIBRARIES ${p8-platform_LIBRARY} "-lpthread")
mark_as_advanced (p8-platform_LIBRARY)

# add the library as a target, so that other things in the project including
# this file may depend on it and get rebuild if this library changes.
add_library (p8-platform UNKNOWN IMPORTED)
set_property (TARGET p8-platform PROPERTY IMPORTED_LOCATION "${p8-platform_LIBRARY}")
# we're c++, so linking a static p8-platform needs the c++ runtime that the .a
# can't ask for by itself. cmake only honours this for STATIC, and only if the
# consumer has enabled CXX; the shared library records libstdc++ on its own
set_property (TARGET p8-platform PROPERTY IMPORTED_LINK_INTERFACE_LANGUAGES "CXX")
